<?php
// route => [Controller@method, [allowed HTTP methods], access]
// access: 'public' | 'guest' (login pages) | 'auth' (any signed-in user) | ['perm' => code] | ['role' => [slugs]]
// Every handler additionally enforces ownership / department / assignment checks on the data itself.
$admin = ['role' => ['super_admin']];
return [
    // Public
    'terms'               => ['PageController@terms',        ['GET'], 'public'],
    'auth/login'          => ['AuthController@login',        ['GET', 'POST'], 'guest'],
    'auth/forgot'         => ['AuthController@forgot',       ['GET', 'POST'], 'guest'],
    'auth/reset'          => ['AuthController@reset',        ['GET', 'POST'], 'guest'],
    'auth/logout'         => ['AuthController@logout',       ['POST'], 'auth'],

    // Account
    'account/profile'     => ['AccountController@profile',   ['GET', 'POST'], 'auth'],
    'account/photo'       => ['AccountController@photo',     ['GET'], 'auth'],
    'account/password'    => ['AccountController@password',  ['GET', 'POST'], 'auth'],
    'account/terms'       => ['AccountController@terms',     ['GET'], 'auth'],
    'account/terms/accept'=> ['AccountController@acceptTerms', ['POST'], 'auth'],

    'dashboard'           => ['DashboardController@index',   ['GET'], 'auth'],
    'help'                => ['PageController@help',         ['GET'], 'auth'],

    // Complaints
    'complaints'          => ['ComplaintController@index',   ['GET'], 'auth'],
    'complaints/create'   => ['ComplaintController@create',  ['GET'], ['perm' => 'complaints.create']],
    'complaints/store'    => ['ComplaintController@store',   ['POST'], ['perm' => 'complaints.create']],
    'complaints/view'     => ['ComplaintController@show',    ['GET'], 'auth'],
    'complaints/status'   => ['ComplaintController@status',  ['POST'], 'auth'],
    'complaints/assign'   => ['ComplaintController@assign',  ['POST'], ['perm' => 'complaints.assign']],
    'complaints/comment'  => ['ComplaintController@comment', ['POST'], 'auth'],
    'complaints/print'    => ['ComplaintController@print',   ['GET'], 'auth'],
    'complaints/pdf'      => ['ComplaintController@pdf',     ['GET'], 'auth'],
    'track'               => ['ComplaintController@track',   ['GET'], 'auth'],
    'attachments/download'=> ['ComplaintController@download', ['GET'], 'auth'],

    'notifications'       => ['NotificationController@index', ['GET'], 'auth'],
    'notifications/read'  => ['NotificationController@read',  ['POST'], 'auth'],

    // Departments
    'departments'         => ['DepartmentController@index',  ['GET'], ['perm' => 'departments.manage']],
    'departments/create'  => ['DepartmentController@create', ['GET'], ['perm' => 'departments.manage']],
    'departments/store'   => ['DepartmentController@store',  ['POST'], ['perm' => 'departments.manage']],
    'departments/view'    => ['DepartmentController@show',   ['GET'], ['perm' => 'departments.manage']],
    'departments/edit'    => ['DepartmentController@edit',   ['GET'], ['perm' => 'departments.manage']],
    'departments/update'  => ['DepartmentController@update', ['POST'], ['perm' => 'departments.manage']],
    'departments/toggle'  => ['DepartmentController@toggle', ['POST'], ['perm' => 'departments.manage']],

    // Users
    'users'               => ['UserController@index',        ['GET'], ['perm' => 'users.manage']],
    'users/create'        => ['UserController@create',       ['GET'], ['perm' => 'users.manage']],
    'users/store'         => ['UserController@store',        ['POST'], ['perm' => 'users.manage']],
    'users/edit'          => ['UserController@edit',         ['GET'], ['perm' => 'users.manage']],
    'users/update'        => ['UserController@update',       ['POST'], ['perm' => 'users.manage']],
    'users/toggle'        => ['UserController@toggle',       ['POST'], ['perm' => 'users.manage']],
    'users/reset-password'=> ['UserController@resetPassword', ['POST'], ['perm' => 'users.manage']],

    // Technicians
    'technicians'         => ['TechnicianController@index',  ['GET'], ['perm' => 'technicians.view']],
    'technicians/view'    => ['TechnicianController@show',   ['GET'], ['perm' => 'technicians.view']],

    // Reports
    'reports'             => ['ReportController@index',      ['GET'], ['perm' => 'reports.view']],
    'reports/csv'         => ['ReportController@csv',        ['GET'], ['perm' => 'reports.export']],
    'reports/pdf'         => ['ReportController@pdf',        ['GET'], ['perm' => 'reports.export']],
    'reports/print'       => ['ReportController@print',      ['GET'], ['perm' => 'reports.export']],

    // Super administrator only
    'settings'            => ['SettingsController@index',    ['GET'], $admin],
    'settings/save'       => ['SettingsController@save',     ['POST'], $admin],
    'settings/categories' => ['SettingsController@categories', ['GET'], $admin],
    'settings/categories/save' => ['SettingsController@categorySave', ['POST'], $admin],
    'settings/permissions'=> ['SettingsController@permissions', ['GET'], $admin],
    'settings/permissions/save' => ['SettingsController@permissionsSave', ['POST'], $admin],
    'audit'               => ['AuditController@index',       ['GET'], $admin],
];

<?php
// Permission catalogue. 'roles' lists the roles a permission can ever apply to; grants are stored in
// role_permissions and managed by the Super Administrator (Settings > Permissions).
// The Super Administrator always holds every permission.
return [
    'complaints.create'  => ['label' => 'Submit complaints',                                   'group' => 'Complaints', 'roles' => ['department_rep']],
    'complaints.respond' => ['label' => 'Respond to information requests, confirm or reopen',  'group' => 'Complaints', 'roles' => ['department_rep']],
    'complaints.review'  => ['label' => 'Review, accept, reject, change status and close',      'group' => 'Complaints', 'roles' => ['nis_admin']],
    'complaints.assign'  => ['label' => 'Assign and reassign complaints to technicians',        'group' => 'Complaints', 'roles' => ['nis_admin']],
    'complaints.work'    => ['label' => 'Update investigation progress on assigned complaints','group' => 'Complaints', 'roles' => ['technician']],
    'departments.manage' => ['label' => 'Register and manage departments',                     'group' => 'Administration', 'roles' => ['nis_admin']],
    'users.manage'       => ['label' => 'Manage technicians and department representatives',  'group' => 'Administration', 'roles' => ['nis_admin']],
    'technicians.view'   => ['label' => 'Monitor technician workload and activity',            'group' => 'Administration', 'roles' => ['nis_admin']],
    'reports.view'       => ['label' => 'View reports',                                        'group' => 'Reporting', 'roles' => ['nis_admin']],
    'reports.export'     => ['label' => 'Export reports (CSV, PDF, print)',                    'group' => 'Reporting', 'roles' => ['nis_admin']],
    'analytics.view'     => ['label' => 'View dashboard analytics charts',                     'group' => 'Reporting', 'roles' => ['nis_admin']],
];

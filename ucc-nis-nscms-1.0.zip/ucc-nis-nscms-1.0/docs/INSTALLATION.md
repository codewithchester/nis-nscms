# Installation guide (local machine)

You said you will test locally first and install on a server later. This guide covers the local part. For the server see
[`DEPLOYMENT.md`](DEPLOYMENT.md).

## 1. Requirements

| Item | Minimum |
|---|---|
| PHP | 8.1 or newer (8.2/8.3 recommended). Developed and tested on PHP 8.3 |
| PHP extensions | `pdo_mysql`, `mbstring` (required); `fileinfo` (recommended — verifies uploads); `openssl` (only for SMTP over TLS) |
| Database | MySQL 5.7+ or MariaDB 10.3+ (InnoDB, utf8mb4) |
| Web server | Apache (with `.htaccess`) — or PHP's built-in server for testing |
| Browser | Any current Chrome, Edge, Firefox or Safari |

No Composer, Node.js, Docker, Redis or SSH is needed, here or on the server.

## 2. Option A — XAMPP / WAMP / Laragon (recommended)

1. Start **Apache** and **MySQL** in the control panel.
2. Copy the project folder into the web root, e.g. `C:\xampp\htdocs\ucc-nis`.
3. Open **phpMyAdmin** → *New* → create a database named `ucc_nis` with collation **utf8mb4_unicode_ci**.
4. Browse to `http://localhost/ucc-nis/install/`.
   * Server check should be all ticks (a missing *fileinfo* is only a warning).
   * Database host `127.0.0.1`, port `3306`, database `ucc_nis`, user `root`, password empty (XAMPP default).
   * Environment: **Local testing**.
   * Leave *Add a few sample departments* ticked while testing.
   * Choose a Super Administrator name, email and a strong password (10+ characters, letters and numbers).
5. Click **Install**. When it says *Installation complete*, **delete the `install` folder**.
6. Open `http://localhost/ucc-nis/` and sign in. You will be asked to accept the Terms of Service once.

## 3. Option B — PHP built-in server (no Apache)

```bash
cd ucc-nis
php -S localhost:8000 router.php
```

Open `http://localhost:8000/install/`. Always start the server with `router.php` — the built-in server ignores
`.htaccess`, and the router blocks `.env`, `app/`, `storage/` and `database/` the way Apache would.

## 4. Option C — manual (phpMyAdmin import)

1. Copy `.env.example` to `.env` and fill in the `DB_*` values.
2. In phpMyAdmin, select your database → *Import* → `database/schema.sql`.
3. Create the first Super Administrator from a terminal in the project folder:
   ```bash
   php tools/create-admin.php
   ```
   (Without a terminal: generate a hash with `php -r "echo password_hash('YourPassword1', PASSWORD_DEFAULT);"` and insert a row into
   `users` with `role_id = 1`.)
4. Delete the `install` folder.

## 5. Updating an existing installation

Back up the database first. For the profile-photo feature, select the existing application database in phpMyAdmin and import
[`database/migrations/20261126_user_profile_photos.sql`](../database/migrations/20261126_user_profile_photos.sql).
The migration is idempotent and only creates the photo metadata table; it does not alter or delete existing user records.
Until it is applied, profile photo upload is disabled and the initials avatar remains available. New installations receive the
table from `database/schema.sql`.

## 6. First steps after installing

1. **Settings** (Super Administrator): check the institution/section names, support email and target resolution times.
2. **Departments → Register department** (or use the samples).
3. **Users → Add user**: create a *NIS Administrator*, one or more *Network Technicians*, and a *Department Representative*
   for each department. A temporary password is shown **once** — send it securely; the person must change it at first sign-in.
4. Sign in as the representative and submit a test complaint, then process it as an administrator and technician
   (walk-through in [`USER_GUIDE.md`](USER_GUIDE.md)).

### Testing email and password reset locally

By default `MAIL_DRIVER=log`: nothing is sent; every email is written to `storage/logs/mail.log`. Use it to read the
password-reset link after pressing *Forgot password*. To test real email later, set `MAIL_DRIVER=smtp` and the `MAIL_*` values in
`.env`, then tick *Send email notifications* in **Settings**.

## 7. Configuration reference (`.env`)

| Key | Meaning |
|---|---|
| `APP_ENV` | `local` or `production`. In production errors are never shown to users |
| `APP_DEBUG` | `true` shows error details — **only honoured when `APP_ENV=local`** |
| `APP_URL` | Public URL without trailing slash, used in email links. Empty = auto-detect |
| `APP_TIMEZONE` | Default `Africa/Accra` |
| `DB_HOST/PORT/NAME/USER/PASS` | Database connection |
| `TRUST_PROXY_HEADERS` | `true` only behind a trusted proxy/CDN (affects client IP and HTTPS detection) |
| `MAIL_*` | Email driver and SMTP credentials (server-side only) |
| `CSP_EXTRA_SCRIPT_SRC` | Extra allowed script origins if a host injects its own scripts |
| `NIS_ENV_FILE` (server variable) | Optional absolute path to keep the env file outside the web root |

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| Installer says *PDO MySQL extension missing* | Enable `extension=pdo_mysql` in `php.ini` and restart Apache |
| *Access denied for user* | Check DB user/password; XAMPP root has an empty password |
| *Unknown database* | Create it in phpMyAdmin first, or tick *Create the database if it does not exist* (local only) |
| Blank page / HTTP 500 | Read `storage/logs/php-error.log`. Set `APP_ENV=local` and `APP_DEBUG=true` temporarily |
| "Your form session expired" (419) | The page was open too long or cookies are blocked. Reload and retry |
| Signed out repeatedly | Idle timeout (Settings, default 30 min) or `storage/sessions` not writable |
| Uploads fail | Increase `upload_max_filesize` / `post_max_size` in `php.ini`; check the limit under Settings |
| Pretty page, no icons/fonts | Make sure the whole `assets/` folder was copied, including `assets/vendor` |
| Want to reinstall | Drop the tables, delete `.env` and `storage/installed.lock`, restore the `install` folder |

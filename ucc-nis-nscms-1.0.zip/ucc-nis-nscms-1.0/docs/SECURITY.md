# Security documentation

The system follows a *zero-trust* approach: being signed in grants nothing by itself. Every request is authenticated,
authorised against the **role and the specific record**, validated, and (for state changes) CSRF-checked on the server.

> Note: the original specification text provided ended at the heading "XSS PROTECTION". The controls below for XSS, CSRF,
> uploads, sessions, headers, logging and deployment were implemented to current best practice to complete that section.

## 1. Controls implemented

### Authentication
| Control | Where |
|---|---|
| Passwords hashed with `password_hash()` (bcrypt via `PASSWORD_DEFAULT`), verified with `password_verify()`, rehashed when the algorithm cost changes | `Core/Password.php`, `Core/Auth.php` |
| Password policy: 10–72 chars, letters + numbers, rejects obvious/common and email-derived passwords | `Password::policy()` |
| Same error message for unknown email and wrong password; a dummy hash is verified for unknown accounts (no user enumeration or timing leak) | `Auth::attempt()` |
| Brute-force protection: 5 failures per account/15 min and 25 per IP/15 min lock sign-in; attempts are logged | `Auth::isLocked()` |
| Session ID regenerated at login (anti-fixation) and after a password change; CSRF token rotated at login | `Auth::attempt()`, `AccountController` |
| Account activation/deactivation takes effect **immediately** (user row is re-read on every request); inactive departments block their representatives | `Auth::user()` |
| Temporary passwords (new users, admin resets) force a password change before anything else; shown once, never emailed | `UserController`, `Router` |
| Password reset: 256-bit random token, only its SHA-256 is stored, expires in 60 min, single use, older tokens invalidated, generic response, request throttling | `AuthController` |
| Idle timeout (default 30 min, configurable) and 8-hour absolute session lifetime; session bound to the browser's User-Agent hash | `Auth::user()` |

### Authorisation
| Control | Where |
|---|---|
| Central route table declares the required role/permission for **every** route; the router enforces it before the controller runs | `config/routes.php`, `Core/Router.php` |
| Permission catalogue per role, editable by the Super Administrator; the Super Administrator is the only role with implicit full access | `config/permissions.php`, `Auth::can()` |
| Record-level checks on every read/write: departments only see their own complaints; technicians only complaints assigned to them (active or completed); non-existent and forbidden records both return 404 (no existence leak) | `Models/Complaint::scope()` |
| Status changes validated against a role-aware workflow table; row locked (`SELECT … FOR UPDATE`) inside a transaction to prevent races | `Services/Workflow.php`, `ComplaintService` |
| User management limited to manageable roles (NIS admins cannot touch administrators); cannot deactivate yourself or the last Super Administrator | `Models/User::manageableRoles()` |
| Internal notes and their attachments are never sent to department representatives | `Complaint::comments/attachments()` |
| Department is taken from the logged-in user, never from form input | `ComplaintService::create()` |

### Injection and output safety
| Control | Where |
|---|---|
| **SQL injection**: PDO with native prepared statements everywhere (`ATTR_EMULATE_PREPARES=false`); no untrusted input is concatenated into SQL; sort columns come from a whitelist, directions are `ASC`/`DESC` only, `LIMIT/OFFSET` are cast to integers, `LIKE` wildcards are escaped | `Core/Db.php`, `Complaint::SORTS` |
| **XSS**: every output goes through `e()` (`htmlspecialchars`, UTF-8, quotes); JSON for charts is placed in attributes through `json_attr()`; no inline scripts, inline styles or inline event handlers exist | `Core/helpers.php`, all views |
| **Content-Security-Policy**: `default-src 'self'; script-src 'self'; style-src 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; base-uri 'self'` — injected script would not execute even if escaping failed | `Core/Security.php` |
| **CSRF**: per-session 256-bit token required on every POST, compared with `hash_equals`; logout is POST-only; session cookies are `SameSite=Lax` | `Core/Csrf.php`, `Router` |
| **Open redirects**: redirects are built only from known route names | `redirect()` |
| **CSV injection**: formula prefixes are neutralised even when preceded by spaces or control characters | `ReportService::csvSafeCell()` |
| **Header injection** in email: CR/LF stripped from addresses and subjects | `Core/Mailer.php` |

### File uploads
Extension allow-list (images, PDF, text/CSV, Word/Excel) · real MIME sniffing with `finfo` · image decoding check · reject files containing `<?php` ·
size limit (Settings + PHP limits) · stored **outside web access** in `storage/uploads` under a random 160-bit name **without an extension** ·
served only through an authorised controller with `Content-Disposition: attachment`, `X-Content-Type-Options: nosniff` and a sandbox CSP ·
each download is audited.

Profile photos are limited to decoded JPEG, PNG, or WebP images and served only to the signed-in owner. Their metadata is stored
in `user_profile_photos`; existing installations must apply the documented migration before enabling uploads. The storage folder
is denied by Apache rules and by the local development router.

### Sessions and cookies
Name `UCCNIS_SID`, `HttpOnly`, `SameSite=Lax`, `Secure` automatically on HTTPS, strict mode, cookies-only, session files kept in `storage/sessions`
(not the shared system temp dir), expired session files garbage-collected.

### Headers
CSP (above) · `X-Frame-Options: DENY` · `X-Content-Type-Options: nosniff` · `Referrer-Policy: strict-origin-when-cross-origin` · `Permissions-Policy` (camera, microphone, geolocation, payment off) ·
`Cross-Origin-Opener-Policy: same-origin` · HSTS when served over HTTPS · `Cache-Control: no-store` (no caching of private pages).

### Secrets and configuration
Database and SMTP credentials live only in `.env` on the server. They are never rendered into pages or JavaScript. `.env`, `*.sql`, `*.md`, `*.log`, `app/`, `config/`,
`storage/`, `database/`, `tools/` and `docs/` are blocked from the web by `.htaccess`. In production, PHP errors are logged, not displayed.
Keep real account passwords out of source files and documentation. The repository `.gitignore` excludes `.env` and runtime
storage; rotate any credential that has previously been placed in a shared project copy.

### Audit trail
`audit_logs` records sign-ins (success, failure, lockout), logouts, password changes/resets, user and department changes, settings and permission changes,
complaint creation, status changes, assignments, comments, downloads, exports, printed documents, denied access and rejected CSRF tokens — with user, IP and User-Agent.
It is append-only from the application (no edit/delete screen).

### Data integrity
Foreign keys, unique constraints (e-mail, reference number, department name/code), indexes, transactions for every multi-step operation (create complaint, assign, change status, reset password),
and a locked yearly counter so reference numbers are unique and sequential even under concurrent submissions.

## 2. Verification status

This checkout does not include the scripted HTTP/database test suite referenced in earlier packaging notes, so those results
cannot be reproduced here. Use [`TESTING.md`](TESTING.md) for the manual acceptance checklist and command-line checks. Security
controls should be re-tested against a disposable database before deployment.

## 3. Deployment hardening checklist

- [ ] `APP_ENV=production`, `APP_DEBUG=false`
- [ ] HTTPS enabled and the redirect block in `.htaccess` uncommented
- [ ] `install/` folder deleted (Settings → *Environment* warns if it is still there)
- [ ] Verify that `https://your-site/.env`, `/storage/logs/php-error.log`, `/database/schema.sql` and `/app/bootstrap.php` return **403/404**
- [ ] Strong Super Administrator password; create named accounts for each administrator (no shared logins)
- [ ] Database user has only the privileges it needs on its own database
- [ ] Regular database backups (see `DEPLOYMENT.md`) and a copy of `storage/uploads`
- [ ] If behind a trusted proxy/CDN, set `TRUST_PROXY_HEADERS=true`; otherwise leave `false`
- [ ] Review the Terms of Service text with the university's legal office
- [ ] On your own server, prefer placing the env file outside the web root (`NIS_ENV_FILE`) and denying `app/ config/ storage/ database/ tools/ docs/` in the web-server config (nginx example in `DEPLOYMENT.md`)

## 4. Known limitations (be aware)

* No two-factor authentication or user-configurable notification preferences yet.
* Email delivery on free shared hosting may be blocked; it is optional and never blocks complaint submission.
* The strict CSP blocks scripts injected by a host; list their origins in `CSP_EXTRA_SCRIPT_SRC` only if truly needed.
* Antivirus scanning of uploads is not included; the allow-list, content checks and private storage reduce risk, but consider server-side scanning on the university server.
* Login throttling uses the client IP seen by PHP. Behind a proxy, set `TRUST_PROXY_HEADERS` correctly or many users may share one IP.

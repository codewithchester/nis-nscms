# Deployment guide

Plan: test locally → test on **InfinityFree** (initial online testing) → move to an **approved UCC server / portal**.
The same code runs in all three; only `.env` and the database change.

> **Data warning.** Free shared hosting is for testing. Use dummy or non-sensitive data on InfinityFree. Production use
> belongs on university-controlled infrastructure with HTTPS and backups.

## A. InfinityFree (test deployment)

1. **Create the account and site.** Add a hosting account and note the *FTP host/user/password* and the *htdocs* folder.
2. **Create the database.** Control panel → *MySQL Databases* → create one. Note the **host** (like `sql123.infinityfree.com`, *not* `localhost`),
   the **database name** (like `if0_12345678_nis`), **user** and **password**.
3. **Upload the files.** Using FileZilla (FTP) upload the *contents* of the project folder into `htdocs/` (so `index.php` is directly inside `htdocs`).
   Upload the whole `assets/` folder including `assets/vendor`, and the hidden file `.htaccess` (turn on *show hidden files*).
   Make sure these folders exist and are writable by PHP (normally the default is fine): `storage/uploads`, `storage/logs`, `storage/sessions`.
4. **Run the installer.** Visit `https://your-site/install/`, enter the database values from step 2, choose **Production**, set the *Site URL*, create your Super Administrator.
   The installer needs write access to the project root to create `.env`; if it cannot, it shows the content to paste into a new `.env` file.
5. **Delete the `install` folder** via FTP.
6. **HTTPS.** Enable the free SSL certificate in the control panel. When it is active, open `.htaccess` and uncomment the HTTPS redirect block.
7. **Check protection.** These must return 403/404: `/.env`, `/storage/logs/php-error.log`, `/database/schema.sql`, `/app/bootstrap.php`, `/config/routes.php`.
8. **Sign in** and follow *First steps* in [`INSTALLATION.md`](INSTALLATION.md).

### InfinityFree notes
* **PHP version:** choose PHP 8.1 or newer in the control panel (*Select PHP Version*), and make sure `pdo_mysql`, `mbstring` and `fileinfo` are on.
* **Upload size:** limits are set by the host (`upload_max_filesize`); keep *Max upload* in Settings at or below it.
* **Email:** free hosts commonly restrict outgoing mail/SMTP. Leave `MAIL_DRIVER=log`; in-app notifications still work. If your plan allows SMTP, set `MAIL_DRIVER=smtp` and credentials, then tick the Settings switch. Test with *Forgot password*.
* **Injected scripts:** if the host adds its own JavaScript to pages and the browser console shows CSP violations, put the script origin into `CSP_EXTRA_SCRIPT_SRC`.
* **Client IP / proxy:** leave `TRUST_PROXY_HEADERS=false` unless you have verified that the host forwards the real IP in `X-Forwarded-For`.
* **No SSH:** everything (installation, configuration) is done through the web installer, phpMyAdmin and FTP. No Composer/Node is needed.
* **Browser check page:** the host may show a short “checking your browser” page on the first visit; this is normal.

## B. Moving to a UCC server or portal

1. **Requirements:** PHP 8.1+ (`pdo_mysql`, `mbstring`, `fileinfo`, `openssl`), MySQL 5.7+/MariaDB 10.3+, HTTPS, Apache or nginx.
2. **Copy** the project to the server. Preferably keep `.env` outside the web root and expose it with the `NIS_ENV_FILE` environment variable
   (Apache: `SetEnv NIS_ENV_FILE /etc/ucc-nis/nis.env`; PHP-FPM: `env[NIS_ENV_FILE]=...`).
3. **Database:** on the old host export (`mysqldump --single-transaction dbname > nis.sql`), create the new database, import it, update `DB_*` in `.env`.
   Copy `storage/uploads/` too — attachment rows refer to those files.
4. **Set** `APP_ENV=production`, `APP_URL=https://nis.ucc.edu.gh` (use the real address), correct SMTP credentials, and tick email notifications in Settings.
5. **Permissions:** the PHP user needs write access to `storage/` only; everything else can be read-only. Example: `chown -R www-data:www-data storage && chmod -R 750 storage`.
6. **Authentication integration:** if UCC single sign-on/LDAP is required later, replace the body of `Auth::attempt()` (one method) and keep the session logic.
7. **Backups:** nightly `mysqldump` plus a copy of `storage/uploads`; test a restore. Keep audit-log retention in line with university policy.
8. **Monitoring:** watch `storage/logs/php-error.log` and the web-server logs; consider rotating them.

### Apache virtual host (excerpt)
```apache
<VirtualHost *:443>
    ServerName nis.example.edu.gh
    DocumentRoot /var/www/ucc-nis
    <Directory /var/www/ucc-nis>
        AllowOverride All        # lets the supplied .htaccess files work
        Require all granted
    </Directory>
    SetEnv NIS_ENV_FILE /etc/ucc-nis/nis.env
</VirtualHost>
```

### nginx (no .htaccess support — add these rules)
```nginx
server {
    root /var/www/ucc-nis;
    index index.php;
    location ~ ^/(app|config|database|storage|tools|docs)/ { deny all; }
    location ~ /\.(?!well-known) { deny all; }
    location ~* \.(env|sql|md|log|lock|example)$ { deny all; }
    location /install/ { deny all; }              # after installation
    location = /index.php { include fastcgi_params; fastcgi_pass unix:/run/php/php8.2-fpm.sock; fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name; }
    location ~ \.php$ { return 404; }              # only index.php may execute (temporarily allow /install/index.php while installing)
    client_max_body_size 10m;
}
```

### Optional: pretty URLs
Links are generated by one function, `url()` in `app/Core/helpers.php`, and routes are read from `$_GET['r']` in `Core/Router.php`.
To move to `/complaints/view/12`-style URLs, add a rewrite rule that maps the path to `index.php?r=...` and change `url()`. Nothing else depends on the format.

# Architecture and database

## 1. Request flow

```
browser ──► index.php?r=complaints/view&id=12
              │
              ├─ app/bootstrap.php   autoloader, .env, timezone, error handling, security headers, session
              └─ Core/Router         1. validate route name          4. role / permission from config/routes.php
                                     2. check HTTP method            5. force password change / accept Terms
                                     3. verify CSRF on POST          6. call Controller@method
                    Controller  ──►  Models / Services (SQL via PDO prepared statements, transactions)
                         └────────►  View (PHP template, output escaped with e()) inside layouts/app|auth|print
```

Everything is plain PHP with PSR-4-style autoloading: `App\Core\Db` → `app/Core/Db.php`.

## 2. Folder map

| Path | Purpose |
|---|---|
| `app/Core` | Framework pieces: `Router`, `Auth`, `Db`, `Session`, `Csrf`, `Validator`, `Password`, `View`, `Form`, `Mailer`, `Pdf`, `Audit`, `Settings`, `Security`, `Request`, `Env`, `helpers.php` |
| `app/Controllers` | One class per feature area; thin: validate input → call service/model → redirect or render |
| `app/Services` | Business rules: `Workflow` (lifecycle), `ComplaintService` (create/transition/assign/comment), `Notifier`, `Upload`, `DashboardService`, `ReportService` |
| `app/Models` | Query helpers with the row-level visibility rules (`Complaint::scope()`), `User`, `Department` |
| `app/Views` | Templates: `layouts/`, `partials/`, one folder per feature |
| `config/routes.php` | The single table of routes and who may use them |
| `config/permissions.php` | Permission catalogue and the roles each can apply to |
| `database/schema.sql` | Complete installation SQL (tables, indexes, foreign keys, reference data) |
| `storage/` | `uploads/` (private attachments), `logs/` (php-error.log, mail.log), `sessions/` |
| `assets/` | `css/app.css`, `css/print.css`, `js/app.js`, `vendor/*`, `img/*` |

## 3. Database (InnoDB, utf8mb4)

| Table | Purpose / key points |
|---|---|
| `roles` | 4 fixed roles (`super_admin`, `nis_admin`, `technician`, `department_rep`) |
| `permissions`, `role_permissions` | Permission catalogue and per-role grants (managed in the UI) |
| `departments` | Unique `name` and `code`, `is_active` |
| `users` | Unique email, `password_hash`, `role_id`, optional `department_id`, `is_active`, `must_change_password`, Terms acceptance, last login |
| `complaint_categories` | Editable list shown on the form |
| `reference_counters` | One row per year; locked inside the creation transaction to issue `NIS-YYYY-NNNNN` |
| `complaints` | Core record: reporter details, location, priority, status, `due_at`, `assigned_to`, timestamps; indexes on department, status, priority, category, assignee, dates |
| `complaint_assignments` | Technician, assigning administrator, date, status (`Active`/`Completed`/`Reassigned`), instructions, investigation notes, resolution details |
| `complaint_status_history` | Every status change with who/when/why |
| `complaint_comments` | Messages, updates, findings, work performed, information requests/responses, resolution; `is_internal` hides from departments |
| `attachments` | File metadata, random stored name, MIME, size, SHA-256 |
| `notifications` | In-app notifications per user |
| `password_resets` | SHA-256 of the token, expiry, used-at |
| `login_attempts` | Throttling data |
| `audit_logs` | Security/audit trail |
| `system_settings` | Key/value settings (no secrets) |

Relationships: `users → roles`, `users → departments`, `complaints → departments/users/categories`, `assignments/history/comments/attachments → complaints (ON DELETE CASCADE)`.
No hard delete exists in the UI: users, departments and categories are *deactivated*, so history stays intact.

## 4. Permissions model

* **Role** decides *data visibility* (fixed in `Complaint::scope()`).
* **Permission** decides *which actions* a role may perform (`complaints.assign`, `reports.export`, …), stored in `role_permissions`.
* Super Administrator always passes `Auth::can()`; settings, audit log and permission management are `super_admin` only.
* Routes declare requirements in `config/routes.php`; controllers/services re-check ownership on every record.

## 5. Extending the system

**Add a page**
1. Add a route in `config/routes.php`: `'faq' => ['PageController@faq', ['GET'], 'auth'],`
2. Add `public function faq(): void { $this->render('pages/faq', [], 'FAQ'); }` and `app/Views/pages/faq.php`.
3. Link it with `url('faq')` and escape every value with `e()`.

**Add a permission**: add it to `config/permissions.php` and to `database/schema.sql` (and `INSERT` it into `permissions`), grant it in *Roles & permissions*, then guard the route with `['perm' => 'your.code']`.

**Add a complaint category**: Super Administrator → *Categories* (no code needed).

**Add a status**: update the `ENUM` in `schema.sql`, `Workflow::STATUSES` and the transition table in `Workflow::allowed()`, plus the badge colour in `app.css`.

**Replace the login method** (e.g. university SSO/LDAP): change `Auth::attempt()`; everything else uses the session it creates.

**Rebrand**: CSS variables at the top of `assets/css/app.css`; logo in `app/Views/partials/logo.php`, `assets/img/favicon.svg`; text in Settings.

## 6. Coding conventions

`declare(strict_types=1)` everywhere · prepared statements only · escape on output (`e()`), validate on input (`Validator`) · no inline JS/CSS ·
controllers contain no SQL for business rules · multi-step writes inside `Db::tx()` · notifications are sent *after* commit and can never break the main action.

# Accessibility

The interface includes semantic page landmarks, a skip-to-content link, labels for icon-only controls, an announced active
navigation link, visible keyboard focus, and a keyboard-operable mobile navigation. The mobile menu supports Escape to
close, returns focus to its opener, and keeps keyboard focus within the open navigation.

The light/dark appearance control exposes its state with `aria-pressed` and a descriptive accessible name. The choice is
stored in the current browser and does not change account data. When no choice is stored, the operating-system preference
is used. The interface also respects reduced-motion preferences and serves Poppins locally, with system font fallbacks.

These features are not a certification of WCAG conformance. Before production, test key workflows with keyboard-only
navigation, browser zoom at 200%, and screen readers such as NVDA with Firefox/Chrome or VoiceOver with Safari. Confirm
that status, validation, notification, and chart information remains understandable without relying on color or visuals.

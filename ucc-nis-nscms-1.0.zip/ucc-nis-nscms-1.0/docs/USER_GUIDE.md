# User guide

## Roles at a glance

| Role | Can do |
|---|---|
| **Super Administrator** | Everything: users (including NIS administrators), departments, all complaints, analytics, settings, categories, roles & permissions, audit log |
| **NIS Administrator** | Review/accept/reject complaints, assign and reassign technicians, change statuses, message departments, reports, manage technicians & department representatives, departments |
| **Network Technician** | See only complaints assigned to them; start work, post updates/findings/work done, ask the department for information, mark resolved; assignment history |
| **Department Representative** | Report complaints for their own department, see only that department's complaints, answer information requests, confirm/reopen resolved complaints, print/download details |

What each non-super role may do can be adjusted under **Settings → Roles & permissions**. Data isolation (departments see
only their own data; technicians only their assignments) is fixed in code.

## Appearance and accessibility

Use the appearance button in the top bar (or sign-in page footer) to switch between light and dark themes. Your choice is
remembered in this browser; if you have not chosen yet, the system appearance is used. Use **Skip to content** to bypass
navigation, and use **Tab**, **Shift+Tab**, **Enter**, and **Space** to move through controls. The mobile navigation can be
closed with its close button or **Escape**. See [`ACCESSIBILITY.md`](ACCESSIBILITY.md) for screen-reader and testing notes.

## Complaint lifecycle

```
Submitted → Under Review → Accepted → Assigned → In Progress → Resolved → Closed
                 ↘ Rejected (with reason)         ↕ Awaiting Department Response
```

| Status | Meaning | Who moves it |
|---|---|---|
| Submitted | Logged by a department, reference number issued | Department (on submit) |
| Under Review | NIS is reading it | NIS administrator |
| Accepted | NIS agrees to handle it | NIS administrator |
| Assigned | A technician has been chosen | Assigning a technician sets this automatically |
| In Progress | Technician is working | Technician / administrator |
| Awaiting Department Response | NIS/technician needs information; the SLA clock pauses | Administrator / technician (note required). Returns automatically when the department replies |
| Resolved | Fix reported, resolution notes recorded | Technician / administrator (notes required) |
| Closed | Confirmed and finished | Department confirms, or administrator closes |
| Rejected | Not accepted; the reason is shown to the department | Administrator (reason required). Can be re-opened to *Under Review* |

A resolved complaint can be **reopened** by the department or administrator (reason required) and goes back to *In Progress*
with the same technician.

## My profile

Open the account menu and choose **My profile** to update your name and phone number, review your role-specific activity
statistics, account status, creation date, and last sign-in time. You can use initials as an avatar or upload a JPEG, PNG, or
WebP photo. Existing installations must apply the profile-photo migration in [`INSTALLATION.md`](INSTALLATION.md) first.

## Priorities and target resolution times

Defaults (changeable in Settings): **Critical 4 h**, **High 24 h**, **Medium 72 h**, **Low 168 h** from submission.
A complaint is *overdue* when its target time has passed while it is still open. Time spent in *Awaiting Department Response* does not count.

## Department representative

1. **Report a problem** → fill in title, category, priority, description, building and room, when it was noticed, contact details and an optional screenshot (max size shown on the form).
2. Keep the reference number. Use **Track a complaint** or open it from **My complaints**.
3. When status is **Awaiting Department Response**, open the complaint and reply in *Discussion and updates*.
4. When **Resolved**, choose **Confirm resolved and close** or **Not fixed — reopen**.
5. **Print** or **Download PDF** from the complaint page.
6. In **Discussion and updates**, messages are ordered oldest first; internal NIS notes and their attachments are not shown.

## NIS administrator

1. New complaints appear on the dashboard and as notifications.
2. Open a complaint → set **Under Review**, then **Accepted** or **Rejected** (explain why).
3. **Assign to a technician** (optional instructions). The same panel **reassigns**; the previous technician is notified and loses access.
4. Use **Request information from department** when details are missing.
5. Post messages; tick *Internal note* to hide them from the department.
6. **Reports**: choose filters → inspect or collapse the animated on-screen preview, then **Print**, **PDF** or **CSV** (opens in Excel). CSV exports include every matching complaint; PDF detail tables are limited to the latest 500 records.
7. **Technicians**: workload bars, overdue counts, average completion time, assignment history.
8. **Departments**: register/edit/deactivate; open one to see its statistics, history and representatives, and to add a representative.

## Network technician

1. **My work** lists your active assignments, most urgent first.
2. Open one → **Start work (In Progress)**.
3. Post **Progress updates**, **Technical findings** and **Work performed**. Untick *Visible to the department* for internal notes.
4. Need information? **Ask the department for information** (write your question).
5. Finished? **Mark as resolved** and write what you did. The department then confirms.

## Super Administrator extras

* **Users**: create NIS administrators too; reset a password (temporary password shown once); deactivate/activate. The last active Super Administrator cannot be deactivated.
* **Settings**: names, target times, rows per page, upload limit, idle timeout, recurring-problem threshold, email switch.
* **Categories**: add, rename, reorder, deactivate (history stays intact).
* **Roles & permissions**: tick what each role may do.
* **Audit log**: sign-ins, failures, status changes, assignments, exports, settings changes, with IP addresses.

## Notifications

A bell (top right) shows unread items. Events: complaint submitted/received, accepted, rejected, technician assigned, status
changed, information requested/provided, resolved, reopened, closed, new messages. Email copies are sent only if enabled.

## Reports explained

* **Most frequently reported problems** – complaints per category.
* **Departments with highest volume** – complaints per department.
* **Recurring problems** – the same category reported N or more times (Settings; default 3) for the same department and building.
* **Average resolution time** – submission to resolution, resolved complaints only.
* **Resolved within target** – share of resolved complaints that met their target time.
* **Technician performance** – assignments, completed, active, average time from assignment to completion.
* All figures are calculated from the database; empty periods show empty states, never placeholder numbers.

# Testing

## 1. Automated checks in this checkout

No repeatable automated test suite is included in this project copy. Earlier packaging notes described HTTP/database checks,
but their test scripts are not present here, so those results cannot be reproduced from this checkout. Do not treat them as
current verification. Run the syntax checks below and complete the manual acceptance checklist against a local test database.

## 2. Manual acceptance checklist (do this locally)

**Accounts**
- [ ] Install, sign in as Super Administrator, accept the Terms
- [ ] Update your profile name/phone; after applying the profile-photo migration, upload a valid image and reject an oversized or non-image file
- [ ] Create an NIS Administrator, two technicians, two representatives in different departments
- [ ] New user signs in with the temporary password and is forced to set a new one
- [ ] Deactivate a user → their open session ends at once; activate again
- [ ] *Forgot password* → open `storage/logs/mail.log`, use the link once; second use fails

**Complaints**
- [ ] Representative submits a complaint with a screenshot; reference `NIS-<year>-00001` shown
- [ ] Other department's representative cannot open it (404) nor find it by reference
- [ ] Administrator: Under Review → Accepted → assign technician → status becomes *Assigned*
- [ ] Technician sees only the assigned complaint; *Start work*; posts an internal finding and a public update
- [ ] Representative sees the public update but **not** the internal note
- [ ] Technician requests information → representative gets a notification and replies → status returns to *In Progress*
- [ ] Technician resolves with notes → representative confirms and closes (or reopens with a reason)
- [ ] Reject a complaint with a reason; the department sees the reason
- [ ] Print and PDF of a complaint open and look correct

**Admin & reporting**
- [ ] Dashboard counts and charts match the complaints list
- [ ] List filters, sorting and pagination work (create 20+ complaints if possible)
- [ ] Reports: change date range/filters; expand/collapse the preview; CSV opens in Excel and includes the full filtered selection; PDF and print layout include reference and applied filters
- [ ] Export CSV values beginning with formula characters, including those preceded by whitespace/control characters, and confirm Excel treats them as text
- [ ] Technicians page shows workload; Departments page shows statistics and representatives
- [ ] Settings: change a target time, add a category, change a permission and see the effect
- [ ] Audit log shows the actions above

**Responsiveness / accessibility**
- [ ] Resize to phone width: menu button opens the sidebar, tables scroll, forms are usable
- [ ] Keyboard only: Tab reaches all controls, focus ring visible, *Skip to content* link works

**Security spot checks**
- [ ] `/.env`, `/storage/...`, `/database/schema.sql` are not downloadable (Apache, or `php -S … router.php`)
- [ ] Paste `<script>alert(1)</script>` in a complaint title: it is shown as text, nothing runs
- [ ] 5 wrong passwords lock sign-in for 15 minutes
- [ ] `install/` removed after installation

## 3. Quick command-line sanity checks

```bash
# syntax-check every PHP file
find . -name '*.php' -not -path './assets/*' -exec php -l {} \; | grep -v "No syntax errors"

# create a Super Administrator without the web installer
php tools/create-admin.php
```

# Bundled third-party components

All files are served locally from `assets/vendor/` (no CDN calls), which keeps the strict Content-Security-Policy intact.

| Component | Version | Licence |
|---|---|---|
| Bootstrap (CSS + JS bundle, includes Popper) | 5.3.3 | MIT |
| Chart.js | 4.4.4 | MIT |
| Bootstrap Icons (CSS + web fonts) | 1.11.3 | MIT |
| IBM Plex Sans / IBM Plex Mono (WOFF2 subsets via Fontsource) | 5.x | SIL Open Font License 1.1 (see `assets/vendor/fonts/LICENSE-IBM-Plex-OFL.txt`) |
| Poppins (WOFF2 Latin and Latin-ext subsets from Google Fonts) | Google Fonts | SIL Open Font License 1.1 (see `assets/vendor/fonts/LICENSE-POPPINS-OFL.txt`) |

The PDF generator (`app/Core/Pdf.php`) and everything else in `app/` is original code written for this project.

<?php
/**
 * Local development router for PHP's built-in web server.
 *   php -S localhost:8000 router.php
 * The built-in server ignores .htaccess, so this file blocks private paths the way Apache would.
 * It is NOT used (and not needed) on Apache/InfinityFree.
 */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$path = rawurldecode($path);
if (preg_match('~^/(app|config|database|storage|tools|docs)(/|$)~i', $path)
    || preg_match('~(^|/)\.(?!well-known)~', $path)
    || preg_match('~\.(env|sql|md|log|lock|example)$~i', $path)
    || $path === '/router.php') {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}
return false;   // serve the requested file or fall through to index.php

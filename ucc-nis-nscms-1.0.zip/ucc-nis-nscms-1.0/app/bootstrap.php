<?php
declare(strict_types=1);

define('APP_ROOT', dirname(__DIR__));
const APP_VERSION = '1.0.0';
const TERMS_VERSION = '1.0';

spl_autoload_register(static function (string $class): void {
    if (strncmp($class, 'App\\', 4) !== 0) return;
    $file = APP_ROOT . '/app/' . str_replace('\\', '/', substr($class, 4)) . '.php';
    if (is_file($file)) require $file;
});

require APP_ROOT . '/app/Core/helpers.php';

use App\Core\{Env, Security, Session, View};

// Optional: keep the env file outside the web root and point to it with the NIS_ENV_FILE server variable.
if (!Env::load((string)(getenv('NIS_ENV_FILE') ?: APP_ROOT . '/.env'))) {
    if (is_file(APP_ROOT . '/install/index.php') && !is_file(APP_ROOT . '/storage/installed.lock')) {
        header('Location: ' . base_path() . '/install/index.php');
        exit;
    }
    http_response_code(503);
    exit('Application is not configured. Copy .env.example to .env and fill in the database settings.');
}

date_default_timezone_set(Env::get('APP_TIMEZONE', 'Africa/Accra') ?: 'Africa/Accra');
mb_internal_encoding('UTF-8');

$debug = !Env::isProduction() && Env::bool('APP_DEBUG');
ini_set('display_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', APP_ROOT . '/storage/logs/php-error.log');
error_reporting(E_ALL);

set_exception_handler(static function (\Throwable $e) use ($debug): void {
    error_log(sprintf("[%s] %s in %s:%d\n%s", date('c'), $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString()));
    if (!headers_sent()) http_response_code(500);
    if (ob_get_level() > 0) ob_end_clean();
    try {
        View::$title = 'Something went wrong';
        View::render('errors/error', [
            'code' => 500, 'heading' => 'Something went wrong',
            'message' => $debug ? $e->getMessage() : 'An unexpected error occurred. It has been logged for the NIS team.',
        ], 'auth');
    } catch (\Throwable) {
        echo 'An unexpected error occurred.';
    }
});

Security::headers();
Session::start();

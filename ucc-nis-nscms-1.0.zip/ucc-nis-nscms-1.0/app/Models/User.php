<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Db;

final class User
{
    /** Roles the acting user is allowed to create/manage. */
    public static function manageableRoles(array $actor): array
    {
        return match ($actor['role']) {
            'super_admin' => ['super_admin', 'nis_admin', 'technician', 'department_rep'],
            'nis_admin'   => ['technician', 'department_rep'],
            default       => [],
        };
    }

    public static function find(int $id): ?array
    {
        return Db::one('SELECT u.id, u.role_id, u.department_id, u.full_name, u.email, u.phone, u.is_active, u.must_change_password,
                               u.last_login_at, u.created_at, r.slug AS role, r.name AS role_name, d.name AS department_name
                          FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN departments d ON d.id = u.department_id WHERE u.id = ?', [$id]);
    }

    public static function roles(array $slugs): array
    {
        return Db::all('SELECT id, slug, name FROM roles WHERE slug IN (' . Db::marks($slugs) . ') ORDER BY id', $slugs);
    }

    public static function technicians(bool $activeOnly = true): array
    {
        return Db::all("SELECT u.id, u.full_name, u.email FROM users u JOIN roles r ON r.id = u.role_id
                         WHERE r.slug = 'technician'" . ($activeOnly ? ' AND u.is_active = 1' : '') . ' ORDER BY u.full_name');
    }

    /** Active staff who should receive new-complaint alerts. */
    public static function staffIds(): array
    {
        return array_map('intval', array_column(Db::all("SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
                         WHERE r.slug IN ('nis_admin','super_admin') AND u.is_active = 1"), 'id'));
    }

    public static function departmentRepIds(int $departmentId): array
    {
        return array_map('intval', array_column(Db::all("SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
                         WHERE r.slug = 'department_rep' AND u.department_id = ? AND u.is_active = 1", [$departmentId]), 'id'));
    }

    public static function emailTaken(string $email, int $exceptId = 0): bool
    {
        return (bool)Db::val('SELECT 1 FROM users WHERE email = ? AND id <> ?', [strtolower($email), $exceptId]);
    }

    public static function activeSuperAdmins(): int
    {
        return (int)Db::val("SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.slug = 'super_admin' AND u.is_active = 1");
    }
}

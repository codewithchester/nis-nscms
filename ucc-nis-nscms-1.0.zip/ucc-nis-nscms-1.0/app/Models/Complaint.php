<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Db;
use App\Services\Workflow;

final class Complaint
{
    private const BASE = 'FROM complaints c
        JOIN departments d ON d.id = c.department_id
        JOIN complaint_categories cat ON cat.id = c.category_id
        LEFT JOIN users t ON t.id = c.assigned_to';
    private const COLS = 'c.*, d.name AS department_name, d.code AS department_code, cat.name AS category_name, t.full_name AS technician_name';

    /** Row-level visibility. Department isolation and technician assignment are enforced here, by role, always. */
    public static function scope(array $u): array
    {
        return match ($u['role']) {
            'department_rep' => ['c.department_id = ?', [(int)($u['department_id'] ?? 0)]],
            'technician'     => ["EXISTS (SELECT 1 FROM complaint_assignments ca WHERE ca.complaint_id = c.id AND ca.technician_id = ? AND ca.status IN ('Active','Completed'))", [(int)$u['id']]],
            'nis_admin', 'super_admin' => ['1=1', []],
            default          => ['1=0', []],
        };
    }

    public static function find(int $id, array $u): ?array
    {
        [$sc, $sp] = self::scope($u);
        return Db::one('SELECT ' . self::COLS . ' ' . self::BASE . " WHERE c.id = ? AND $sc", array_merge([$id], $sp));
    }

    public static function findByReference(string $ref, array $u): ?array
    {
        [$sc, $sp] = self::scope($u);
        return Db::one('SELECT ' . self::COLS . ' ' . self::BASE . " WHERE c.reference_no = ? AND $sc", array_merge([$ref], $sp));
    }

    public static function accessible(int $id, array $u): bool
    {
        [$sc, $sp] = self::scope($u);
        return (bool)Db::val("SELECT 1 FROM complaints c WHERE c.id = ? AND $sc", array_merge([$id], $sp));
    }

    public static function isOverdue(array $c): bool
    {
        return !in_array($c['status'], Workflow::NOT_OUTSTANDING, true) && strtotime((string)$c['due_at']) < time();
    }

    public const SORTS = [
        'reference' => 'c.reference_no', 'title' => 'c.title', 'department' => 'd.name', 'category' => 'cat.name',
        'priority' => 'c.priority', 'status' => 'c.status', 'technician' => 't.full_name',
        'reported' => 'c.reported_at', 'created' => 'c.created_at', 'updated' => 'c.updated_at', 'due' => 'c.due_at',
    ];

    /** @return array{rows:array,total:int,pages:int,page:int} */
    public static function search(array $u, array $f, string $sort, string $dir, int $page, int $per): array
    {
        [$sc, $sp] = self::scope($u);
        $where = [$sc];
        $p = $sp;
        $staff = in_array($u['role'], ['super_admin', 'nis_admin'], true);

        if (($f['q'] ?? '') !== '') {
            $like = '%' . addcslashes($f['q'], '%_\\') . '%';
            $where[] = '(c.reference_no LIKE ? OR c.title LIKE ? OR c.reporter_name LIKE ? OR c.building LIKE ? OR c.room LIKE ?)';
            array_push($p, $like, $like, $like, $like, $like);
        }
        if (in_array($f['status'] ?? '', Workflow::STATUSES, true)) { $where[] = 'c.status = ?'; $p[] = $f['status']; }
        if (in_array($f['priority'] ?? '', Workflow::PRIORITIES, true)) { $where[] = 'c.priority = ?'; $p[] = $f['priority']; }
        if ((int)($f['category'] ?? 0) > 0) { $where[] = 'c.category_id = ?'; $p[] = (int)$f['category']; }
        if ($staff && (int)($f['department'] ?? 0) > 0) { $where[] = 'c.department_id = ?'; $p[] = (int)$f['department']; }
        if ($staff && (int)($f['technician'] ?? 0) > 0) { $where[] = 'c.assigned_to = ?'; $p[] = (int)$f['technician']; }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f['from'] ?? '')) { $where[] = 'c.created_at >= ?'; $p[] = $f['from'] . ' 00:00:00'; }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f['to'] ?? '')) { $where[] = 'c.created_at < ?'; $p[] = date('Y-m-d', strtotime($f['to'] . ' +1 day')) . ' 00:00:00'; }
        if (($f['overdue'] ?? '') === '1') {
            $where[] = "c.status NOT IN ('Awaiting Department Response','Resolved','Closed','Rejected') AND c.due_at < NOW()";
        }

        $sortCol = self::SORTS[$sort] ?? self::SORTS['created'];
        $dir = strtolower($dir) === 'asc' ? 'ASC' : 'DESC';
        $w = implode(' AND ', $where);

        $total = (int)Db::val("SELECT COUNT(*) " . self::BASE . " WHERE $w", $p);
        $pages = max(1, (int)ceil($total / $per));
        $page = min(max(1, $page), $pages);
        $offset = ($page - 1) * $per;
        $rows = Db::all('SELECT ' . self::COLS . ' ' . self::BASE . " WHERE $w ORDER BY $sortCol $dir, c.id DESC LIMIT " . (int)$per . ' OFFSET ' . (int)$offset, $p);
        return ['rows' => $rows, 'total' => $total, 'pages' => $pages, 'page' => $page];
    }

    public static function comments(int $id, bool $includeInternal): array
    {
        return Db::all('SELECT cm.*, u.full_name, r.slug AS role, r.name AS role_name
                          FROM complaint_comments cm JOIN users u ON u.id = cm.user_id JOIN roles r ON r.id = u.role_id
                         WHERE cm.complaint_id = ?' . ($includeInternal ? '' : ' AND cm.is_internal = 0') . ' ORDER BY cm.created_at, cm.id', [$id]);
    }

    public static function history(int $id): array
    {
        return Db::all('SELECT h.*, u.full_name, r.name AS role_name FROM complaint_status_history h
                          JOIN users u ON u.id = h.changed_by JOIN roles r ON r.id = u.role_id
                         WHERE h.complaint_id = ? ORDER BY h.created_at, h.id', [$id]);
    }

    public static function assignments(int $id): array
    {
        return Db::all('SELECT a.*, t.full_name AS technician_name, b.full_name AS assigner_name
                          FROM complaint_assignments a JOIN users t ON t.id = a.technician_id JOIN users b ON b.id = a.assigned_by
                         WHERE a.complaint_id = ? ORDER BY a.assigned_at DESC, a.id DESC', [$id]);
    }

    public static function attachments(int $id, bool $includeInternal): array
    {
        return Db::all('SELECT a.id, a.original_name, a.size_bytes, a.created_at, a.comment_id, u.full_name
                          FROM attachments a JOIN users u ON u.id = a.uploaded_by
                          LEFT JOIN complaint_comments cm ON cm.id = a.comment_id
                         WHERE a.complaint_id = ?' . ($includeInternal ? '' : ' AND (cm.id IS NULL OR cm.is_internal = 0)') . ' ORDER BY a.id', [$id]);
    }

    public static function categories(bool $activeOnly = true): array
    {
        return Db::all('SELECT id, name, is_active FROM complaint_categories' . ($activeOnly ? ' WHERE is_active = 1' : '') . ' ORDER BY sort_order, name');
    }
}

<?php
declare(strict_types=1);

namespace App\Models;

use App\Core\Db;

final class Department
{
    public static function find(int $id): ?array
    {
        return Db::one('SELECT * FROM departments WHERE id = ?', [$id]);
    }

    public static function options(bool $activeOnly = true): array
    {
        return Db::all('SELECT id, name, code FROM departments' . ($activeOnly ? ' WHERE is_active = 1' : '') . ' ORDER BY name');
    }

    public static function stats(int $id): array
    {
        return Db::one("SELECT COUNT(*) AS total,
                SUM(status IN ('Resolved','Closed')) AS resolved,
                SUM(status NOT IN ('Resolved','Closed','Rejected')) AS open_count,
                SUM(status = 'Rejected') AS rejected,
                AVG(CASE WHEN resolved_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, created_at, resolved_at) / 60 END) AS avg_hours
              FROM complaints WHERE department_id = ?", [$id]) ?? [];
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

final class Audit
{
    /** Record a security-relevant event. Never pass passwords, tokens or other secrets in $details. */
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, array $details = [], ?int $userId = null): void
    {
        try {
            $userId ??= (Auth::user()['id'] ?? null);
            Db::exec(
                'INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, ip_address, user_agent) VALUES (?,?,?,?,?,?,?)',
                [$userId, $action, $entityType, $entityId, $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null, Request::ip(), Request::userAgent()]
            );
        } catch (\Throwable $e) {
            error_log('[audit] ' . $e->getMessage());
        }
    }
}

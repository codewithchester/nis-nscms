<?php
declare(strict_types=1);

namespace App\Core;

final class Security
{
    public static function headers(): void
    {
        if (headers_sent()) return;
        $extra = trim((string)Env::get('CSP_EXTRA_SCRIPT_SRC', ''));   // only if the host injects its own scripts
        $csp = "default-src 'self'; script-src 'self'" . ($extra !== '' ? ' ' . $extra : '') .
               "; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; " .
               "object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'";
        header('Content-Security-Policy: ' . $csp);
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
        header('Cross-Origin-Opener-Policy: same-origin');
        header('X-Permitted-Cross-Domain-Policies: none');
        header_remove('X-Powered-By');
        if (Request::isHttps()) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
    }
}

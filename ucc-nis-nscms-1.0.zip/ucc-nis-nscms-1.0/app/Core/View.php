<?php
declare(strict_types=1);

namespace App\Core;

final class View
{
    public static string $title = "";
    public static bool $wide = false;

    public static function render(string $view, array $data = [], string $layout = 'app'): void
    {
        $file = APP_ROOT . '/app/Views/' . $view . '.php';
        if (!is_file($file)) throw new \RuntimeException("View not found: $view");
        extract($data, EXTR_SKIP);
        ob_start();
        require $file;
        $content = ob_get_clean();
        if ($layout === '') { echo $content; return; }
        require APP_ROOT . '/app/Views/layouts/' . $layout . '.php';
    }

    public static function partial(string $name, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        require APP_ROOT . '/app/Views/partials/' . $name . '.php';
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Tiny dependency-free PDF writer (A4, Helvetica) for text reports and tables.
 * Runs on any PHP host: no Composer, no extensions beyond mbstring/iconv.
 */
final class Pdf
{
    // Helvetica glyph widths (1/1000 em) for ASCII 32..126
    private const W = [278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];

    private array $pages = [];
    private string $buf = '';
    private float $y = 0;
    public float $pw = 595.28, $ph = 841.89, $m = 40;
    private string $footer;

    public function __construct(private bool $landscape = false, string $footer = '')
    {
        if ($landscape) { [$this->pw, $this->ph] = [$this->ph, $this->pw]; }
        $this->footer = $footer;
        $this->addPage();
    }

    public function addPage(): void
    {
        if ($this->buf !== '') $this->pages[] = $this->buf;
        $this->buf = '';
        $this->y = $this->m;
    }

    private function enc(string $s): string
    {
        $s = str_replace(["\r", "\t"], ['', ' '], $s);
        $s = preg_replace('/[^\P{C}\n]+/u', '', $s) ?? $s;
        $c = function_exists('mb_convert_encoding') ? mb_convert_encoding($s, 'Windows-1252', 'UTF-8') : (iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s) ?: $s);
        return $c;
    }

    private function esc(string $s): string { return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s); }

    public function width(string $s, float $size): float
    {
        $w = 0;
        foreach (str_split($this->enc($s)) as $ch) {
            $o = ord($ch);
            $w += ($o >= 32 && $o <= 126) ? self::W[$o - 32] : 556;
        }
        return $w * $size / 1000;
    }

    private function fit(string $s, float $max, float $size): string
    {
        $s = preg_replace('/\s+/', ' ', $s) ?? $s;
        if ($this->width($s, $size) <= $max) return $s;
        while ($s !== '' && $this->width($s . '...', $size) > $max) $s = mb_substr($s, 0, -1);
        return $s . '...';
    }

    /** Word-wrap to width. */
    public function wrap(string $text, float $max, float $size): array
    {
        $lines = [];
        foreach (preg_split('/\R/', $text) ?: [''] as $para) {
            $line = '';
            foreach (preg_split('/\s+/', trim($para)) ?: [] as $word) {
                $try = $line === '' ? $word : $line . ' ' . $word;
                if ($this->width($try, $size) <= $max) { $line = $try; continue; }
                if ($line !== '') $lines[] = $line;
                while ($this->width($word, $size) > $max && mb_strlen($word) > 1) {
                    $cut = $word;
                    while ($this->width($cut, $size) > $max && mb_strlen($cut) > 1) $cut = mb_substr($cut, 0, -1);
                    $lines[] = $cut;
                    $word = mb_substr($word, mb_strlen($cut));
                }
                $line = $word;
            }
            $lines[] = $line;
        }
        return $lines;
    }

    private function ensure(float $h): void
    {
        if ($this->y + $h > $this->ph - $this->m - 14) $this->addPage();
    }

    private function put(float $x, float $y, string $s, float $size, bool $bold = false, array $rgb = [0, 0, 0]): void
    {
        $this->buf .= sprintf("BT /%s %.2f Tf %.3f %.3f %.3f rg %.2f %.2f Td (%s) Tj ET\n", $bold ? 'F2' : 'F1', $size, $rgb[0], $rgb[1], $rgb[2], $x, $this->ph - $y, $this->esc($this->enc($s)));
    }

    private function rect(float $x, float $y, float $w, float $h, array $fill): void
    {
        $this->buf .= sprintf("%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f\n", $fill[0], $fill[1], $fill[2], $x, $this->ph - $y - $h, $w, $h);
    }

    private function line(float $x1, float $y, float $x2, array $rgb = [0.8, 0.8, 0.8]): void
    {
        $this->buf .= sprintf("%.3f %.3f %.3f RG 0.5 w %.2f %.2f m %.2f %.2f l S\n", $rgb[0], $rgb[1], $rgb[2], $x1, $this->ph - $y, $x2, $this->ph - $y);
    }

    // ------------------------------------------------------------ public layout API
    public function letterhead(string $org, string $unit, string $docTitle): void
    {
        $this->rect($this->m, $this->y, $this->pw - 2 * $this->m, 54, [0.09, 0.29, 0.45]);
        $this->rect($this->m + 10, $this->y + 9, 36, 36, [1, 1, 1]);
        $this->put($this->m + 17, $this->y + 31, 'LOGO', 8, true, [0.09, 0.29, 0.45]);
        $this->put($this->m + 58, $this->y + 22, $org, 14, true, [1, 1, 1]);
        $this->put($this->m + 58, $this->y + 38, $unit, 9.5, false, [0.95, 0.85, 0.6]);
        $this->y += 68;
        $this->put($this->m, $this->y + 12, $docTitle, 16, true, [0.12, 0.12, 0.14]);
        $this->y += 24;
    }

    public function heading(string $t): void
    {
        $this->ensure(30);
        $this->y += 8;
        $this->put($this->m, $this->y + 10, $t, 11.5, true, [0.09, 0.29, 0.45]);
        $this->y += 15;
        $this->line($this->m, $this->y, $this->pw - $this->m, [0.78, 0.59, 0.18]);
        $this->y += 6;
    }

    public function text(string $t, float $size = 9.5, bool $bold = false, array $rgb = [0.15, 0.15, 0.18]): void
    {
        foreach ($this->wrap($t, $this->pw - 2 * $this->m, $size) as $l) {
            $this->ensure($size + 4);
            $this->put($this->m, $this->y + $size, $l, $size, $bold, $rgb);
            $this->y += $size + 3.5;
        }
    }

    /** Label/value rows laid out in two columns. */
    public function kv(array $pairs, int $cols = 2): void
    {
        $colW = ($this->pw - 2 * $this->m) / $cols;
        $i = 0;
        $rowH = 0;
        foreach ($pairs as $label => $value) {
            $col = $i % $cols;
            if ($col === 0) { $this->y += $rowH; $rowH = 0; $this->ensure(36); }
            $x = $this->m + $col * $colW;
            $this->put($x, $this->y + 8, (string)$label, 7.5, false, [0.45, 0.45, 0.5]);
            $lines = array_slice($this->wrap((string)$value, $colW - 12, 9.5), 0, 3);
            $yy = $this->y + 19;
            foreach ($lines as $l) { $this->put($x, $yy, $l, 9.5, true); $yy += 11.5; }
            $rowH = max($rowH, 12 + 11.5 * max(1, count($lines)) + 6);
            $i++;
        }
        $this->y += $rowH + 2;
    }

    /** @param string[] $headers @param array<int,string[]> $rows @param float[] $weights relative column widths */
    public function table(array $headers, array $rows, array $weights, float $size = 8): void
    {
        $total = $this->pw - 2 * $this->m;
        $sum = array_sum($weights);
        $w = array_map(fn($x) => $total * $x / $sum, $weights);
        $head = function () use ($headers, $w, $size, $total): void {
            $this->ensure(20);
            $this->rect($this->m, $this->y, $total, 16, [0.93, 0.9, 0.86]);
            $x = $this->m;
            foreach ($headers as $i => $h) { $this->put($x + 4, $this->y + 11, $this->fit($h, $w[$i] - 8, $size), $size, true, [0.2, 0.1, 0.12]); $x += $w[$i]; }
            $this->y += 17;
        };
        $head();
        if (!$rows) { $this->put($this->m + 4, $this->y + 12, 'No records.', $size, false, [0.45, 0.45, 0.5]); $this->y += 18; return; }
        foreach ($rows as $n => $row) {
            if ($this->y + 16 > $this->ph - $this->m - 14) { $this->addPage(); $head(); }
            if ($n % 2 === 1) $this->rect($this->m, $this->y - 1, $total, 14, [0.975, 0.97, 0.96]);
            $x = $this->m;
            foreach ($row as $i => $cell) { $this->put($x + 4, $this->y + 9, $this->fit((string)$cell, $w[$i] - 8, $size), $size); $x += $w[$i]; }
            $this->y += 14;
        }
        $this->y += 4;
    }

    public function space(float $h = 6): void { $this->y += $h; }

    public function output(): string
    {
        $this->pages[] = $this->buf;
        $this->buf = '';
        $n = count($this->pages);
        $objs = [];
        $objs[1] = '<< /Type /Catalog /Pages 2 0 R >>';
        $kids = [];
        for ($i = 0; $i < $n; $i++) $kids[] = (5 + $i * 2) . ' 0 R';
        $objs[2] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . $n . ' >>';
        $objs[3] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
        $objs[4] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>';
        foreach ($this->pages as $i => $content) {
            $foot = sprintf("BT /F1 7.5 Tf 0.45 0.45 0.5 rg %.2f %.2f Td (%s) Tj ET\nBT /F1 7.5 Tf 0.45 0.45 0.5 rg %.2f %.2f Td (Page %d of %d) Tj ET\n",
                $this->m, 24, $this->esc($this->enc($this->footer)), $this->pw - $this->m - 50, 24, $i + 1, $n);
            $content .= $foot;
            $pid = 5 + $i * 2;
            $objs[$pid] = sprintf('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.2f %.2f] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents %d 0 R >>', $this->pw, $this->ph, $pid + 1);
            $objs[$pid + 1] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";
        }
        ksort($objs);
        $out = "%PDF-1.4\n";
        $offsets = [];
        foreach ($objs as $id => $body) {
            $offsets[$id] = strlen($out);
            $out .= "$id 0 obj\n$body\nendobj\n";
        }
        $xref = strlen($out);
        $max = max(array_keys($objs));
        $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) $out .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
        $out .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";
        return $out;
    }

    public function download(string $filename): never
    {
        $data = $this->output();
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._-]/', '_', $filename) . '"');
        header('Content-Length: ' . strlen($data));
        echo $data;
        exit;
    }
}

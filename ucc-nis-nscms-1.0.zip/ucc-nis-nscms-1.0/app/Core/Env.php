<?php
declare(strict_types=1);

namespace App\Core;

/** Minimal .env loader. Values live only on the server and are never sent to the browser. */
final class Env
{
    private static array $vars = [];
    private static bool $loaded = false;

    public static function load(string $file): bool
    {
        if (!is_file($file) || !is_readable($file)) {
            return false;
        }
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#' || !str_contains($line, '=')) {
                continue;
            }
            [$k, $v] = explode('=', $line, 2);
            $k = trim($k);
            $v = trim($v);
            if (strlen($v) >= 2 && (($v[0] === '"' && substr($v, -1) === '"') || ($v[0] === "'" && substr($v, -1) === "'"))) {
                $v = substr($v, 1, -1);
            }
            self::$vars[$k] = $v;
        }
        self::$loaded = true;
        return true;
    }

    public static function loaded(): bool { return self::$loaded; }

    public static function get(string $key, ?string $default = null): ?string
    {
        return self::$vars[$key] ?? $default;
    }

    public static function bool(string $key, bool $default = false): bool
    {
        $v = self::$vars[$key] ?? null;
        return $v === null ? $default : in_array(strtolower($v), ['1', 'true', 'yes', 'on'], true);
    }

    public static function isProduction(): bool
    {
        return strtolower(self::get('APP_ENV', 'production') ?? 'production') === 'production';
    }
}

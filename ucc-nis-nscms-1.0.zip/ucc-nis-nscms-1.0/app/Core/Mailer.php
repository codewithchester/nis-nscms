<?php
declare(strict_types=1);

namespace App\Core;

/**
 * Email delivery. Credentials are read from .env on the server only.
 * MAIL_DRIVER=log  -> messages are written to storage/logs/mail.log (default; ideal for local testing)
 * MAIL_DRIVER=smtp -> sent over SMTP (TLS/SSL) when the "Email notifications" setting is switched on.
 * Email is never required: failures are logged and the caller carries on.
 */
final class Mailer
{
    public static function send(string $to, string $subject, string $html, string $text): bool
    {
        $to = self::clean($to);
        $subject = self::clean($subject);
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) return false;

        $driver = strtolower((string)Env::get('MAIL_DRIVER', 'log'));
        if ($driver === 'smtp') {
            if (!(bool)Settings::get('email_enabled', '0')) return false;
            try {
                return self::smtp($to, $subject, $html, $text);
            } catch (\Throwable $e) {
                error_log('[mail] ' . $e->getMessage());
                return false;
            }
        }
        // log driver
        $entry = sprintf("=== %s ===\nTo: %s\nSubject: %s\n\n%s\n\n", date('c'), $to, $subject, $text);
        @file_put_contents(APP_ROOT . '/storage/logs/mail.log', $entry, FILE_APPEND | LOCK_EX);
        return true;
    }

    private static function clean(string $v): string { return trim(str_replace(["\r", "\n", "\0"], '', $v)); }

    private static function smtp(string $to, string $subject, string $html, string $text): bool
    {
        $host = (string)Env::get('MAIL_HOST', '');
        $port = (int)Env::get('MAIL_PORT', '587');
        $enc = strtolower((string)Env::get('MAIL_ENCRYPTION', 'tls'));
        $user = (string)Env::get('MAIL_USERNAME', '');
        $pass = (string)Env::get('MAIL_PASSWORD', '');
        $from = self::clean((string)Env::get('MAIL_FROM_ADDRESS', $user));
        $fromName = self::clean((string)Env::get('MAIL_FROM_NAME', 'UCC NIS Support'));
        if ($host === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) throw new \RuntimeException('SMTP is not configured.');

        $remote = ($enc === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
        $fp = @stream_socket_client($remote, $errno, $errstr, 8, STREAM_CLIENT_CONNECT);
        if (!$fp) throw new \RuntimeException("SMTP connect failed: $errstr");
        stream_set_timeout($fp, 8);

        $read = function () use ($fp): string {
            $data = '';
            while (($line = fgets($fp, 515)) !== false) {
                $data .= $line;
                if (strlen($line) < 4 || $line[3] === ' ') break;
            }
            return $data;
        };
        $cmd = function (string $c, array $ok) use ($fp, $read): string {
            fwrite($fp, $c . "\r\n");
            $r = $read();
            if (!in_array((int)substr($r, 0, 3), $ok, true)) throw new \RuntimeException('SMTP error after command: ' . substr($r, 0, 120));
            return $r;
        };

        if ((int)substr($read(), 0, 3) !== 220) throw new \RuntimeException('SMTP greeting failed.');
        $ehlo = (string)preg_replace('/[^a-zA-Z0-9.-]/', '', (string)($_SERVER['SERVER_NAME'] ?? 'localhost')) ?: 'localhost';
        $cmd('EHLO ' . $ehlo, [250]);
        if ($enc === 'tls') {
            $cmd('STARTTLS', [220]);
            if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT)) throw new \RuntimeException('STARTTLS failed.');
            $cmd('EHLO ' . $ehlo, [250]);
        }
        if ($user !== '') {
            $cmd('AUTH LOGIN', [334]);
            $cmd(base64_encode($user), [334]);
            $cmd(base64_encode($pass), [235]);
        }
        $cmd('MAIL FROM:<' . $from . '>', [250]);
        $cmd('RCPT TO:<' . $to . '>', [250, 251]);
        $cmd('DATA', [354]);

        $boundary = 'b' . bin2hex(random_bytes(8));
        $headers = [
            'Date: ' . date('r'),
            'From: ' . '=?UTF-8?B?' . base64_encode($fromName) . '?= <' . $from . '>',
            'To: <' . $to . '>',
            'Subject: =?UTF-8?B?' . base64_encode($subject) . '?=',
            'MIME-Version: 1.0',
            'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $ehlo . '>',
            'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        ];
        $body = "--$boundary\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($text)) .
                "--$boundary\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n" . chunk_split(base64_encode($html)) .
                "--$boundary--\r\n";
        $data = implode("\r\n", $headers) . "\r\n\r\n" . $body;
        $data = preg_replace('/^\./m', '..', $data);   // dot-stuffing
        fwrite($fp, $data . "\r\n.\r\n");
        $r = $read();
        $cmd('QUIT', [221, 250]);
        fclose($fp);
        return (int)substr($r, 0, 3) === 250;
    }
}

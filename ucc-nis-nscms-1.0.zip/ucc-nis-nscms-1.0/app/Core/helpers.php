<?php
declare(strict_types=1);

use App\Core\{Auth, Csrf, Env, Form, Request, Settings, View};

function e(mixed $v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function base_path(): string
{
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/index.php'));
    return $dir === '/' || $dir === '.' ? '' : rtrim($dir, '/');
}

/** Internal link. Routes are query-string based so the app works on any host without rewrite rules. */
function url(string $route = '', array $query = []): string
{
    $rest = http_build_query(array_filter($query, fn($v) => $v !== null && $v !== ''), '', '&', PHP_QUERY_RFC3986);
    $qs = ($route !== '' ? 'r=' . $route : '') . ($route !== '' && $rest !== '' ? '&' : '') . $rest;   // route names are [a-z0-9/_-] only
    return base_path() . '/index.php' . ($qs !== '' ? '?' . $qs : '');
}

/** Absolute link (used in emails). Prefers APP_URL from .env. */
function abs_url(string $route = '', array $query = []): string
{
    $root = rtrim((string)Env::get('APP_URL', ''), '/');
    if ($root === '') {
        $root = (Request::isHttps() ? 'https' : 'http') . '://' . preg_replace('/[^a-zA-Z0-9.:-]/', '', (string)($_SERVER['HTTP_HOST'] ?? 'localhost')) . base_path();
    }
    return $root . substr(url($route, $query), strlen(base_path()));
}

function asset(string $path): string
{
    $file = APP_ROOT . '/assets/' . $path;
    return base_path() . '/assets/' . $path . (is_file($file) ? '?v=' . filemtime($file) : '');
}

function redirect(string $route, array $query = []): never
{
    header('Location: ' . url($route, $query));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = [$type, $message];
}

function pull_flash(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

function old(string $key, mixed $default = ''): string { return (string)Form::old($key, $default); }
function field_error(string $key): ?string { return Form::error($key); }

/** Adds is-invalid when the field has an error. */
function invalid(string $key): string { return Form::error($key) ? ' is-invalid' : ''; }

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function auth_user(): ?array { return Auth::user(); }
function can(string $perm): bool { return Auth::can($perm); }
/** Only department representatives file complaints (they belong to a department); admins and technicians never do. */
function can_report(): bool { return (Auth::user()['role'] ?? '') === 'department_rep' && Auth::can('complaints.create'); }
function setting(string $key, mixed $default = null): mixed { return Settings::get($key, $default); }

function abort(int $code, string $message = ''): never
{
    $titles = [403 => 'Access denied', 404 => 'Page not found', 405 => 'Method not allowed', 419 => 'Session expired', 429 => 'Too many requests', 500 => 'Something went wrong'];
    $defaults = [
        403 => 'You do not have permission to do that.',
        404 => 'The page or record you asked for does not exist, or you do not have access to it.',
        405 => 'That action is not supported.',
        419 => 'Your form session expired or was invalid. Go back, refresh the page and try again.',
        500 => 'An unexpected error occurred. It has been logged.',
    ];
    http_response_code($code);
    if (!headers_sent()) header('Cache-Control: no-store');
    View::$title = $titles[$code] ?? 'Error';
    View::render('errors/error', ['code' => $code, 'heading' => $titles[$code] ?? 'Error', 'message' => $message ?: ($defaults[$code] ?? '')],
        Auth::check() ? 'app' : 'auth');
    exit;
}

function fmt_dt(?string $s, string $fmt = 'd M Y, H:i'): string
{
    if (!$s) return '—';
    $t = strtotime($s);
    return $t ? date($fmt, $t) : '—';
}

function fmt_d(?string $s): string { return fmt_dt($s, 'd M Y'); }

function ago(?string $s): string
{
    if (!$s) return '—';
    $d = time() - (int)strtotime($s);
    if ($d < 60) return 'just now';
    if ($d < 3600) return floor($d / 60) . ' min ago';
    if ($d < 86400) return floor($d / 3600) . ' hr ago';
    if ($d < 86400 * 7) return floor($d / 86400) . ' d ago';
    return fmt_d($s);
}

function hours_label(null|int|float|string $h): string
{
    if ($h === null || $h === '') return '—';
    $h = (float)$h;
    if ($h < 1) return round($h * 60) . ' min';
    if ($h < 48) return round($h, 1) . ' hr';
    return round($h / 24, 1) . ' days';
}

function status_badge(string $status): string
{
    return '<span class="pill st-' . e(strtolower(str_replace(' ', '-', $status))) . '">' . e($status) . '</span>';
}

function priority_badge(string $p): string
{
    return '<span class="prio prio-' . e(strtolower($p)) . '">' . e($p) . '</span>';
}

function icon(string $name): string { return '<i class="bi bi-' . e($name) . '" aria-hidden="true"></i>'; }

/** JSON for a data-* attribute (read by assets/js/app.js; no inline scripts needed, so CSP stays strict). */
function json_attr(array $data): string
{
    return e(json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
}

function sort_link(string $route, array $query, string $key, string $label, string $curSort, string $curDir): string
{
    $dir = ($curSort === $key && $curDir === 'asc') ? 'desc' : 'asc';
    $arrow = $curSort === $key ? ($curDir === 'asc' ? ' <i class="bi bi-caret-up-fill" aria-hidden="true"></i>' : ' <i class="bi bi-caret-down-fill" aria-hidden="true"></i>') : '';
    $q = array_merge($query, ['sort' => $key, 'dir' => $dir, 'page' => 1]);
    return '<a class="sort" href="' . e(url($route, $q)) . '">' . e($label) . $arrow . '</a>';
}

function mask_email(string $e): string
{
    [$a, $b] = array_pad(explode('@', $e, 2), 2, '');
    return substr($a, 0, 2) . str_repeat('*', max(1, strlen($a) - 2)) . '@' . $b;
}

function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name)) ?: [];
    $s = '';
    foreach (array_slice($parts, 0, 2) as $p) $s .= mb_strtoupper(mb_substr($p, 0, 1));
    return $s ?: '?';
}

function human_size(int $bytes): string
{
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024) . ' KB';
    return $bytes . ' B';
}

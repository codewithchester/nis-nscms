<?php
declare(strict_types=1);

namespace App\Core;

/** Carries old input and validation errors across a redirect (one request only). */
final class Form
{
    private static ?array $old = null;
    private static ?array $errors = null;

    public static function remember(array $input, array $errors): void
    {
        foreach (['password', 'password_confirm', 'current_password', 'new_password', 'new_password_confirm', '_csrf'] as $k) unset($input[$k]);
        $_SESSION['_old'] = $input;
        $_SESSION['_errors'] = $errors;
    }

    private static function load(): void
    {
        if (self::$old === null) {
            self::$old = $_SESSION['_old'] ?? [];
            self::$errors = $_SESSION['_errors'] ?? [];
            unset($_SESSION['_old'], $_SESSION['_errors']);
        }
    }

    public static function old(string $key, mixed $default = ''): mixed { self::load(); return self::$old[$key] ?? $default; }
    public static function error(string $key): ?string { self::load(); return self::$errors[$key] ?? null; }
    public static function errors(): array { self::load(); return self::$errors ?? []; }
}

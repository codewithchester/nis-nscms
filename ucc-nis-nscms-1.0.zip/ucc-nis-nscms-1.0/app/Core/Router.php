<?php
declare(strict_types=1);

namespace App\Core;

final class Router
{
    private const OPEN_WHEN_RESTRICTED = ['auth/logout', 'account/password', 'account/terms', 'account/terms/accept'];

    public static function dispatch(array $routes): void
    {
        $route = trim((string)($_GET['r'] ?? ''), '/');
        if (!preg_match('~^[a-z0-9/_-]{0,50}$~', $route)) abort(404);
        if ($route === '') redirect(Auth::check() ? 'dashboard' : 'auth/login');

        $def = $routes[$route] ?? null;
        if ($def === null) abort(404);
        [$handler, $methods, $access] = $def;

        $method = Request::method();
        if (!in_array($method, $methods, true)) {
            header('Allow: ' . implode(', ', $methods));
            abort(405);
        }
        if ($method === 'POST' && !Csrf::valid()) {
            Audit::log('csrf.rejected', null, null, ['route' => $route]);
            abort(419);
        }

        $user = Auth::user();

        if ($access === 'guest' && $user) redirect('dashboard');

        if ($access !== 'public' && $access !== 'guest') {
            if (!$user) {
                if ($method === 'GET') {
                    $_SESSION['intended'] = ['r' => $route, 'id' => Request::intGet('id')];
                }
                redirect('auth/login');
            }
            if (!in_array($route, self::OPEN_WHEN_RESTRICTED, true)) {
                if ((int)$user['must_change_password'] === 1) redirect('account/password');
                if (($user['terms_version'] ?? '') !== TERMS_VERSION) redirect('account/terms');
            }
            if (is_array($access)) {
                if (isset($access['perm']) && !Auth::can($access['perm'])) { Audit::log('access.denied', null, null, ['route' => $route]); abort(403); }
                if (isset($access['role']) && !in_array($user['role'], $access['role'], true)) { Audit::log('access.denied', null, null, ['route' => $route]); abort(403); }
            }
        }

        [$class, $action] = explode('@', $handler);
        $fqcn = 'App\\Controllers\\' . $class;
        (new $fqcn())->$action();
    }
}

<?php
declare(strict_types=1);

namespace App\Core;

final class Auth
{
    private const DUMMY_HASH = '$2y$10$EC2URHaiI5ZxgrQZRaijiulHWcycksMNSUehRK4/4UFnh0Qork/YK';
    private const MAX_USER_FAILS = 5;
    private const MAX_IP_FAILS = 25;
    private const LOCK_MINUTES = 15;
    private const ABSOLUTE_LIFETIME = 28800; // 8 hours

    private static ?array $user = null;
    private static bool $resolved = false;
    private static ?array $grants = null;
    private static ?array $catalog = null;

    // ---------------------------------------------------------------- session user
    public static function user(): ?array
    {
        if (self::$resolved) return self::$user;
        self::$resolved = true;
        $id = (int)($_SESSION['uid'] ?? 0);
        if ($id <= 0) return null;

        $now = time();
        $idle = max(5, (int)Settings::get('session_timeout_min', 30)) * 60;
        if (($_SESSION['last_activity'] ?? 0) < $now - $idle) { self::expire('Your session expired due to inactivity. Please sign in again.'); return null; }
        if (($_SESSION['login_at'] ?? 0) < $now - self::ABSOLUTE_LIFETIME) { self::expire('Your session has ended. Please sign in again.'); return null; }
        if (!hash_equals($_SESSION['ua'] ?? '', self::uaHash())) { self::expire('Please sign in again.'); return null; }

        $row = Db::one(
            'SELECT u.id, u.role_id, u.department_id, u.full_name, u.email, u.phone, u.is_active, u.must_change_password,
                    u.terms_version, u.last_login_at, u.created_at, r.slug AS role, r.name AS role_name,
                    d.name AS department_name, d.code AS department_code, d.is_active AS department_active
               FROM users u
               JOIN roles r ON r.id = u.role_id
               LEFT JOIN departments d ON d.id = u.department_id
              WHERE u.id = ?', [$id]);
        if (!$row || !(int)$row['is_active']) { self::expire('Your account is not active. Contact the NIS office.'); return null; }
        if ($row['role'] === 'department_rep' && (!$row['department_id'] || !(int)$row['department_active'])) {
            self::expire('Your department account is inactive. Contact the NIS office.');
            return null;
        }
        $_SESSION['last_activity'] = $now;
        return self::$user = $row;
    }

    public static function check(): bool { return self::user() !== null; }
    public static function id(): int { return (int)(self::user()['id'] ?? 0); }
    public static function role(): string { return (string)(self::user()['role'] ?? ''); }
    public static function isStaff(): bool { return in_array(self::role(), ['super_admin', 'nis_admin'], true); }

    private static function uaHash(): string { return hash('sha256', Request::userAgent()); }

    private static function expire(string $message): void
    {
        Session::destroy();
        Session::start();
        $_SESSION['flash'][] = ['warning', $message];
        self::$user = null;
    }

    // ---------------------------------------------------------------- login / logout
    /** @return array{0:bool,1:?string} [success, error message] */
    public static function attempt(string $email, string $password): array
    {
        $email = strtolower(trim($email));
        $ident = hash('sha256', $email);
        $ip = Request::ip();

        if (self::isLocked($ident, $ip)) {
            Audit::log('login.locked', 'user', null, ['email' => $email], 0);
            return [false, 'Too many failed attempts. Please wait ' . self::LOCK_MINUTES . ' minutes before trying again.'];
        }

        $u = Db::one('SELECT u.id, u.password_hash, u.is_active, u.department_id, r.slug AS role, d.is_active AS dept_active
                        FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN departments d ON d.id = u.department_id
                       WHERE u.email = ?', [$email]);

        // Always run one password_verify so timing does not reveal whether the account exists.
        $ok = password_verify($password, $u['password_hash'] ?? self::DUMMY_HASH) && $u !== null;

        if (!$ok) {
            self::recordAttempt($ident, $ip, false);
            Audit::log('login.failed', 'user', $u ? (int)$u['id'] : null, ['email' => $email], $u ? (int)$u['id'] : 0);
            return [false, 'Incorrect email or password.'];
        }
        if (!(int)$u['is_active']) {
            Audit::log('login.blocked_inactive', 'user', (int)$u['id'], [], (int)$u['id']);
            return [false, 'This account has been deactivated. Contact the NIS office.'];
        }
        if ($u['role'] === 'department_rep' && (!$u['department_id'] || !(int)$u['dept_active'])) {
            return [false, 'Your department is inactive. Contact the NIS office.'];
        }

        if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
            Db::exec('UPDATE users SET password_hash = ? WHERE id = ?', [Password::hash($password), $u['id']]);
        }

        Db::exec('DELETE FROM login_attempts WHERE identifier = ?', [$ident]);
        self::recordAttempt($ident, $ip, true);
        Db::exec('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?', [$ip, $u['id']]);

        Session::regenerate();            // prevents session fixation
        Csrf::rotate();
        $_SESSION['uid'] = (int)$u['id'];
        $_SESSION['login_at'] = time();
        $_SESSION['last_activity'] = time();
        $_SESSION['ua'] = self::uaHash();
        self::$resolved = false;
        self::$user = null;
        Audit::log('login.success', 'user', (int)$u['id'], [], (int)$u['id']);
        return [true, null];
    }

    public static function logout(): void
    {
        if (self::check()) Audit::log('logout', 'user', self::id());
        Session::destroy();
        self::$user = null;
        self::$resolved = true;
        Session::start();
    }

    private static function recordAttempt(string $ident, string $ip, bool $success): void
    {
        Db::exec('INSERT INTO login_attempts (identifier, ip_address, success) VALUES (?,?,?)', [$ident, $ip, $success ? 1 : 0]);
        if (random_int(1, 50) === 1) Db::exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 2 DAY)');
    }

    private static function isLocked(string $ident, string $ip): bool
    {
        $since = date('Y-m-d H:i:s', time() - self::LOCK_MINUTES * 60);
        $byUser = (int)Db::val('SELECT COUNT(*) FROM login_attempts WHERE identifier = ? AND success = 0 AND attempted_at > ?', [$ident, $since]);
        if ($byUser >= self::MAX_USER_FAILS) return true;
        $byIp = (int)Db::val('SELECT COUNT(*) FROM login_attempts WHERE ip_address = ? AND success = 0 AND attempted_at > ?', [$ip, $since]);
        return $byIp >= self::MAX_IP_FAILS;
    }

    /** Throttle for non-login public actions (e.g. password reset requests). */
    public static function throttle(string $bucket, int $max, int $minutes): bool
    {
        $ident = hash('sha256', $bucket . '|' . Request::ip());
        $since = date('Y-m-d H:i:s', time() - $minutes * 60);
        $n = (int)Db::val('SELECT COUNT(*) FROM login_attempts WHERE identifier = ? AND attempted_at > ?', [$ident, $since]);
        if ($n >= $max) return false;
        Db::exec('INSERT INTO login_attempts (identifier, ip_address, success) VALUES (?,?,0)', [$ident, Request::ip()]);
        return true;
    }

    // ---------------------------------------------------------------- authorisation
    public static function catalog(): array
    {
        return self::$catalog ??= (require APP_ROOT . '/config/permissions.php');
    }

    /** Server-side permission check. Super Administrator holds every permission. */
    public static function can(string $code): bool
    {
        $u = self::user();
        if (!$u) return false;
        if ($u['role'] === 'super_admin') return true;
        $def = self::catalog()[$code] ?? null;
        if (!$def || !in_array($u['role'], $def['roles'], true)) return false;   // permission does not apply to this role
        if (self::$grants === null) {
            self::$grants = array_column(Db::all(
                'SELECT p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id WHERE rp.role_id = ?',
                [(int)$u['role_id']]), 'code');
        }
        return in_array($code, self::$grants, true);
    }

    public static function password(int $userId, string $plain): void
    {
        Db::exec('UPDATE users SET password_hash = ?, must_change_password = 0, password_changed_at = NOW() WHERE id = ?', [Password::hash($plain), $userId]);
    }
}

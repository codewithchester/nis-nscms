<?php
declare(strict_types=1);

namespace App\Core;

/** Small rule-based validator. Rules: required|email|min:N|max:N|in:a,b|int|phone|datetime|date|regex */
final class Validator
{
    private array $errors = [];
    private array $data = [];

    public static function make(array $input, array $rules, array $labels = []): self
    {
        $v = new self();
        foreach ($rules as $field => $ruleString) {
            $raw = $input[$field] ?? '';
            $value = is_string($raw) ? trim($raw) : '';
            $label = $labels[$field] ?? ucfirst(str_replace('_', ' ', $field));
            $rulesList = explode('|', $ruleString);
            $nullable = !in_array('required', $rulesList, true);
            $v->data[$field] = $value;
            if ($value === '') {
                if (!$nullable) $v->errors[$field] = "$label is required.";
                continue;
            }
            foreach ($rulesList as $rule) {
                [$name, $arg] = array_pad(explode(':', $rule, 2), 2, null);
                $err = match ($name) {
                    'email' => filter_var($value, FILTER_VALIDATE_EMAIL) ? null : "$label must be a valid email address.",
                    'min'   => mb_strlen($value) >= (int)$arg ? null : "$label must be at least $arg characters.",
                    'max'   => mb_strlen($value) <= (int)$arg ? null : "$label must not exceed $arg characters.",
                    'in'    => in_array($value, explode(',', (string)$arg), true) ? null : "$label has an invalid value.",
                    'int'   => ctype_digit($value) ? null : "$label must be a number.",
                    'phone' => preg_match('/^\+?[0-9][0-9\s().-]{6,19}$/', $value) ? null : "$label must be a valid phone number.",
                    'date'  => self::validDate($value, 'Y-m-d') ? null : "$label must be a valid date.",
                    'datetime' => self::validDateTime($value) ? null : "$label must be a valid date and time.",
                    'name'  => preg_match('/^[\p{L}\p{M}\s\'.,-]{2,120}$/u', $value) ? null : "$label contains invalid characters.",
                    default => null,
                };
                if ($err) { $v->errors[$field] = $err; break; }
            }
        }
        return $v;
    }

    public static function validDate(string $s, string $fmt): bool
    {
        $d = \DateTime::createFromFormat('!' . $fmt, $s);
        return $d !== false && $d->format($fmt) === $s;
    }

    /** Accepts "Y-m-d\TH:i" (browser datetime-local) or "Y-m-d H:i:s". */
    public static function validDateTime(string $s): bool
    {
        return self::validDate($s, 'Y-m-d\TH:i') || self::validDate($s, 'Y-m-d H:i:s') || self::validDate($s, 'Y-m-d H:i');
    }

    public function addError(string $field, string $msg): void { $this->errors[$field] = $msg; }
    public function fails(): bool { return $this->errors !== []; }
    public function errors(): array { return $this->errors; }
    public function data(): array { return $this->data; }
    public function get(string $k): string { return $this->data[$k] ?? ''; }
}

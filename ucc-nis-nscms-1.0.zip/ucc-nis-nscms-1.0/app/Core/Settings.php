<?php
declare(strict_types=1);

namespace App\Core;

final class Settings
{
    private static ?array $cache = null;

    private static function load(): void
    {
        if (self::$cache === null) {
            self::$cache = [];
            foreach (Db::all('SELECT setting_key, setting_value FROM system_settings') as $r) {
                self::$cache[$r['setting_key']] = $r['setting_value'];
            }
        }
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        self::load();
        $v = self::$cache[$key] ?? null;
        return ($v === null || $v === '') ? $default : $v;
    }

    public static function set(string $key, string $value): void
    {
        Db::exec('INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)', [$key, $value]);
        self::$cache = null;
    }
}

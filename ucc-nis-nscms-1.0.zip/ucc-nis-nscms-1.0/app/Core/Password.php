<?php
declare(strict_types=1);

namespace App\Core;

final class Password
{
    public static function hash(string $plain): string { return password_hash($plain, PASSWORD_DEFAULT); }

    /** Returns an error message, or null when acceptable. */
    public static function policy(string $pw, string $email = '', string $name = ''): ?string
    {
        if (strlen($pw) < 10) return 'Password must be at least 10 characters long.';
        if (strlen($pw) > 72) return 'Password must not exceed 72 characters.';
        if (!preg_match('/[A-Za-z]/', $pw) || !preg_match('/[0-9]/', $pw)) return 'Password must contain at least one letter and one number.';
        if (preg_match('/^(.)\1+$/', $pw)) return 'Password is too simple.';
        $lower = strtolower($pw);
        if ($email !== '' && str_contains($lower, strtolower(explode('@', $email)[0])) && strlen(explode('@', $email)[0]) >= 4) return 'Password must not contain your email name.';
        foreach (['password123', '1234567890', 'qwerty1234', 'ucc1234567', 'admin12345'] as $bad) {
            if (str_contains($lower, $bad)) return 'Password is too common. Choose something less predictable.';
        }
        return null;
    }

    /** Random temporary password that satisfies the policy. */
    public static function generate(int $len = 12): string
    {
        $a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
        $pw = '';
        for ($i = 0; $i < $len; $i++) $pw .= $a[random_int(0, strlen($a) - 1)];
        return $pw . random_int(10, 99);
    }
}

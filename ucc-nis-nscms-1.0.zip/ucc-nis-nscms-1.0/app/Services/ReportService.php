<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\{Db, Settings};

final class ReportService
{
    private static function validDate(string $value): bool
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        $errors = \DateTimeImmutable::getLastErrors();
        return $date !== false
            && $date->format('Y-m-d') === $value
            && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0));
    }

    public static function filters(array $get): array
    {
        $date = fn($k, $d) => (isset($get[$k]) && is_string($get[$k]) && self::validDate($get[$k])) ? $get[$k] : $d;
        $str = fn($k) => isset($get[$k]) && is_string($get[$k]) ? $get[$k] : '';
        $f = [
            'from' => $date('from', date('Y-m-d', strtotime('-90 days'))),
            'to' => $date('to', date('Y-m-d')),
            'department' => ctype_digit($str('department')) ? (int)$str('department') : 0,
            'category' => ctype_digit($str('category')) ? (int)$str('category') : 0,
            'technician' => ctype_digit($str('technician')) ? (int)$str('technician') : 0,
            'priority' => in_array($str('priority'), Workflow::PRIORITIES, true) ? $str('priority') : '',
            'status' => in_array($str('status'), Workflow::STATUSES, true) ? $str('status') : '',
        ];
        if ($f['from'] > $f['to']) [$f['from'], $f['to']] = [$f['to'], $f['from']];
        return $f;
    }

    public static function describeFilters(array $f): array
    {
        $labels = ['Start date' => $f['from'], 'End date' => $f['to']];
        foreach ([
            ['department', 'Department', 'departments'],
            ['category', 'Category', 'complaint_categories'],
            ['technician', 'Technician', 'users'],
        ] as [$key, $label, $table]) {
            if ($f[$key] > 0) {
                $column = $key === 'technician' ? 'full_name' : 'name';
                $value = Db::val("SELECT $column FROM $table WHERE id = ?", [$f[$key]]);
                $labels[$label] = $value !== null ? (string)$value : 'Unknown (#' . $f[$key] . ')';
            }
        }
        if ($f['priority'] !== '') $labels['Priority'] = $f['priority'];
        if ($f['status'] !== '') $labels['Status'] = $f['status'];
        return $labels;
    }

    public static function csvSafeCell(mixed $value): mixed
    {
        if (is_string($value) && preg_match('/^(?:[\x00-\x20]|\xEF\xBB\xBF)*[=+\-@]/', $value) === 1) {
            return "'" . $value;
        }
        return $value;
    }

    /** WHERE fragment on alias "c" built from validated filters only; values are always bound. */
    private static function where(array $f): array
    {
        $w = ['c.created_at >= ?', 'c.created_at < ?'];
        $p = [$f['from'] . ' 00:00:00', date('Y-m-d', strtotime($f['to'] . ' +1 day')) . ' 00:00:00'];
        if ($f['department']) { $w[] = 'c.department_id = ?'; $p[] = $f['department']; }
        if ($f['category']) { $w[] = 'c.category_id = ?'; $p[] = $f['category']; }
        if ($f['priority'] !== '') { $w[] = 'c.priority = ?'; $p[] = $f['priority']; }
        if ($f['status'] !== '') { $w[] = 'c.status = ?'; $p[] = $f['status']; }
        if ($f['technician']) { $w[] = 'EXISTS (SELECT 1 FROM complaint_assignments fa WHERE fa.complaint_id = c.id AND fa.technician_id = ?)'; $p[] = $f['technician']; }
        return [implode(' AND ', $w), $p];
    }

    public static function build(array $f, int $detailLimit = 200): array
    {
        [$w, $p] = self::where($f);
        $avg = 'AVG(CASE WHEN c.resolved_at IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, c.created_at, c.resolved_at) END) / 60';

        $summary = Db::one("SELECT COUNT(*) total,
                SUM(c.status IN ('Resolved','Closed')) resolved,
                SUM(c.status NOT IN ('Resolved','Closed','Rejected')) unresolved,
                SUM(c.status = 'Rejected') rejected,
                SUM(c.status NOT IN ('Awaiting Department Response','Resolved','Closed','Rejected') AND c.due_at < NOW()) overdue,
                $avg avg_hours,
                SUM(c.resolved_at IS NOT NULL AND c.resolved_at <= c.due_at) within_sla,
                SUM(c.resolved_at IS NOT NULL) resolved_total
              FROM complaints c WHERE $w", $p) ?? [];
        foreach (['total', 'resolved', 'unresolved', 'rejected', 'overdue', 'within_sla', 'resolved_total'] as $k) $summary[$k] = (int)($summary[$k] ?? 0);
        $summary['sla_pct'] = $summary['resolved_total'] > 0 ? round(100 * $summary['within_sla'] / $summary['resolved_total']) : null;

        $threshold = max(2, (int)Settings::get('recurring_threshold', 3));
        return [
            'filters' => $f,
            'summary' => $summary,
            'by_category' => Db::all("SELECT cat.name, COUNT(*) total, SUM(c.status IN ('Resolved','Closed')) resolved, $avg avg_hours
                                        FROM complaints c JOIN complaint_categories cat ON cat.id = c.category_id WHERE $w GROUP BY cat.id, cat.name ORDER BY total DESC, cat.name", $p),
            'by_department' => Db::all("SELECT d.name, d.code, COUNT(*) total, SUM(c.status NOT IN ('Resolved','Closed','Rejected')) open_count, SUM(c.status IN ('Resolved','Closed')) resolved, $avg avg_hours
                                          FROM complaints c JOIN departments d ON d.id = c.department_id WHERE $w GROUP BY d.id, d.name, d.code ORDER BY total DESC, d.name", $p),
            'by_priority' => Db::all("SELECT c.priority, COUNT(*) total, $avg avg_hours FROM complaints c WHERE $w GROUP BY c.priority ORDER BY FIELD(c.priority,'Critical','High','Medium','Low')", $p),
            'by_status' => Db::all("SELECT c.status, COUNT(*) total FROM complaints c WHERE $w GROUP BY c.status ORDER BY FIELD(c.status,'Submitted','Under Review','Accepted','Assigned','In Progress','Awaiting Department Response','Resolved','Closed','Rejected')", $p),
            'by_location' => Db::all("SELECT c.building, COUNT(*) total FROM complaints c WHERE $w GROUP BY c.building ORDER BY total DESC LIMIT 10", $p),
            'recurring' => Db::all("SELECT d.name AS department, cat.name AS category, c.building, COUNT(*) occurrences, MAX(c.created_at) last_reported
                                      FROM complaints c JOIN departments d ON d.id = c.department_id JOIN complaint_categories cat ON cat.id = c.category_id
                                     WHERE $w GROUP BY c.department_id, c.category_id, c.building, d.name, cat.name HAVING COUNT(*) >= $threshold
                                     ORDER BY occurrences DESC, last_reported DESC LIMIT 25", $p),
            'technicians' => Db::all("SELECT t.full_name, COUNT(a.id) assigned, SUM(a.status = 'Completed') completed, SUM(a.status = 'Active') active,
                                             AVG(CASE WHEN a.status = 'Completed' THEN TIMESTAMPDIFF(MINUTE, a.assigned_at, a.completed_at) END) / 60 avg_hours
                                        FROM complaint_assignments a JOIN users t ON t.id = a.technician_id JOIN complaints c ON c.id = a.complaint_id
                                       WHERE $w GROUP BY t.id, t.full_name ORDER BY completed DESC, assigned DESC", $p),
            'unresolved' => Db::all("SELECT c.reference_no, c.title, d.name AS department_name, c.priority, c.status, c.created_at, c.due_at,
                                            TIMESTAMPDIFF(DAY, c.created_at, NOW()) age_days,
                                            (c.status NOT IN ('Awaiting Department Response') AND c.due_at < NOW()) is_overdue
                                       FROM complaints c JOIN departments d ON d.id = c.department_id
                                      WHERE $w AND c.status NOT IN ('Resolved','Closed','Rejected') ORDER BY c.due_at ASC LIMIT 100", $p),
            'rows' => self::rows($f, $detailLimit),
            'recurring_threshold' => $threshold,
        ];
    }

    public static function rows(array $f, int $limit): array
    {
        [$sql, $params] = self::rowsQuery($f, $limit);
        return Db::all($sql, $params);
    }

    /** Stream all rows matching the same validated filters used by the report preview. */
    public static function streamRows(array $f): \Generator
    {
        [$sql, $params] = self::rowsQuery($f, null);
        $statement = Db::run($sql, $params);
        try {
            while (($row = $statement->fetch()) !== false) yield $row;
        } finally {
            $statement->closeCursor();
        }
    }

    private static function rowsQuery(array $f, ?int $limit): array
    {
        [$w, $p] = self::where($f);
        $sql = "SELECT c.reference_no, c.title, d.name AS department_name, cat.name AS category_name, c.priority, c.status, c.building, c.room,
                               c.reporter_name, t.full_name AS technician_name, c.created_at, c.reported_at, c.due_at, c.resolved_at,
                               CASE WHEN c.resolved_at IS NOT NULL THEN ROUND(TIMESTAMPDIFF(MINUTE, c.created_at, c.resolved_at) / 60, 2) END AS resolution_hours
                          FROM complaints c JOIN departments d ON d.id = c.department_id JOIN complaint_categories cat ON cat.id = c.category_id
                          LEFT JOIN users t ON t.id = c.assigned_to
                         WHERE $w ORDER BY c.created_at DESC";
        if ($limit !== null) $sql .= ' LIMIT ' . max(0, $limit);
        return [$sql, $p];
    }
}

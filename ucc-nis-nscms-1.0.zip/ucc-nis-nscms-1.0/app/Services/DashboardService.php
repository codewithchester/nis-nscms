<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Db;
use App\Models\Complaint;

/** All dashboard numbers come straight from the database; nothing is hard-coded or simulated. */
final class DashboardService
{
    private const ACTIVE_SQL = "('Awaiting Department Response','Resolved','Closed','Rejected')";

    public static function admin(array $user, bool $withCharts): array
    {
        $c = Db::one("SELECT COUNT(*) total,
                SUM(status = 'Submitted') new_count,
                SUM(status IN ('Submitted','Under Review','Accepted')) pending,
                SUM(status = 'In Progress') investigating,
                SUM(status = 'Assigned') assigned,
                SUM(assigned_to IS NULL AND status NOT IN ('Resolved','Closed','Rejected')) unassigned,
                SUM(status = 'Awaiting Department Response') awaiting,
                SUM(status IN ('Resolved','Closed')) resolved,
                SUM(status NOT IN " . self::ACTIVE_SQL . " AND due_at < NOW()) overdue
              FROM complaints") ?? [];
        $out = ['counts' => array_map('intval', $c)];
        $out['counts']['departments'] = (int)Db::val('SELECT COUNT(*) FROM departments WHERE is_active = 1');
        $out['counts']['technicians'] = (int)Db::val("SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE r.slug = 'technician' AND u.is_active = 1");
        $out['recent'] = Complaint::search($user, [], 'created', 'desc', 1, 8)['rows'];
        $out['attention'] = Db::all("SELECT c.id, c.reference_no, c.title, c.priority, c.status, c.due_at, d.name AS department_name
                FROM complaints c JOIN departments d ON d.id = c.department_id
               WHERE c.status NOT IN " . self::ACTIVE_SQL . " AND c.due_at < NOW() ORDER BY c.due_at ASC LIMIT 5");
        if (!$withCharts) return $out;

        // priority distribution
        $pri = array_column(Db::all('SELECT priority, COUNT(*) n FROM complaints GROUP BY priority'), 'n', 'priority');
        $out['charts']['priority'] = ['labels' => Workflow::PRIORITIES, 'data' => array_map(fn($p) => (int)($pri[$p] ?? 0), Workflow::PRIORITIES)];

        // categories
        $cat = Db::all('SELECT cat.name, COUNT(*) n FROM complaints c JOIN complaint_categories cat ON cat.id = c.category_id GROUP BY cat.id, cat.name ORDER BY n DESC LIMIT 8');
        $out['charts']['category'] = ['labels' => array_column($cat, 'name'), 'data' => array_map('intval', array_column($cat, 'n'))];

        // departments
        $dep = Db::all('SELECT d.code, d.name, COUNT(*) n FROM complaints c JOIN departments d ON d.id = c.department_id GROUP BY d.id, d.code, d.name ORDER BY n DESC LIMIT 8');
        $out['charts']['department'] = ['labels' => array_column($dep, 'code'), 'names' => array_column($dep, 'name'), 'data' => array_map('intval', array_column($dep, 'n'))];

        // monthly trend (last 12 months)
        $months = [];
        for ($i = 11; $i >= 0; $i--) $months[date('Y-m', strtotime("first day of -$i month"))] = ['label' => date('M Y', strtotime("first day of -$i month")), 'created' => 0, 'resolved' => 0];
        $since = date('Y-m-01', strtotime('first day of -11 month'));
        foreach (Db::all("SELECT DATE_FORMAT(created_at,'%Y-%m') m, COUNT(*) n FROM complaints WHERE created_at >= ? GROUP BY m", [$since]) as $r) if (isset($months[$r['m']])) $months[$r['m']]['created'] = (int)$r['n'];
        foreach (Db::all("SELECT DATE_FORMAT(resolved_at,'%Y-%m') m, COUNT(*) n FROM complaints WHERE resolved_at >= ? GROUP BY m", [$since]) as $r) if (isset($months[$r['m']])) $months[$r['m']]['resolved'] = (int)$r['n'];
        $out['charts']['monthly'] = ['labels' => array_column($months, 'label'), 'created' => array_column($months, 'created'), 'resolved' => array_column($months, 'resolved')];

        // technician workload (open complaints per technician)
        $wl = Db::all("SELECT t.full_name, COUNT(c.id) n FROM users t JOIN roles r ON r.id = t.role_id AND r.slug = 'technician'
                        LEFT JOIN complaints c ON c.assigned_to = t.id AND c.status NOT IN ('Resolved','Closed','Rejected')
                       WHERE t.is_active = 1 GROUP BY t.id, t.full_name ORDER BY n DESC, t.full_name LIMIT 12");
        $out['charts']['workload'] = ['labels' => array_column($wl, 'full_name'), 'data' => array_map('intval', array_column($wl, 'n'))];

        // resolution performance by priority
        $perf = [];
        foreach (Db::all('SELECT priority, COUNT(*) n, AVG(TIMESTAMPDIFF(MINUTE, created_at, resolved_at)) / 60 avg_h, SUM(resolved_at <= due_at) within_sla
                            FROM complaints WHERE resolved_at IS NOT NULL GROUP BY priority') as $r) $perf[$r['priority']] = $r;
        $out['charts']['resolution'] = [
            'labels' => Workflow::PRIORITIES,
            'avg'    => array_map(fn($p) => isset($perf[$p]) ? round((float)$perf[$p]['avg_h'], 1) : 0, Workflow::PRIORITIES),
            'sla'    => array_map(fn($p) => isset($perf[$p]) && (int)$perf[$p]['n'] > 0 ? round(100 * (int)$perf[$p]['within_sla'] / (int)$perf[$p]['n']) : 0, Workflow::PRIORITIES),
        ];
        return $out;
    }

    public static function department(array $user): array
    {
        $d = (int)$user['department_id'];
        $c = Db::one("SELECT COUNT(*) total,
                SUM(status NOT IN ('Resolved','Closed','Rejected')) open_count,
                SUM(status = 'Awaiting Department Response') awaiting,
                SUM(status IN ('Resolved','Closed')) resolved,
                SUM(status = 'Rejected') rejected FROM complaints WHERE department_id = ?", [$d]) ?? [];
        return [
            'counts' => array_map('intval', $c),
            'recent' => Complaint::search($user, [], 'created', 'desc', 1, 6)['rows'],
            'needs_response' => Complaint::search($user, ['status' => Workflow::AWAITING], 'updated', 'desc', 1, 10)['rows'],
            'to_confirm' => Complaint::search($user, ['status' => 'Resolved'], 'created', 'desc', 1, 10)['rows'],
        ];
    }

    public static function technician(array $user): array
    {
        $id = (int)$user['id'];
        $c = Db::one("SELECT COUNT(*) active_total,
                SUM(status = 'Assigned') assigned,
                SUM(status = 'In Progress') in_progress,
                SUM(status = 'Awaiting Department Response') awaiting,
                SUM(status NOT IN " . self::ACTIVE_SQL . " AND due_at < NOW()) overdue
              FROM complaints WHERE assigned_to = ? AND status NOT IN ('Resolved','Closed','Rejected')", [$id]) ?? [];
        $counts = array_map('intval', $c);
        $counts['completed'] = (int)Db::val("SELECT COUNT(*) FROM complaint_assignments WHERE technician_id = ? AND status = 'Completed'", [$id]);
        $counts['avg_hours'] = Db::val("SELECT AVG(TIMESTAMPDIFF(MINUTE, assigned_at, completed_at)) / 60 FROM complaint_assignments WHERE technician_id = ? AND status = 'Completed'", [$id]);
        $queue = Db::all("SELECT c.id, c.reference_no, c.title, c.priority, c.status, c.due_at, c.building, c.room, d.name AS department_name
                            FROM complaints c JOIN departments d ON d.id = c.department_id
                           WHERE c.assigned_to = ? AND c.status NOT IN ('Resolved','Closed','Rejected')
                           ORDER BY c.priority DESC, c.due_at ASC LIMIT 25", [$id]);
        $history = Db::all("SELECT c.id, c.reference_no, c.title, c.priority, c.status, a.completed_at, d.name AS department_name
                              FROM complaint_assignments a JOIN complaints c ON c.id = a.complaint_id JOIN departments d ON d.id = c.department_id
                             WHERE a.technician_id = ? AND a.status = 'Completed' ORDER BY a.completed_at DESC LIMIT 8", [$id]);
        return ['counts' => $counts, 'queue' => $queue, 'history' => $history];
    }
}

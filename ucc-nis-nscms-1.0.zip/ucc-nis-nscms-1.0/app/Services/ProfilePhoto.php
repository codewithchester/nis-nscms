<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Db;

final class ProfilePhoto
{
    private static ?bool $available = null;

    public static function available(): bool
    {
        return self::$available ??= (bool)Db::val(
            "SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'user_profile_photos'"
        );
    }

    public static function existsFor(int $userId): bool
    {
        if ($userId <= 0 || !self::available()) return false;
        $photo = Db::one('SELECT stored_name FROM user_profile_photos WHERE user_id = ?', [$userId]);
        return $photo
            && preg_match('/^[a-f0-9]{40}$/', $photo['stored_name'])
            && is_file(Upload::dir() . '/' . $photo['stored_name']);
    }
}

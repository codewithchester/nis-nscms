<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\{Db, Mailer};

final class Notifier
{
    /** In-app notification (always) plus email (when the environment allows). Never throws. */
    public static function send(array $userIds, ?int $complaintId, string $type, string $title, string $message, int $excludeUserId = 0): void
    {
        try {
            $ids = array_values(array_unique(array_filter(array_map('intval', $userIds), fn($i) => $i > 0 && $i !== $excludeUserId)));
            if (!$ids) return;
            $message = mb_substr($message, 0, 480);
            foreach ($ids as $id) {
                Db::exec('INSERT INTO notifications (user_id, complaint_id, type, title, message) VALUES (?,?,?,?,?)',
                    [$id, $complaintId, $type, mb_substr($title, 0, 150), $message]);
            }
            $users = Db::all('SELECT email, full_name FROM users WHERE is_active = 1 AND id IN (' . Db::marks($ids) . ')', $ids);
            $link = $complaintId ? abs_url('complaints/view', ['id' => $complaintId]) : abs_url('notifications');
            $org = (string)setting('section_name', 'Network Infrastructure Section');
            foreach ($users as $u) {
                $html = '<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;color:#222">'
                    . '<h2 style="color:#174b74;margin-bottom:4px">' . e($title) . '</h2>'
                    . '<p>Hello ' . e($u['full_name']) . ',</p><p>' . nl2br(e($message)) . '</p>'
                    . '<p><a href="' . e($link) . '" style="background:#174b74;color:#fff;padding:10px 18px;border-radius:4px;text-decoration:none">Open in the portal</a></p>'
                    . '<hr style="border:none;border-top:1px solid #ddd"><p style="font-size:12px;color:#777">' . e(setting('org_name', 'University of Cape Coast')) . ' · ' . e($org) . '</p></div>';
                $text = "Hello {$u['full_name']},\n\n$title\n$message\n\nOpen: $link\n";
                Mailer::send($u['email'], '[UCC NIS] ' . $title, $html, $text);
            }
        } catch (\Throwable $e) {
            error_log('[notify] ' . $e->getMessage());
        }
    }

    /** Unread count and latest items for the header bell. */
    public static function summary(int $userId): array
    {
        return [
            'count' => (int)Db::val('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$userId]),
            'items' => Db::all('SELECT id, complaint_id, title, message, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 6', [$userId]),
        ];
    }
}

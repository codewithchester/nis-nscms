<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Settings;

/**
 * Safe attachment handling:
 *  - extension allow-list + real MIME sniffing (finfo) + image decoding check
 *  - files are stored OUTSIDE public access in /storage/uploads under a random name with no extension
 *  - downloads are always served as attachments through an authorised controller, with nosniff
 */
final class Upload
{
    private const ALLOWED = [
        'jpg' => ['image/jpeg'], 'jpeg' => ['image/jpeg'], 'png' => ['image/png'], 'gif' => ['image/gif'], 'webp' => ['image/webp'],
        'pdf' => ['application/pdf'],
        'txt' => ['text/'], 'log' => ['text/'], 'csv' => ['text/', 'application/csv'],
        'doc' => ['application/msword', 'application/vnd.ms-office', 'application/cdfv2', 'application/x-ole-storage', 'application/octet-stream'],
        'xls' => ['application/vnd.ms-excel', 'application/vnd.ms-office', 'application/cdfv2', 'application/x-ole-storage', 'application/octet-stream'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip', 'application/octet-stream'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip', 'application/octet-stream'],
    ];
    public const CANONICAL = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp',
        'pdf' => 'application/pdf', 'txt' => 'text/plain', 'log' => 'text/plain', 'csv' => 'text/csv',
        'doc' => 'application/msword', 'xls' => 'application/vnd.ms-excel',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];

    public static function allowedExtensions(): string { return strtoupper(implode(', ', array_keys(self::ALLOWED))); }

    public static function dir(): string
    {
        $d = APP_ROOT . '/storage/uploads';
        if (!is_dir($d)) @mkdir($d, 0750, true);
        return $d;
    }

    /** @return array{none?:bool,error?:string,ext?:string,size?:int,name?:string} */
    public static function inspect(?array $file): array
    {
        if (!$file || !isset($file['error']) || is_array($file['error'])) return ['none' => true];
        if ($file['error'] === UPLOAD_ERR_NO_FILE) return ['none' => true];
        if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) return ['error' => 'The attachment is larger than the server allows.'];
        if ($file['error'] !== UPLOAD_ERR_OK) return ['error' => 'The attachment could not be uploaded. Please try again.'];

        $max = max(1, (int)Settings::get('max_upload_mb', 5)) * 1048576;
        $size = (int)$file['size'];
        if ($size <= 0) return ['error' => 'The attachment is empty.'];
        if ($size > $max) return ['error' => 'The attachment must be ' . human_size($max) . ' or smaller.'];
        if (!is_uploaded_file($file['tmp_name'])) return ['error' => 'Invalid upload.'];

        $name = self::cleanName((string)$file['name']);
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!isset(self::ALLOWED[$ext])) return ['error' => 'File type not allowed. Allowed: ' . self::allowedExtensions() . '.'];

        if (function_exists('finfo_open')) {
            $fi = finfo_open(FILEINFO_MIME_TYPE);
            $mime = strtolower((string)finfo_file($fi, $file['tmp_name']));
            finfo_close($fi);
            $ok = false;
            foreach (self::ALLOWED[$ext] as $prefix) { if (str_starts_with($mime, $prefix)) { $ok = true; break; } }
            if (!$ok) return ['error' => 'The file content does not match its extension.'];
        }
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true) && @getimagesize($file['tmp_name']) === false) {
            return ['error' => 'The image appears to be corrupt.'];
        }
        $head = (string)file_get_contents($file['tmp_name'], false, null, 0, 2048);
        if (in_array($ext, ['txt', 'log', 'csv'], true) && str_contains($head, "\0")) return ['error' => 'The text file appears to be binary.'];
        if (stripos($head, '<?php') !== false) return ['error' => 'The file contains disallowed content.'];

        return ['ext' => $ext, 'size' => $size, 'name' => $name];
    }

    /** Profile photos accept only decoded JPEG, PNG, or WebP raster images. */
    public static function inspectProfilePhoto(?array $file): array
    {
        $meta = self::inspect($file);
        if (isset($meta['error']) || isset($meta['none'])) return $meta;
        if (!in_array($meta['ext'], ['jpg', 'jpeg', 'png', 'webp'], true)) {
            return ['error' => 'Profile photos must be a JPEG, PNG, or WebP image.'];
        }

        $image = @getimagesize($file['tmp_name']);
        if ($image === false || $image[0] < 1 || $image[1] < 1 || $image[0] * $image[1] > 16000000) {
            return ['error' => 'The profile photo is invalid or its dimensions are too large.'];
        }
        return $meta;
    }

    /** Move the uploaded file into private storage. Call only after inspect() passed. */
    public static function store(array $file, array $meta): array
    {
        $stored = bin2hex(random_bytes(20));
        $dest = self::dir() . '/' . $stored;
        if (!move_uploaded_file($file['tmp_name'], $dest)) throw new \RuntimeException('Could not store upload.');
        @chmod($dest, 0640);
        return [
            'stored_name' => $stored, 'original_name' => $meta['name'], 'size' => $meta['size'],
            'mime' => self::CANONICAL[$meta['ext']] ?? 'application/octet-stream', 'sha256' => hash_file('sha256', $dest),
        ];
    }

    public static function remove(string $stored): void
    {
        if (preg_match('/^[a-f0-9]{40}$/', $stored)) @unlink(self::dir() . '/' . $stored);
    }

    public static function cleanName(string $n): string
    {
        $n = basename(str_replace('\\', '/', $n));
        $n = preg_replace('/[\x00-\x1F\x7F"<>|:*?\\\\\/]+/u', '_', $n) ?? 'file';
        $n = trim($n, " .\t");
        return mb_substr($n === '' ? 'file' : $n, 0, 150);
    }
}

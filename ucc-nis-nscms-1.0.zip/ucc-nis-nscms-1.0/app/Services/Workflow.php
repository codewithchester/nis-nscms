<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\Auth;

/** Complaint lifecycle rules. The server decides what each role may do; the UI only mirrors it. */
final class Workflow
{
    public const STATUSES = ['Submitted', 'Under Review', 'Accepted', 'Assigned', 'In Progress', 'Awaiting Department Response', 'Resolved', 'Closed', 'Rejected'];
    public const PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];
    /** Statuses in which the SLA clock is not running / the complaint is not outstanding. */
    public const NOT_OUTSTANDING = ['Awaiting Department Response', 'Resolved', 'Closed', 'Rejected'];
    public const FINISHED = ['Resolved', 'Closed', 'Rejected'];
    public const AWAITING = 'Awaiting Department Response';

    public static function allowed(array $actor, array $c): array
    {
        $from = $c['status'];

        // NIS administrators (and the Super Administrator)
        if (Auth::can('complaints.review')) {
            $hold = $c['status_before_hold'] ?: 'Under Review';
            $map = [
                'Submitted'    => ['Under Review', 'Accepted', 'Rejected', self::AWAITING],
                'Under Review' => ['Accepted', 'Rejected', self::AWAITING],
                'Accepted'     => ['Under Review', 'Rejected', self::AWAITING],
                'Assigned'     => ['In Progress', self::AWAITING, 'Resolved'],
                'In Progress'  => [self::AWAITING, 'Resolved'],
                self::AWAITING => [$hold, 'Rejected'],
                'Resolved'     => ['Closed', 'In Progress'],
                'Closed'       => [],
                'Rejected'     => ['Under Review'],
            ];
            return $map[$from] ?? [];
        }

        // Network technicians: only on complaints currently assigned to them
        if (Auth::can('complaints.work') && (int)$c['assigned_to'] === (int)$actor['id']) {
            return match ($from) {
                'Assigned'    => ['In Progress', self::AWAITING],
                'In Progress' => [self::AWAITING, 'Resolved'],
                default       => [],
            };
        }

        // Department representatives: confirm or reopen a resolved complaint of their own department
        if (Auth::can('complaints.respond') && (int)$c['department_id'] === (int)($actor['department_id'] ?? 0)) {
            return $from === 'Resolved' ? ['Closed', 'In Progress'] : [];
        }
        return [];
    }

    public static function noteRequired(string $from, string $to): bool
    {
        return in_array($to, ['Rejected', self::AWAITING, 'Resolved'], true) || ($from === 'Resolved' && $to === 'In Progress');
    }

    public static function noteLabel(string $from, string $to): string
    {
        return match (true) {
            $to === 'Rejected' => 'Reason for rejection (shown to the department)',
            $to === self::AWAITING => 'What information do you need from the department?',
            $to === 'Resolved' => 'Resolution notes (what was done)',
            $from === 'Resolved' && $to === 'In Progress' => 'Why is the problem not resolved?',
            default => 'Note (optional)',
        };
    }

    public static function slaHours(string $priority): int
    {
        $key = 'sla_hours_' . strtolower($priority);
        return max(1, (int)\App\Core\Settings::get($key, ['Critical' => 4, 'High' => 24, 'Medium' => 72, 'Low' => 168][$priority] ?? 72));
    }
}

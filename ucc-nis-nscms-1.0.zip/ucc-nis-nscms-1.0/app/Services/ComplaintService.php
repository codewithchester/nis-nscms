<?php
declare(strict_types=1);

namespace App\Services;

use App\Core\{Audit, Auth, Db};
use App\Models\{Complaint, User};

final class ComplaintService
{
    // ------------------------------------------------------------------ create
    /** @return array{0:int,1:string} [complaint id, reference number] */
    public static function create(array $in, array $actor, array $fileMeta, ?array $file): array
    {
        $stored = null;
        try {
            [$id, $ref] = Db::tx(function () use ($in, $actor, $fileMeta, $file, &$stored) {
                $year = (int)date('Y');
                Db::exec('INSERT IGNORE INTO reference_counters (ref_year, last_seq) VALUES (?, 0)', [$year]);
                $seq = (int)Db::val('SELECT last_seq FROM reference_counters WHERE ref_year = ? FOR UPDATE', [$year]) + 1;
                Db::exec('UPDATE reference_counters SET last_seq = ? WHERE ref_year = ?', [$seq, $year]);
                $ref = sprintf('NIS-%d-%05d', $year, $seq);

                $reported = str_replace('T', ' ', $in['reported_at']);
                if (strlen($reported) === 16) $reported .= ':00';
                $due = date('Y-m-d H:i:s', time() + Workflow::slaHours($in['priority']) * 3600);

                $id = Db::insert('INSERT INTO complaints
                    (reference_no, department_id, submitted_by, category_id, reporter_name, reporter_email, reporter_phone, title, description,
                     building, room, reported_at, priority, status, due_at)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [$ref, (int)$actor['department_id'], (int)$actor['id'], (int)$in['category_id'], $in['reporter_name'], strtolower($in['reporter_email']),
                     $in['reporter_phone'], $in['title'], $in['description'], $in['building'], $in['room'], $reported, $in['priority'], 'Submitted', $due]);

                Db::exec('INSERT INTO complaint_status_history (complaint_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)',
                    [$id, null, 'Submitted', (int)$actor['id'], 'Complaint submitted']);

                if ($file && isset($fileMeta['ext'])) {
                    $s = Upload::store($file, $fileMeta);
                    $stored = $s['stored_name'];
                    Db::exec('INSERT INTO attachments (complaint_id, uploaded_by, original_name, stored_name, mime_type, size_bytes, sha256) VALUES (?,?,?,?,?,?,?)',
                        [$id, (int)$actor['id'], $s['original_name'], $s['stored_name'], $s['mime'], $s['size'], $s['sha256']]);
                }
                return [$id, $ref];
            });
        } catch (\Throwable $e) {
            if ($stored) Upload::remove($stored);
            throw $e;
        }

        Audit::log('complaint.create', 'complaint', $id, ['reference' => $ref, 'priority' => $in['priority']]);
        Notifier::send(User::staffIds(), $id, 'complaint_submitted', "New complaint $ref",
            "{$actor['department_name']}: {$in['title']} ({$in['priority']} priority)");
        Notifier::send([(int)$actor['id']], $id, 'complaint_received', "Complaint $ref received",
            "Your complaint \"{$in['title']}\" has been logged. Use reference $ref to track progress.");
        return [$id, $ref];
    }

    /** While NIS waits for the department, the target clock is paused: push the due date back by the waiting time. */
    private static function extendDueAfterHold(int $id): void
    {
        $since = Db::val("SELECT created_at FROM complaint_status_history WHERE complaint_id = ? AND to_status = ? ORDER BY id DESC LIMIT 1", [$id, Workflow::AWAITING]);
        if ($since) {
            Db::exec('UPDATE complaints SET due_at = DATE_ADD(due_at, INTERVAL GREATEST(0, TIMESTAMPDIFF(SECOND, ?, NOW())) SECOND) WHERE id = ?', [$since, $id]);
        }
    }

    // ------------------------------------------------------------------ status changes
    /** @return array{0:bool,1:?string} */
    public static function transition(int $id, string $to, string $note, array $actor): array
    {
        $note = trim($note);
        $outcome = Db::tx(function () use ($id, $to, $note, $actor) {
            $c = Db::one('SELECT * FROM complaints WHERE id = ? FOR UPDATE', [$id]);
            if (!$c || !Complaint::accessible($id, $actor)) return [false, 'not_found'];
            $from = $c['status'];
            if (!in_array($to, Workflow::allowed($actor, $c), true)) return [false, 'You cannot change this complaint from "' . $from . '" to "' . $to . '".'];
            if (Workflow::noteRequired($from, $to) && mb_strlen($note) < 5) return [false, 'Please provide a note (at least 5 characters) for this change.'];
            if (mb_strlen($note) > 3000) return [false, 'The note is too long (3000 characters maximum).'];

            $sets = ['status = ?'];
            $p = [$to];
            if ($from === Workflow::AWAITING) { $sets[] = 'status_before_hold = NULL'; self::extendDueAfterHold($id); }
            if ($to === Workflow::AWAITING) { $sets[] = 'status_before_hold = ?'; $p[] = $from; }
            if ($to === 'Rejected') { $sets[] = 'rejection_reason = ?'; $p[] = $note; }
            if ($from === 'Rejected') { $sets[] = 'rejection_reason = NULL'; }
            if ($to === 'Resolved') { $sets[] = 'resolved_at = NOW()'; }
            if ($from === 'Resolved' && $to === 'In Progress') { $sets[] = 'resolved_at = NULL'; }
            if ($to === 'Closed') { $sets[] = 'closed_at = NOW()'; }
            $p[] = $id;
            Db::exec('UPDATE complaints SET ' . implode(', ', $sets) . ' WHERE id = ?', $p);

            if ($to === 'Resolved') {
                Db::exec("UPDATE complaint_assignments SET status = 'Completed', completed_at = NOW(), resolution_details = ? WHERE complaint_id = ? AND status = 'Active'", [$note, $id]);
                Db::exec("INSERT INTO complaint_comments (complaint_id, user_id, kind, body, is_internal) VALUES (?,?, 'resolution', ?, 0)", [$id, $actor['id'], $note]);
            }
            if ($from === 'Resolved' && $to === 'In Progress') {
                Db::exec("UPDATE complaint_assignments SET status = 'Active', completed_at = NULL
                           WHERE id = (SELECT id FROM (SELECT id FROM complaint_assignments WHERE complaint_id = ? AND status = 'Completed' ORDER BY id DESC LIMIT 1) x)", [$id]);
                Db::exec("INSERT INTO complaint_comments (complaint_id, user_id, kind, body, is_internal) VALUES (?,?, 'comment', ?, 0)", [$id, $actor['id'], 'Reopened: ' . $note]);
            }
            if ($to === Workflow::AWAITING) {
                Db::exec("INSERT INTO complaint_comments (complaint_id, user_id, kind, body, is_internal) VALUES (?,?, 'info_request', ?, 0)", [$id, $actor['id'], $note]);
            }
            Db::exec('INSERT INTO complaint_status_history (complaint_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)',
                [$id, $from, $to, $actor['id'], $note !== '' ? $note : null]);
            return [true, null, $c, $from];
        });

        if (!$outcome[0]) return [false, $outcome[1] === 'not_found' ? 'Complaint not found.' : $outcome[1]];
        [, , $c, $from] = $outcome;
        Audit::log('complaint.status', 'complaint', $id, ['from' => $from, 'to' => $to]);
        self::notifyStatus($c, $from, $to, $note, $actor);
        return [true, null];
    }

    private static function notifyStatus(array $c, string $from, string $to, string $note, array $actor): void
    {
        $ref = $c['reference_no'];
        $id = (int)$c['id'];
        $reps = array_merge(User::departmentRepIds((int)$c['department_id']), [(int)$c['submitted_by']]);
        $tech = $c['assigned_to'] ? [(int)$c['assigned_to']] : [];
        $me = (int)$actor['id'];
        $short = $note !== '' ? ' — ' . mb_substr($note, 0, 200) : '';

        switch (true) {
            case $to === 'Under Review':
                Notifier::send($reps, $id, 'status_changed', "$ref is under review", 'NIS is reviewing your complaint.' . $short, $me); break;
            case $to === 'Accepted':
                Notifier::send($reps, $id, 'complaint_accepted', "$ref accepted", 'Your complaint has been accepted and will be assigned to a technician.' . $short, $me); break;
            case $to === 'Rejected':
                Notifier::send($reps, $id, 'complaint_rejected', "$ref rejected", 'Your complaint was rejected.' . $short, $me); break;
            case $to === Workflow::AWAITING:
                Notifier::send($reps, $id, 'info_requested', "Information needed for $ref", $note, $me); break;
            case $to === 'In Progress' && $from === 'Resolved':
                Notifier::send(array_merge(User::staffIds(), $tech), $id, 'complaint_reopened', "$ref reopened", 'The department reports the problem is not resolved.' . $short, $me); break;
            case $to === 'In Progress':
                Notifier::send($reps, $id, 'status_changed', "Work started on $ref", 'A technician is now working on your complaint.', $me); break;
            case $to === 'Resolved':
                Notifier::send(array_merge($reps, User::staffIds()), $id, 'complaint_resolved', "$ref resolved", 'The complaint has been marked as resolved.' . $short, $me); break;
            case $to === 'Closed':
                Notifier::send(array_merge($reps, $tech), $id, 'complaint_closed', "$ref closed", 'The complaint has been closed.', $me); break;
        }
    }

    // ------------------------------------------------------------------ assignment
    /** @return array{0:bool,1:?string} */
    public static function assign(int $id, int $techId, string $instructions, array $actor): array
    {
        $instructions = trim($instructions);
        if (mb_strlen($instructions) > 2000) return [false, 'Instructions are too long (2000 characters maximum).'];

        $out = Db::tx(function () use ($id, $techId, $instructions, $actor) {
            $c = Db::one('SELECT * FROM complaints WHERE id = ? FOR UPDATE', [$id]);
            if (!$c) return [false, 'Complaint not found.'];
            if (in_array($c['status'], Workflow::FINISHED, true)) return [false, 'Resolved, closed or rejected complaints cannot be assigned.'];
            $tech = Db::one("SELECT u.id, u.full_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = ? AND r.slug = 'technician' AND u.is_active = 1", [$techId]);
            if (!$tech) return [false, 'Choose an active network technician.'];
            if ((int)$c['assigned_to'] === $techId) return [false, $tech['full_name'] . ' is already assigned to this complaint.'];

            $prev = Db::one("SELECT technician_id FROM complaint_assignments WHERE complaint_id = ? AND status = 'Active' LIMIT 1", [$id]);
            Db::exec("UPDATE complaint_assignments SET status = 'Reassigned', completed_at = NOW() WHERE complaint_id = ? AND status = 'Active'", [$id]);
            Db::exec('INSERT INTO complaint_assignments (complaint_id, technician_id, assigned_by, instructions) VALUES (?,?,?,?)',
                [$id, $techId, $actor['id'], $instructions !== '' ? $instructions : null]);

            $to = in_array($c['status'], ['Submitted', 'Under Review', 'Accepted'], true) ? 'Assigned' : $c['status'];
            Db::exec('UPDATE complaints SET assigned_to = ?, status = ? WHERE id = ?', [$techId, $to, $id]);
            Db::exec('INSERT INTO complaint_status_history (complaint_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)',
                [$id, $c['status'], $to, $actor['id'], ($prev ? 'Reassigned to ' : 'Assigned to ') . $tech['full_name']]);
            return [true, null, $c, $tech, $prev ? (int)$prev['technician_id'] : 0];
        });
        if (!$out[0]) return [false, $out[1]];
        [, , $c, $tech, $prevTech] = $out;
        $ref = $c['reference_no'];
        Audit::log('complaint.assign', 'complaint', $id, ['technician_id' => $techId, 'previous' => $prevTech]);
        Notifier::send([$techId], $id, 'complaint_assigned', "Assigned: $ref", "{$c['title']} ({$c['priority']} priority)" . ($instructions !== '' ? ' — ' . mb_substr($instructions, 0, 200) : ''), (int)$actor['id']);
        if ($prevTech) Notifier::send([$prevTech], $id, 'complaint_unassigned', "Reassigned: $ref", 'This complaint has been reassigned to another technician.', (int)$actor['id']);
        Notifier::send(array_merge(User::departmentRepIds((int)$c['department_id']), [(int)$c['submitted_by']]), $id, 'technician_assigned', "Technician assigned to $ref", $tech['full_name'] . ' has been assigned to your complaint.', (int)$actor['id']);
        return [true, null];
    }

    // ------------------------------------------------------------------ comments / updates
    /** @return array{0:bool,1:?string} */
    public static function addComment(int $id, array $actor, string $kind, string $body, bool $internal, ?array $file, array $fileMeta): array
    {
        $body = trim($body);
        if (mb_strlen($body) < 3) return [false, 'Please write a message (at least 3 characters).'];
        if (mb_strlen($body) > 5000) return [false, 'The message is too long (5000 characters maximum).'];

        $stored = null;
        try {
            $out = Db::tx(function () use ($id, $actor, $kind, $body, $internal, $file, $fileMeta, &$stored) {
                $c = Db::one('SELECT * FROM complaints WHERE id = ? FOR UPDATE', [$id]);
                if (!$c || !Complaint::accessible($id, $actor)) return [false, 'Complaint not found.'];
                if ($c['status'] === 'Closed') return [false, 'This complaint is closed and read-only.'];

                $returnTo = null;
                if (Auth::can('complaints.review')) {
                    $kind = 'comment';
                } elseif (Auth::can('complaints.work') && (int)$c['assigned_to'] === (int)$actor['id']) {
                    if (!in_array($kind, ['update', 'finding', 'work_performed'], true)) return [false, 'Choose the type of update.'];
                    if (!in_array($c['status'], ['Assigned', 'In Progress', Workflow::AWAITING], true)) return [false, 'You can only post updates while the complaint is active.'];
                } elseif (Auth::can('complaints.respond') && (int)$c['department_id'] === (int)$actor['department_id']) {
                    $internal = false;
                    $kind = 'comment';
                    if ($c['status'] === Workflow::AWAITING) { $kind = 'info_response'; $returnTo = $c['status_before_hold'] ?: 'Under Review'; }
                } else {
                    return [false, 'You are not allowed to comment on this complaint.'];
                }

                $cid = Db::insert('INSERT INTO complaint_comments (complaint_id, user_id, kind, body, is_internal) VALUES (?,?,?,?,?)', [$id, $actor['id'], $kind, $body, $internal ? 1 : 0]);

                if ($file && isset($fileMeta['ext'])) {
                    $s = Upload::store($file, $fileMeta);
                    $stored = $s['stored_name'];
                    Db::exec('INSERT INTO attachments (complaint_id, comment_id, uploaded_by, original_name, stored_name, mime_type, size_bytes, sha256) VALUES (?,?,?,?,?,?,?,?)',
                        [$id, $cid, $actor['id'], $s['original_name'], $s['stored_name'], $s['mime'], $s['size'], $s['sha256']]);
                }

                if (in_array($kind, ['update', 'finding', 'work_performed'], true)) {
                    $label = ['update' => 'Progress', 'finding' => 'Finding', 'work_performed' => 'Work performed'][$kind];
                    Db::exec("UPDATE complaint_assignments SET investigation_notes = CONCAT(COALESCE(investigation_notes, ''), ?)
                               WHERE complaint_id = ? AND status = 'Active'", ['[' . date('d M Y H:i') . "] $label: $body\n", $id]);
                }
                if ($returnTo !== null) {
                    self::extendDueAfterHold($id);
                    Db::exec('UPDATE complaints SET status = ?, status_before_hold = NULL WHERE id = ?', [$returnTo, $id]);
                    Db::exec('INSERT INTO complaint_status_history (complaint_id, from_status, to_status, changed_by, note) VALUES (?,?,?,?,?)',
                        [$id, Workflow::AWAITING, $returnTo, $actor['id'], 'Department responded']);
                }
                return [true, null, $c, $kind, $internal, $returnTo];
            });
        } catch (\Throwable $e) {
            if ($stored) Upload::remove($stored);
            throw $e;
        }
        if (!$out[0]) return [false, $out[1]];
        [, , $c, $kind, $internal, $returnTo] = $out;

        $ref = $c['reference_no'];
        $cid = (int)$c['id'];
        $me = (int)$actor['id'];
        $reps = array_merge(User::departmentRepIds((int)$c['department_id']), [(int)$c['submitted_by']]);
        $tech = $c['assigned_to'] ? [(int)$c['assigned_to']] : [];
        $snippet = mb_substr($body, 0, 250);
        Audit::log('complaint.comment', 'complaint', $cid, ['kind' => $kind, 'internal' => $internal]);

        if ($actor['role'] === 'department_rep') {
            Notifier::send($tech ?: User::staffIds(), $cid, $returnTo ? 'info_provided' : 'department_comment', ($returnTo ? 'Information provided for ' : 'New message on ') . $ref, "{$actor['full_name']}: $snippet", $me);
            if ($returnTo) Notifier::send(User::staffIds(), $cid, 'info_provided', "Information provided for $ref", "{$actor['department_name']} has responded.", $me);
        } elseif (!$internal) {
            Notifier::send(array_merge($reps, $actor['role'] === 'technician' ? [] : $tech), $cid, 'new_comment', "Update on $ref", "{$actor['full_name']}: $snippet", $me);
        } elseif ($actor['role'] !== 'technician') {
            Notifier::send($tech, $cid, 'internal_note', "Internal note on $ref", $snippet, $me);
        }
        return [true, null];
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Db, Request, Validator};
use App\Models\{Complaint, Department};

final class DepartmentController extends BaseController
{
    public function index(): void
    {
        $q = Request::get('q');
        $st = Request::get('status');
        $where = ['1=1']; $p = [];
        if ($q !== '') { $like = '%' . addcslashes($q, '%_\\') . '%'; $where[] = '(d.name LIKE ? OR d.code LIKE ?)'; array_push($p, $like, $like); }
        if ($st === 'active') $where[] = 'd.is_active = 1';
        if ($st === 'inactive') $where[] = 'd.is_active = 0';
        $w = implode(' AND ', $where);
        $per = $this->perPage();
        $total = (int)Db::val("SELECT COUNT(*) FROM departments d WHERE $w", $p);
        $pages = max(1, (int)ceil($total / $per));
        $page = min(max(1, Request::intGet('page')), $pages);
        $rows = Db::all("SELECT d.*,
                (SELECT COUNT(*) FROM complaints c WHERE c.department_id = d.id) AS complaints_total,
                (SELECT COUNT(*) FROM complaints c WHERE c.department_id = d.id AND c.status NOT IN ('Resolved','Closed','Rejected')) AS complaints_open,
                (SELECT COUNT(*) FROM users u WHERE u.department_id = d.id AND u.is_active = 1) AS reps
            FROM departments d WHERE $w ORDER BY d.name LIMIT $per OFFSET " . (($page - 1) * $per), $p);
        $this->render('departments/index', compact('rows', 'total', 'pages', 'page', 'q', 'st'), 'Departments');
    }

    public function create(): void
    {
        $this->render('departments/form', ['d' => null], 'Register department');
    }

    public function edit(): void
    {
        $d = Department::find(Request::intGet('id')) ?? abort(404);
        $this->render('departments/form', ['d' => $d], 'Edit department');
    }

    private function validate(int $exceptId): array
    {
        $_POST['code'] = strtoupper((string)($_POST['code'] ?? ''));
        $v = Validator::make($_POST, [
            'name' => 'required|min:3|max:150', 'code' => 'required|min:2|max:20', 'head_name' => 'name|max:120',
            'email' => 'email|max:150', 'phone' => 'phone', 'location' => 'max:150',
        ], ['name' => 'Department name', 'code' => 'Code', 'head_name' => 'Head of department']);
        if (!$v->fails() || !isset($v->errors()['code'])) {
            if (!preg_match('/^[A-Z0-9-]{2,20}$/', $v->get('code'))) $v->addError('code', 'Code may only contain letters, numbers and hyphens.');
        }
        if (!isset($v->errors()['name']) && Db::val('SELECT 1 FROM departments WHERE name = ? AND id <> ?', [$v->get('name'), $exceptId])) $v->addError('name', 'A department with this name already exists.');
        if (!isset($v->errors()['code']) && Db::val('SELECT 1 FROM departments WHERE code = ? AND id <> ?', [$v->get('code'), $exceptId])) $v->addError('code', 'This code is already in use.');
        return [$v, $exceptId];
    }

    public function store(): void
    {
        [$v] = $this->validate(0);
        if ($v->fails()) $this->invalid($v, 'departments/create');
        $d = $v->data();
        $id = Db::insert('INSERT INTO departments (name, code, head_name, email, phone, location) VALUES (?,?,?,?,?,?)',
            [$d['name'], $d['code'], $d['head_name'] ?: null, strtolower($d['email']) ?: null, $d['phone'] ?: null, $d['location'] ?: null]);
        Audit::log('department.create', 'department', $id, ['name' => $d['name']]);
        flash('success', 'Department registered. Add a representative so they can report complaints.');
        redirect('departments/view', ['id' => $id]);
    }

    public function update(): void
    {
        $id = Request::intPost('id');
        Department::find($id) ?? abort(404);
        [$v] = $this->validate($id);
        if ($v->fails()) $this->invalid($v, 'departments/edit', ['id' => $id]);
        $d = $v->data();
        Db::exec('UPDATE departments SET name=?, code=?, head_name=?, email=?, phone=?, location=? WHERE id=?',
            [$d['name'], $d['code'], $d['head_name'] ?: null, strtolower($d['email']) ?: null, $d['phone'] ?: null, $d['location'] ?: null, $id]);
        Audit::log('department.update', 'department', $id);
        flash('success', 'Department updated.');
        redirect('departments/view', ['id' => $id]);
    }

    public function toggle(): void
    {
        $id = Request::intPost('id');
        $d = Department::find($id) ?? abort(404);
        $new = (int)$d['is_active'] === 1 ? 0 : 1;
        Db::exec('UPDATE departments SET is_active = ? WHERE id = ?', [$new, $id]);
        Audit::log($new ? 'department.activate' : 'department.deactivate', 'department', $id);
        flash('success', $new ? 'Department activated.' : 'Department deactivated. Its representatives can no longer sign in.');
        redirect('departments/view', ['id' => $id]);
    }

    public function show(): void
    {
        $d = Department::find(Request::intGet('id')) ?? abort(404);
        $u = $this->user();
        $reps = Db::all("SELECT id, full_name, email, phone, is_active, last_login_at FROM users WHERE department_id = ? ORDER BY is_active DESC, full_name", [$d['id']]);
        $res = Complaint::search($u, ['department' => (string)$d['id']], Request::get('sort', 'created'), Request::get('dir', 'desc'), max(1, Request::intGet('page')), 10);
        $this->render('departments/show', ['d' => $d, 'stats' => Department::stats((int)$d['id']), 'reps' => $reps, 'res' => $res], $d['name']);
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Auth, Form, Validator, View};

abstract class BaseController
{
    protected function user(): array { return Auth::user() ?? abort(403); }

    protected function render(string $view, array $data = [], string $title = '', string $layout = 'app'): void
    {
        View::$title = $title;
        View::render($view, $data, $layout);
    }

    /** Remember input + errors, flash a notice and go back to the form. */
    protected function invalid(Validator|array $errors, string $route, array $query = []): never
    {
        $errs = $errors instanceof Validator ? $errors->errors() : $errors;
        Form::remember($_POST, $errs);
        flash('danger', 'Please correct the highlighted fields and try again.');
        redirect($route, $query);
    }

    protected function perPage(): int { return min(100, max(5, (int)setting('per_page', 15))); }

    protected function checkbox(string $key): bool { return isset($_POST[$key]) && $_POST[$key] === '1'; }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Auth, Db, Pdf, Request, Validator};
use App\Models\{Complaint, Department, User};
use App\Services\{ComplaintService, Upload, Workflow};

final class ComplaintController extends BaseController
{
    // ---------------------------------------------------------------- list
    public function index(): void
    {
        $u = $this->user();
        $f = [];
        foreach (['q', 'status', 'priority', 'category', 'department', 'technician', 'from', 'to', 'overdue'] as $k) $f[$k] = Request::get($k);
        $sort = Request::get('sort', 'created');
        $dir = Request::get('dir', 'desc');
        $res = Complaint::search($u, $f, $sort, $dir, max(1, Request::intGet('page')), $this->perPage());
        $staff = Auth::isStaff();
        $this->render('complaints/index', [
            'res' => $res, 'f' => $f, 'sort' => isset(Complaint::SORTS[$sort]) ? $sort : 'created', 'dir' => strtolower($dir) === 'asc' ? 'asc' : 'desc',
            'categories' => Complaint::categories(false), 'departments' => $staff ? Department::options(false) : [], 'technicians' => $staff ? User::technicians(false) : [],
            'staff' => $staff,
        ], $u['role'] === 'technician' ? 'My assignments' : ($u['role'] === 'department_rep' ? 'My department’s complaints' : 'All complaints'));
    }

    // ---------------------------------------------------------------- create
    public function create(): void
    {
        $u = $this->user();
        if ($u['role'] !== 'department_rep' || !$u['department_id']) abort(403, 'Only department representatives can report complaints.');
        $this->render('complaints/create', [
            'categories' => Complaint::categories(), 'u' => $u, 'maxMb' => (int)setting('max_upload_mb', 5), 'exts' => Upload::allowedExtensions(),
            'now' => date('Y-m-d\TH:i'),
        ], 'Report a network problem');
    }

    public function store(): void
    {
        $u = $this->user();
        if ($u['role'] !== 'department_rep' || !$u['department_id']) abort(403, 'Only department representatives can report complaints.');
        $v = Validator::make($_POST, [
            'reporter_name' => 'required|name', 'reporter_email' => 'required|email|max:150', 'reporter_phone' => 'required|phone',
            'title' => 'required|min:5|max:200', 'category_id' => 'required|int', 'description' => 'required|min:20|max:5000',
            'building' => 'required|min:2|max:150', 'room' => 'required|min:1|max:100', 'reported_at' => 'required|datetime',
            'priority' => 'required|in:' . implode(',', Workflow::PRIORITIES),
        ], ['reporter_name' => 'Reporter name', 'reporter_email' => 'Contact email', 'reporter_phone' => 'Contact phone', 'category_id' => 'Category',
            'description' => 'Description', 'building' => 'Building or location', 'room' => 'Office, room or block', 'reported_at' => 'Date and time']);

        if (!$v->fails() && !Db::val('SELECT 1 FROM complaint_categories WHERE id = ? AND is_active = 1', [(int)$v->get('category_id')])) $v->addError('category_id', 'Choose a valid category.');
        if (!$v->fails()) {
            $t = strtotime(str_replace('T', ' ', $v->get('reported_at')));
            if ($t > time() + 600) $v->addError('reported_at', 'The date and time cannot be in the future.');
            elseif ($t < strtotime('-1 year')) $v->addError('reported_at', 'The date cannot be more than a year ago.');
        }
        $file = $_FILES['attachment'] ?? null;
        $meta = Upload::inspect($file);
        if (isset($meta['error'])) $v->addError('attachment', $meta['error']);
        if ($v->fails()) $this->invalid($v, 'complaints/create');

        [$id, $ref] = ComplaintService::create($v->data(), $u, $meta, isset($meta['ext']) ? $file : null);
        flash('success', "Complaint submitted. Your reference number is $ref — keep it to track progress.");
        redirect('complaints/view', ['id' => $id]);
    }

    // ---------------------------------------------------------------- view
    private function load(): array
    {
        $u = $this->user();
        $id = Request::method() === 'POST' ? Request::intPost('id') : Request::intGet('id');
        $c = $id > 0 ? Complaint::find($id, $u) : null;
        if (!$c) abort(404);
        return [$u, $c];
    }

    public function show(): void
    {
        [$u, $c] = $this->load();
        $id = (int)$c['id'];
        $internalVisible = $u['role'] !== 'department_rep';
        Db::exec('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND complaint_id = ? AND is_read = 0', [$u['id'], $id]);

        $allowed = Workflow::allowed($u, $c);
        $isAssignedTech = $u['role'] === 'technician' && (int)$c['assigned_to'] === (int)$u['id'];
        $this->render('complaints/show', [
            'c' => $c, 'u' => $u,
            'history' => Complaint::history($id),
            'comments' => Complaint::comments($id, $internalVisible),
            'attachments' => Complaint::attachments($id, $internalVisible),
            'assignments' => $u['role'] === 'department_rep' ? [] : Complaint::assignments($id),
            'allowed' => $allowed,
            'canAssign' => Auth::can('complaints.assign') && !in_array($c['status'], Workflow::FINISHED, true),
            'technicians' => Auth::can('complaints.assign') ? User::technicians() : [],
            'canComment' => $c['status'] !== 'Closed' && (Auth::can('complaints.review') || ($isAssignedTech && in_array($c['status'], ['Assigned', 'In Progress', Workflow::AWAITING], true)) ||
                (Auth::can('complaints.respond') && (int)$c['department_id'] === (int)$u['department_id'])),
            'isStaff' => Auth::can('complaints.review'), 'isTech' => $isAssignedTech,
            'overdue' => Complaint::isOverdue($c), 'maxMb' => (int)setting('max_upload_mb', 5), 'exts' => Upload::allowedExtensions(),
        ], $c['reference_no']);
    }

    // ---------------------------------------------------------------- actions
    public function status(): void
    {
        [$u, $c] = $this->load();
        $to = Request::post('to');
        if (!in_array($to, Workflow::STATUSES, true)) { flash('danger', 'Choose a valid status.'); redirect('complaints/view', ['id' => $c['id']]); }
        [$ok, $err] = ComplaintService::transition((int)$c['id'], $to, Request::post('note'), $u);
        flash($ok ? 'success' : 'danger', $ok ? "Status changed to $to." : $err);
        redirect('complaints/view', ['id' => $c['id']]);
    }

    public function assign(): void
    {
        [$u, $c] = $this->load();
        [$ok, $err] = ComplaintService::assign((int)$c['id'], Request::intPost('technician_id'), Request::post('instructions'), $u);
        flash($ok ? 'success' : 'danger', $ok ? 'Technician assigned.' : $err);
        redirect('complaints/view', ['id' => $c['id']]);
    }

    public function comment(): void
    {
        [$u, $c] = $this->load();
        $file = $_FILES['attachment'] ?? null;
        $meta = Upload::inspect($file);
        if (isset($meta['error'])) { flash('danger', $meta['error']); redirect('complaints/view', ['id' => $c['id']]); }
        $internal = $u['role'] === 'technician' ? !$this->checkbox('visible') : $this->checkbox('internal');
        [$ok, $err] = ComplaintService::addComment((int)$c['id'], $u, Request::post('kind', 'comment'), Request::post('body'), $internal, isset($meta['ext']) ? $file : null, $meta);
        flash($ok ? 'success' : 'danger', $ok ? 'Message posted.' : $err);
        redirect('complaints/view', ['id' => $c['id']]);
    }

    // ---------------------------------------------------------------- print / pdf
    private function printable(): array
    {
        [$u, $c] = $this->load();
        $id = (int)$c['id'];
        return [$c, Complaint::history($id), Complaint::comments($id, false), Complaint::attachments($id, false)];
    }

    public function print(): void
    {
        [$c, $history, $comments, $attachments] = $this->printable();
        Audit::log('complaint.print', 'complaint', (int)$c['id']);
        $this->render('complaints/print', compact('c', 'history', 'comments', 'attachments'), $c['reference_no'], 'print');
    }

    public function pdf(): void
    {
        [$c, $history, $comments, $attachments] = $this->printable();
        Audit::log('complaint.pdf', 'complaint', (int)$c['id']);
        $pdf = new Pdf(false, $c['reference_no'] . ' · Generated ' . date('d M Y H:i') . ' · ' . setting('system_abbr', 'UCC NIS NSCMS'));
        $pdf->letterhead((string)setting('org_name', 'University of Cape Coast'), (string)setting('section_name', 'Network Infrastructure Section (NIS)'), 'Complaint ' . $c['reference_no']);
        $pdf->kv([
            'Status' => $c['status'], 'Priority' => $c['priority'], 'Department' => $c['department_name'], 'Category' => $c['category_name'],
            'Reported by' => $c['reporter_name'], 'Contact' => $c['reporter_email'] . ' / ' . $c['reporter_phone'],
            'Location' => $c['building'] . ', ' . $c['room'], 'Reported at' => fmt_dt($c['reported_at']),
            'Submitted' => fmt_dt($c['created_at']), 'Target resolution' => fmt_dt($c['due_at']),
            'Assigned technician' => $c['technician_name'] ?: 'Not yet assigned', 'Resolved at' => $c['resolved_at'] ? fmt_dt($c['resolved_at']) : '—',
        ]);
        $pdf->heading($c['title']);
        $pdf->text($c['description']);
        if ($c['rejection_reason']) { $pdf->heading('Reason for rejection'); $pdf->text($c['rejection_reason']); }
        $pdf->heading('Status history');
        $pdf->table(['When', 'Change', 'By', 'Note'], array_map(fn($h) => [fmt_dt($h['created_at']), ($h['from_status'] ? $h['from_status'] . ' > ' : '') . $h['to_status'], $h['full_name'], (string)$h['note']], $history), [2, 3.2, 2.2, 5]);
        if ($comments) {
            $pdf->heading('Updates and messages');
            foreach ($comments as $cm) {
                $pdf->text(fmt_dt($cm['created_at']) . ' · ' . $cm['full_name'] . ' (' . $cm['role_name'] . ')', 8, true, [0.45, 0.45, 0.5]);
                $pdf->text($cm['body']);
                $pdf->space(3);
            }
        }
        if ($attachments) {
            $pdf->heading('Attachments');
            foreach ($attachments as $a) $pdf->text($a['original_name'] . ' (' . human_size((int)$a['size_bytes']) . ')');
        }
        $pdf->download($c['reference_no'] . '.pdf');
    }

    // ---------------------------------------------------------------- tracking
    public function track(): void
    {
        $u = $this->user();
        $ref = strtoupper(Request::get('ref'));
        $c = null; $msg = null; $history = [];
        if ($ref !== '') {
            if (!preg_match('/^NIS-\d{4}-\d{5}$/', $ref)) {
                $msg = 'Reference numbers look like NIS-' . date('Y') . '-00001.';
            } else {
                $c = Complaint::findByReference($ref, $u);
                if ($c) $history = Complaint::history((int)$c['id']);
                else $msg = 'No complaint with that reference number was found in the records you can access.';
            }
        }
        $this->render('complaints/track', ['ref' => $ref, 'c' => $c, 'history' => $history, 'msg' => $msg, 'overdue' => $c ? Complaint::isOverdue($c) : false], 'Track a complaint');
    }

    // ---------------------------------------------------------------- attachment download
    public function download(): void
    {
        $u = $this->user();
        $a = Db::one('SELECT a.*, cm.is_internal FROM attachments a LEFT JOIN complaint_comments cm ON cm.id = a.comment_id WHERE a.id = ?', [Request::intGet('id')]);
        if (!$a || !Complaint::accessible((int)$a['complaint_id'], $u)) abort(404);
        if ((int)($a['is_internal'] ?? 0) === 1 && $u['role'] === 'department_rep') abort(404);
        $path = Upload::dir() . '/' . $a['stored_name'];
        if (!preg_match('/^[a-f0-9]{40}$/', $a['stored_name']) || !is_file($path)) abort(404, 'The file is no longer available.');

        Audit::log('attachment.download', 'attachment', (int)$a['id']);
        $name = Upload::cleanName($a['original_name']);
        header('Content-Type: ' . ($a['mime_type'] ?: 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . preg_replace('/[^A-Za-z0-9._ -]/', '_', $name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;

final class PageController extends BaseController
{
    public function terms(): void
    {
        $this->render('pages/terms', [], 'Terms of Service', Auth::check() && !$this->restricted() ? 'app' : 'auth');
    }

    public function help(): void
    {
        $this->render('pages/help', ['u' => $this->user()], 'Help & guidance');
    }

    private function restricted(): bool
    {
        $u = Auth::user();
        return $u && ((int)$u['must_change_password'] === 1 || ($u['terms_version'] ?? '') !== TERMS_VERSION);
    }
}

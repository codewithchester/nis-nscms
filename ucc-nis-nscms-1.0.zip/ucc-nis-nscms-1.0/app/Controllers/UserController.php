<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Db, Password, Request, Validator};
use App\Models\{Department, User};

final class UserController extends BaseController
{
    private function target(array $actor, int $id): array
    {
        $t = User::find($id) ?? abort(404);
        if (!in_array($t['role'], User::manageableRoles($actor), true)) abort(403);
        return $t;
    }

    public function index(): void
    {
        $actor = $this->user();
        $roles = User::manageableRoles($actor);
        $where = ['r.slug IN (' . Db::marks($roles) . ')'];
        $p = $roles;
        $q = Request::get('q'); $role = Request::get('role'); $dept = Request::intGet('department'); $st = Request::get('status');
        if ($q !== '') { $like = '%' . addcslashes($q, '%_\\') . '%'; $where[] = '(u.full_name LIKE ? OR u.email LIKE ?)'; array_push($p, $like, $like); }
        if (in_array($role, $roles, true)) { $where[] = 'r.slug = ?'; $p[] = $role; }
        if ($dept > 0) { $where[] = 'u.department_id = ?'; $p[] = $dept; }
        if ($st === 'active') $where[] = 'u.is_active = 1';
        if ($st === 'inactive') $where[] = 'u.is_active = 0';
        $w = implode(' AND ', $where);
        $per = $this->perPage();
        $total = (int)Db::val("SELECT COUNT(*) FROM users u JOIN roles r ON r.id = u.role_id WHERE $w", $p);
        $pages = max(1, (int)ceil($total / $per));
        $page = min(max(1, Request::intGet('page')), $pages);
        $rows = Db::all("SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.last_login_at, r.slug AS role, r.name AS role_name, d.name AS department_name
                           FROM users u JOIN roles r ON r.id = u.role_id LEFT JOIN departments d ON d.id = u.department_id
                          WHERE $w ORDER BY u.is_active DESC, r.id, u.full_name LIMIT $per OFFSET " . (($page - 1) * $per), $p);
        $this->render('users/index', ['rows' => $rows, 'total' => $total, 'page' => $page, 'pages' => $pages, 'q' => $q, 'role' => $role, 'dept' => $dept, 'st' => $st,
            'roles' => User::roles($roles), 'departments' => Department::options(false), 'actor' => $actor], 'Users');
    }

    public function create(): void
    {
        $actor = $this->user();
        $this->render('users/form', ['t' => null, 'roles' => User::roles(User::manageableRoles($actor)), 'departments' => Department::options(), 'preDept' => Request::intGet('department')], 'Add user');
    }

    public function edit(): void
    {
        $actor = $this->user();
        $t = $this->target($actor, Request::intGet('id'));
        $this->render('users/form', ['t' => $t, 'roles' => User::roles([$t['role']]), 'departments' => Department::options(false), 'preDept' => 0], 'Edit user');
    }

    private function validateCommon(array $actor, ?array $t): Validator
    {
        $v = Validator::make($_POST, ['full_name' => 'required|name', 'email' => 'required|email|max:150', 'phone' => 'phone'], ['full_name' => 'Full name']);
        if (!isset($v->errors()['email']) && User::emailTaken($v->get('email'), (int)($t['id'] ?? 0))) $v->addError('email', 'This email address is already registered.');
        return $v;
    }

    private function resolveDepartment(Validator $v, string $role): ?int
    {
        if ($role !== 'department_rep') return null;
        $id = Request::intPost('department_id');
        $d = $id ? Department::find($id) : null;
        if (!$d) { $v->addError('department_id', 'Choose the department this representative belongs to.'); return null; }
        return (int)$d['id'];
    }

    public function store(): void
    {
        $actor = $this->user();
        $allowed = User::manageableRoles($actor);
        $roleSlug = Request::post('role');
        $v = $this->validateCommon($actor, null);
        if (!in_array($roleSlug, $allowed, true)) $v->addError('role', 'Choose a role.');
        $dept = $this->resolveDepartment($v, $roleSlug);
        if ($v->fails()) $this->invalid($v, 'users/create');

        $roleId = (int)Db::val('SELECT id FROM roles WHERE slug = ?', [$roleSlug]);
        $temp = Password::generate();
        $id = Db::insert('INSERT INTO users (role_id, department_id, full_name, email, phone, password_hash, must_change_password, password_changed_at) VALUES (?,?,?,?,?,?,1,NULL)',
            [$roleId, $dept, $v->get('full_name'), strtolower($v->get('email')), $v->get('phone') ?: null, Password::hash($temp)]);
        Audit::log('user.create', 'user', $id, ['role' => $roleSlug]);
        flash('success', 'Account created for ' . $v->get('full_name') . '. Temporary password (shown once, share it securely): ' . $temp . ' — they must change it at first sign-in.');
        redirect('users');
    }

    public function update(): void
    {
        $actor = $this->user();
        $t = $this->target($actor, Request::intPost('id'));
        $v = $this->validateCommon($actor, $t);
        $dept = $this->resolveDepartment($v, $t['role']);
        if ($v->fails()) $this->invalid($v, 'users/edit', ['id' => $t['id']]);
        Db::exec('UPDATE users SET full_name=?, email=?, phone=?, department_id=? WHERE id=?',
            [$v->get('full_name'), strtolower($v->get('email')), $v->get('phone') ?: null, $dept, $t['id']]);
        Audit::log('user.update', 'user', (int)$t['id']);
        flash('success', 'User updated.');
        redirect('users');
    }

    public function toggle(): void
    {
        $actor = $this->user();
        $t = $this->target($actor, Request::intPost('id'));
        if ((int)$t['id'] === (int)$actor['id']) { flash('danger', 'You cannot deactivate your own account.'); redirect('users'); }
        $new = (int)$t['is_active'] === 1 ? 0 : 1;
        if ($new === 0 && $t['role'] === 'super_admin' && User::activeSuperAdmins() <= 1) { flash('danger', 'At least one active Super Administrator is required.'); redirect('users'); }
        Db::exec('UPDATE users SET is_active = ? WHERE id = ?', [$new, $t['id']]);
        Audit::log($new ? 'user.activate' : 'user.deactivate', 'user', (int)$t['id']);
        flash('success', $t['full_name'] . ($new ? ' activated.' : ' deactivated and signed out on their next request.'));
        redirect('users');
    }

    public function resetPassword(): void
    {
        $actor = $this->user();
        $t = $this->target($actor, Request::intPost('id'));
        if ((int)$t['id'] === (int)$actor['id']) { flash('danger', 'Use “Change password” to update your own password.'); redirect('users'); }
        $temp = Password::generate();
        Db::tx(function () use ($t, $temp) {
            Db::exec('UPDATE users SET password_hash = ?, must_change_password = 1 WHERE id = ?', [Password::hash($temp), $t['id']]);
            Db::exec('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$t['id']]);
        });
        Audit::log('user.password_reset', 'user', (int)$t['id']);
        flash('success', 'Temporary password for ' . $t['full_name'] . ' (shown once): ' . $temp . ' — they must change it at next sign-in.');
        redirect('users');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Db, Request};

final class NotificationController extends BaseController
{
    public function index(): void
    {
        $u = $this->user();
        $per = 20;
        $total = (int)Db::val('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [$u['id']]);
        $pages = max(1, (int)ceil($total / $per));
        $page = min(max(1, Request::intGet('page')), $pages);
        $items = Db::all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per), [$u['id']]);
        $this->render('notifications/index', ['items' => $items, 'page' => $page, 'pages' => $pages, 'total' => $total], 'Notifications');
    }

    public function read(): void
    {
        $u = $this->user();
        if ($this->checkbox('all')) {
            Db::exec('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$u['id']]);
        } else {
            Db::exec('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?', [Request::intPost('id'), $u['id']]);
        }
        redirect('notifications');
    }
}

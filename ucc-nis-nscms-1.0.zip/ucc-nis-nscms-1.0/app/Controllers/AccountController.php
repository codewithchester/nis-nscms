<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Auth, Csrf, Db, Password, Request, Session, Validator};
use App\Services\{ProfilePhoto, Upload};

final class AccountController extends BaseController
{
    private function profileStats(array $u): array
    {
        switch ($u['role']) {
            case 'department_rep':
                $counts = Db::one("SELECT COUNT(*) total,
                        SUM(status NOT IN ('Resolved','Closed','Rejected')) open_count,
                        SUM(status IN ('Resolved','Closed')) resolved
                    FROM complaints WHERE submitted_by = ? AND department_id = ?",
                    [(int)$u['id'], (int)$u['department_id']]) ?? [];
                return [
                    ['label' => 'Complaints submitted', 'value' => (int)($counts['total'] ?? 0)],
                    ['label' => 'Currently open', 'value' => (int)($counts['open_count'] ?? 0)],
                    ['label' => 'Resolved or closed', 'value' => (int)($counts['resolved'] ?? 0)],
                ];
            case 'technician':
                $counts = Db::one("SELECT COUNT(*) assigned,
                        SUM(status = 'Active') active,
                        SUM(status = 'Completed') completed
                    FROM complaint_assignments WHERE technician_id = ?", [(int)$u['id']]) ?? [];
                return [
                    ['label' => 'Assignments', 'value' => (int)($counts['assigned'] ?? 0)],
                    ['label' => 'Active tasks', 'value' => (int)($counts['active'] ?? 0)],
                    ['label' => 'Completed tasks', 'value' => (int)($counts['completed'] ?? 0)],
                ];
            default:
                $activity = (int)Db::val(
                    'SELECT COUNT(*) FROM audit_logs WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)',
                    [(int)$u['id']]
                );
                return [
                    ['label' => 'Recorded actions (30 days)', 'value' => $activity],
                    ['label' => 'Account status', 'value' => (int)$u['is_active'] === 1 ? 'Active' : 'Inactive'],
                ];
        }
    }

    private function layout(array $u): string
    {
        return ((int)$u['must_change_password'] === 1 || ($u['terms_version'] ?? '') !== TERMS_VERSION) ? 'auth' : 'app';
    }

    public function profile(): void
    {
        $u = $this->user();
        if (Request::method() === 'GET') {
            $photosAvailable = ProfilePhoto::available();
            $hasPhoto = ProfilePhoto::existsFor((int)$u['id']);
            $this->render('account/profile', [
                'u' => $u, 'stats' => $this->profileStats($u),
                'photosAvailable' => $photosAvailable, 'hasPhoto' => $hasPhoto,
                'maxMb' => (int)setting('max_upload_mb', 5),
            ], 'My profile');
            return;
        }
        $v = Validator::make($_POST, ['full_name' => 'required|name', 'phone' => 'phone']);
        $photoFile = $_FILES['profile_photo'] ?? null;
        $photoMeta = Upload::inspectProfilePhoto($photoFile);
        if (isset($photoMeta['error'])) $v->addError('profile_photo', $photoMeta['error']);
        if (isset($photoMeta['ext']) && !ProfilePhoto::available()) {
            $v->addError('profile_photo', 'Profile photo storage is not installed yet. Ask an administrator to apply the database migration.');
        }
        if ($v->fails()) $this->invalid($v, 'account/profile');

        $oldPhoto = null;
        $newPhoto = null;
        if (isset($photoMeta['ext'])) {
            $oldPhoto = Db::val('SELECT stored_name FROM user_profile_photos WHERE user_id = ?', [(int)$u['id']]);
            $newPhoto = Upload::store($photoFile, $photoMeta);
        }
        try {
            Db::tx(function () use ($u, $v, $newPhoto): void {
                Db::exec('UPDATE users SET full_name = ?, phone = ? WHERE id = ?', [$v->get('full_name'), $v->get('phone') ?: null, $u['id']]);
                if ($newPhoto) {
                    Db::exec('INSERT INTO user_profile_photos (user_id, stored_name, mime_type) VALUES (?,?,?)
                        ON DUPLICATE KEY UPDATE stored_name = VALUES(stored_name), mime_type = VALUES(mime_type)',
                        [(int)$u['id'], $newPhoto['stored_name'], $newPhoto['mime']]);
                }
            });
        } catch (\Throwable $e) {
            if ($newPhoto) Upload::remove($newPhoto['stored_name']);
            throw $e;
        }
        if ($oldPhoto && $newPhoto && $oldPhoto !== $newPhoto['stored_name']) Upload::remove((string)$oldPhoto);
        Audit::log('profile.update', 'user', (int)$u['id']);
        if ($newPhoto) Audit::log('profile.photo.updated', 'user', (int)$u['id']);
        flash('success', 'Profile updated.');
        redirect('account/profile');
    }

    public function photo(): void
    {
        $u = $this->user();
        if (!$this->photosAvailable()) abort(404);
        $photo = Db::one('SELECT stored_name, mime_type FROM user_profile_photos WHERE user_id = ?', [(int)$u['id']]);
        if (!$photo || !preg_match('/^[a-f0-9]{40}$/', $photo['stored_name'])
            || !in_array($photo['mime_type'], ['image/jpeg', 'image/png', 'image/webp'], true)) {
            abort(404, 'Profile photo not found.');
        }
        $path = Upload::dir() . '/' . $photo['stored_name'];
        if (!is_file($path)) abort(404, 'Profile photo not found.');

        header('Content-Type: ' . $photo['mime_type']);
        header('Content-Disposition: inline');
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'none'; sandbox");
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    public function password(): void
    {
        $u = $this->user();
        if (Request::method() === 'GET') {
            $this->render('account/password', ['forced' => (int)$u['must_change_password'] === 1], 'Change password', $this->layout($u));
            return;
        }
        $current = (string)($_POST['current_password'] ?? '');
        $new = (string)($_POST['new_password'] ?? '');
        $confirm = (string)($_POST['new_password_confirm'] ?? '');
        $hash = (string)Db::val('SELECT password_hash FROM users WHERE id = ?', [$u['id']]);
        $errors = [];
        if (!password_verify($current, $hash)) $errors['current_password'] = 'Your current password is incorrect.';
        elseif (($e = Password::policy($new, $u['email'], $u['full_name']))) $errors['new_password'] = $e;
        elseif ($new === $current) $errors['new_password'] = 'Choose a password different from your current one.';
        elseif (!hash_equals($new, $confirm)) $errors['new_password_confirm'] = 'The two passwords do not match.';
        if ($errors) $this->invalid($errors, 'account/password');

        Auth::password((int)$u['id'], $new);
        Session::regenerate();
        Csrf::rotate();
        Audit::log('password.changed', 'user', (int)$u['id']);
        flash('success', 'Password changed.');
        redirect('dashboard');
    }

    public function terms(): void
    {
        $u = $this->user();
        $this->render('account/terms', ['accepted' => ($u['terms_version'] ?? '') === TERMS_VERSION], 'Accept Terms of Service', $this->layout($u));
    }

    public function acceptTerms(): void
    {
        $u = $this->user();
        if (!$this->checkbox('agree')) {
            flash('danger', 'You must accept the Terms of Service to use the portal.');
            redirect('account/terms');
        }
        Db::exec('UPDATE users SET terms_version = ?, terms_accepted_at = NOW() WHERE id = ?', [TERMS_VERSION, $u['id']]);
        Audit::log('terms.accepted', 'user', (int)$u['id'], ['version' => TERMS_VERSION]);
        redirect('dashboard');
    }
}

<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\Auth;
use App\Services\DashboardService;

final class DashboardController extends BaseController
{
    public function index(): void
    {
        $u = $this->user();
        switch ($u['role']) {
            case 'super_admin':
            case 'nis_admin':
                $this->render('dashboard/admin', DashboardService::admin($u, Auth::can('analytics.view')) + ['charts_enabled' => Auth::can('analytics.view')], 'Dashboard');
                return;
            case 'technician':
                $this->render('dashboard/technician', DashboardService::technician($u), 'My work');
                return;
            default:
                $this->render('dashboard/department', DashboardService::department($u), 'Dashboard');
        }
    }
}

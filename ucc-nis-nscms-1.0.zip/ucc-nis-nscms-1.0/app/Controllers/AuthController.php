<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Auth, Db, Mailer, Password, Request, Validator};

final class AuthController extends BaseController
{
    public function login(): void
    {
        if (Request::method() === 'GET') {
            $this->render('auth/login', [], 'Sign in', 'auth');
            return;
        }
        $email = strtolower(Request::post('email'));
        $pw = (string)($_POST['password'] ?? '');
        if ($email === '' || $pw === '' || strlen($pw) > 200 || strlen($email) > 150) {
            $this->invalid(['email' => 'Enter your email address and password.'], 'auth/login');
        }
        [$ok, $err] = Auth::attempt($email, $pw);
        if (!$ok) {
            \App\Core\Form::remember(['email' => $email], []);
            flash('danger', $err ?? 'Sign in failed.');
            redirect('auth/login');
        }
        $next = $_SESSION['intended'] ?? null;
        unset($_SESSION['intended']);
        if (is_array($next) && isset($next['r']) && preg_match('~^[a-z0-9/_-]{1,50}$~', (string)$next['r']) && isset((require APP_ROOT . '/config/routes.php')[$next['r']])
            && in_array('GET', (require APP_ROOT . '/config/routes.php')[$next['r']][1], true)) {
            redirect($next['r'], ['id' => (int)($next['id'] ?? 0) ?: null]);
        }
        redirect('dashboard');
    }

    public function logout(): void
    {
        Auth::logout();
        flash('success', 'You have been signed out.');
        redirect('auth/login');
    }

    public function forgot(): void
    {
        if (Request::method() === 'GET') {
            $this->render('auth/forgot', [], 'Forgot password', 'auth');
            return;
        }
        $generic = 'If an active account exists for that email address, a password reset link has been sent. The link expires in 60 minutes.';
        $email = strtolower(Request::post('email'));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $this->invalid(['email' => 'Enter a valid email address.'], 'auth/forgot');

        if (!Auth::throttle('forgot', 5, 15)) {
            flash('warning', 'Too many reset requests. Please wait a few minutes and try again.');
            redirect('auth/forgot');
        }
        $u = Db::one('SELECT id, full_name, email FROM users WHERE email = ? AND is_active = 1', [$email]);
        if ($u) {
            $token = bin2hex(random_bytes(32));
            Db::tx(function () use ($u, $token) {
                Db::exec('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$u['id']]);
                Db::exec('INSERT INTO password_resets (user_id, token_hash, expires_at, requested_ip) VALUES (?,?,?,?)',
                    [$u['id'], hash('sha256', $token), date('Y-m-d H:i:s', time() + 3600), Request::ip()]);
            });
            $link = abs_url('auth/reset', ['token' => $token]);
            Mailer::send($u['email'], 'Reset your UCC NIS portal password',
                '<p>Hello ' . e($u['full_name']) . ',</p><p>We received a request to reset your password. This link works once and expires in 60 minutes:</p><p><a href="' . e($link) . '">Reset my password</a></p><p>If you did not ask for this, ignore this email — your password stays the same.</p>',
                "Hello {$u['full_name']},\n\nReset your password (valid 60 minutes, single use):\n$link\n\nIf you did not request this, ignore this email.\n");
            Audit::log('password.reset_requested', 'user', (int)$u['id'], [], (int)$u['id']);
        }
        flash('success', $generic);
        redirect('auth/forgot');
    }

    private function findToken(string $token): ?array
    {
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) return null;
        return Db::one('SELECT pr.id, pr.user_id FROM password_resets pr JOIN users u ON u.id = pr.user_id
                         WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW() AND u.is_active = 1', [hash('sha256', $token)]);
    }

    public function reset(): void
    {
        $token = Request::method() === 'POST' ? Request::post('token') : Request::get('token');
        $row = $this->findToken($token);
        if (!$row) {
            flash('danger', 'This reset link is invalid or has expired. Request a new one.');
            redirect('auth/forgot');
        }
        if (Request::method() === 'GET') {
            $this->render('auth/reset', ['token' => $token], 'Choose a new password', 'auth');
            return;
        }
        $pw = (string)($_POST['password'] ?? '');
        $confirm = (string)($_POST['password_confirm'] ?? '');
        $user = Db::one('SELECT email, full_name FROM users WHERE id = ?', [$row['user_id']]);
        $err = Password::policy($pw, $user['email'] ?? '', $user['full_name'] ?? '');
        if (!$err && !hash_equals($pw, $confirm)) $err = 'The two passwords do not match.';
        if ($err) {
            flash('danger', $err);
            redirect('auth/reset', ['token' => $token]);
        }
        Db::tx(function () use ($row, $pw) {
            $claimed = Db::exec('UPDATE password_resets SET used_at = NOW() WHERE id = ? AND used_at IS NULL', [$row['id']]);
            if ($claimed !== 1) throw new \RuntimeException('Token already used');
            Auth::password((int)$row['user_id'], $pw);
            Db::exec('UPDATE password_resets SET used_at = NOW() WHERE user_id = ? AND used_at IS NULL', [$row['user_id']]);
            Db::exec('DELETE FROM login_attempts WHERE identifier = ?', [hash('sha256', strtolower((string)Db::val('SELECT email FROM users WHERE id = ?', [$row['user_id']])))]);
        });
        Audit::log('password.reset_completed', 'user', (int)$row['user_id'], [], (int)$row['user_id']);
        flash('success', 'Your password has been changed. Sign in with your new password.');
        redirect('auth/login');
    }
}

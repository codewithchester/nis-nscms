<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Db, Request};

final class AuditController extends BaseController
{
    public function index(): void
    {
        $q = Request::get('q'); $action = Request::get('action'); $from = Request::get('from'); $to = Request::get('to');
        $where = ['1=1']; $p = [];
        if ($q !== '') { $like = '%' . addcslashes($q, '%_\\') . '%'; $where[] = '(u.full_name LIKE ? OR u.email LIKE ? OR a.ip_address LIKE ? OR a.details LIKE ?)'; array_push($p, $like, $like, $like, $like); }
        if ($action !== '' && preg_match('/^[a-z_.]{1,60}$/', $action)) { $where[] = 'a.action = ?'; $p[] = $action; }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) { $where[] = 'a.created_at >= ?'; $p[] = $from . ' 00:00:00'; }
        if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) { $where[] = 'a.created_at < ?'; $p[] = date('Y-m-d', strtotime($to . ' +1 day')) . ' 00:00:00'; }
        $w = implode(' AND ', $where);
        $per = 30;
        $total = (int)Db::val("SELECT COUNT(*) FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE $w", $p);
        $pages = max(1, (int)ceil($total / $per));
        $page = min(max(1, Request::intGet('page')), $pages);
        $rows = Db::all("SELECT a.*, u.full_name, u.email FROM audit_logs a LEFT JOIN users u ON u.id = a.user_id WHERE $w ORDER BY a.id DESC LIMIT $per OFFSET " . (($page - 1) * $per), $p);
        $actions = array_column(Db::all('SELECT DISTINCT action FROM audit_logs ORDER BY action'), 'action');
        $this->render('settings/audit', compact('rows', 'total', 'page', 'pages', 'q', 'action', 'from', 'to', 'actions'), 'Audit log');
    }
}

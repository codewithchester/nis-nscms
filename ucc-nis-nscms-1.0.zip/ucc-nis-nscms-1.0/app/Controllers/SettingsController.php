<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Auth, Db, Env, Request, Request as R, Settings, Validator};

final class SettingsController extends BaseController
{
    private const INT_RULES = [
        'sla_hours_critical' => [1, 720, 'Critical target (hours)'], 'sla_hours_high' => [1, 2160, 'High target (hours)'],
        'sla_hours_medium' => [1, 8760, 'Medium target (hours)'], 'sla_hours_low' => [1, 8760, 'Low target (hours)'],
        'per_page' => [5, 100, 'Rows per page'], 'max_upload_mb' => [1, 25, 'Maximum upload size (MB)'],
        'session_timeout_min' => [5, 240, 'Session timeout (minutes)'], 'recurring_threshold' => [2, 50, 'Recurring problem threshold'],
    ];

    public function index(): void
    {
        $this->render('settings/index', [
            'env' => [
                'Environment' => Env::isProduction() ? 'production' : 'local / development',
                'HTTPS' => R::isHttps() ? 'Yes' : 'No (use HTTPS in production)',
                'Mail driver' => strtoupper((string)Env::get('MAIL_DRIVER', 'log')) . (strtolower((string)Env::get('MAIL_DRIVER', 'log')) === 'smtp' ? ' (' . (Env::get('MAIL_HOST') ?: 'host not set') . ')' : ' (messages written to storage/logs/mail.log)'),
                'PHP version' => PHP_VERSION,
                'PHP upload limit' => ini_get('upload_max_filesize') . ' per file, ' . ini_get('post_max_size') . ' per request',
                'Installer present' => is_dir(APP_ROOT . '/install') ? 'YES - delete the /install folder' : 'No',
                'Time zone' => date_default_timezone_get(),
            ],
        ], 'System settings');
    }

    public function save(): void
    {
        $v = Validator::make($_POST, [
            'system_name' => 'required|min:5|max:150', 'org_name' => 'required|max:150', 'section_name' => 'required|max:150',
            'support_email' => 'email|max:150', 'support_phone' => 'phone',
        ], ['system_name' => 'System name', 'org_name' => 'Institution name', 'section_name' => 'Section name', 'support_email' => 'Support email', 'support_phone' => 'Support phone']);
        $ints = [];
        foreach (self::INT_RULES as $key => [$min, $max, $label]) {
            $val = Request::post($key);
            if (!ctype_digit($val) || (int)$val < $min || (int)$val > $max) $v->addError($key, "$label must be between $min and $max.");
            else $ints[$key] = (string)(int)$val;
        }
        if ($v->fails()) $this->invalid($v, 'settings');

        $changes = [];
        foreach (['system_name', 'org_name', 'section_name', 'support_email', 'support_phone'] as $k) { Settings::set($k, $v->get($k)); }
        foreach ($ints as $k => $val) { if ((string)Settings::get($k) !== $val) $changes[$k] = $val; Settings::set($k, $val); }
        $email = $this->checkbox('email_enabled') ? '1' : '0';
        Settings::set('email_enabled', $email);
        Audit::log('settings.update', 'settings', null, $changes + ['email_enabled' => $email]);
        flash('success', 'Settings saved.');
        redirect('settings');
    }

    public function categories(): void
    {
        $rows = Db::all('SELECT c.*, (SELECT COUNT(*) FROM complaints x WHERE x.category_id = c.id) AS used FROM complaint_categories c ORDER BY c.sort_order, c.name');
        $this->render('settings/categories', ['rows' => $rows], 'Complaint categories');
    }

    public function categorySave(): void
    {
        $id = Request::intPost('id');
        $v = Validator::make($_POST, ['name' => 'required|min:3|max:100', 'sort_order' => 'int'], ['name' => 'Category name', 'sort_order' => 'Order']);
        if (!$v->fails() && Db::val('SELECT 1 FROM complaint_categories WHERE name = ? AND id <> ?', [$v->get('name'), $id])) $v->addError('name', 'That category already exists.');
        if ($v->fails()) { flash('danger', implode(' ', $v->errors())); redirect('settings/categories'); }
        $sort = min(999, (int)($v->get('sort_order') ?: 99));
        if ($id > 0) {
            if (!Db::val('SELECT 1 FROM complaint_categories WHERE id = ?', [$id])) abort(404);
            Db::exec('UPDATE complaint_categories SET name = ?, sort_order = ?, is_active = ? WHERE id = ?', [$v->get('name'), $sort, $this->checkbox('is_active') ? 1 : 0, $id]);
            Audit::log('category.update', 'category', $id, ['name' => $v->get('name')]);
            flash('success', 'Category updated.');
        } else {
            $nid = Db::insert('INSERT INTO complaint_categories (name, sort_order) VALUES (?,?)', [$v->get('name'), $sort]);
            Audit::log('category.create', 'category', $nid, ['name' => $v->get('name')]);
            flash('success', 'Category added.');
        }
        redirect('settings/categories');
    }

    public function permissions(): void
    {
        $roles = Db::all("SELECT id, slug, name FROM roles WHERE slug <> 'super_admin' ORDER BY id");
        $grants = [];
        foreach (Db::all('SELECT rp.role_id, p.code FROM role_permissions rp JOIN permissions p ON p.id = rp.permission_id') as $g) $grants[$g['role_id']][$g['code']] = true;
        $this->render('settings/permissions', ['roles' => $roles, 'grants' => $grants, 'catalog' => Auth::catalog()], 'Roles & permissions');
    }

    public function permissionsSave(): void
    {
        $catalog = Auth::catalog();
        $roles = Db::all("SELECT id, slug FROM roles WHERE slug <> 'super_admin'");
        $posted = $_POST['grant'] ?? [];
        $perms = array_column(Db::all('SELECT id, code FROM permissions'), 'id', 'code');
        Db::tx(function () use ($roles, $catalog, $posted, $perms) {
            foreach ($roles as $r) {
                Db::exec('DELETE FROM role_permissions WHERE role_id = ?', [$r['id']]);
                foreach ($catalog as $code => $def) {
                    if (!in_array($r['slug'], $def['roles'], true) || !isset($perms[$code])) continue;
                    if (is_array($posted) && isset($posted[$r['slug']][$code]) && $posted[$r['slug']][$code] === '1') {
                        Db::exec('INSERT INTO role_permissions (role_id, permission_id) VALUES (?,?)', [$r['id'], $perms[$code]]);
                    }
                }
            }
        });
        Audit::log('permissions.update', 'permissions');
        flash('success', 'Permissions updated. Changes apply on the next request.');
        redirect('settings/permissions');
    }
}

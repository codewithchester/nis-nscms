<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Db, Request};
use App\Models\User;

final class TechnicianController extends BaseController
{
    public function index(): void
    {
        $rows = Db::all("SELECT u.id, u.full_name, u.email, u.phone, u.is_active, u.last_login_at,
              (SELECT COUNT(*) FROM complaints c WHERE c.assigned_to = u.id AND c.status NOT IN ('Resolved','Closed','Rejected')) AS open_count,
              (SELECT COUNT(*) FROM complaints c WHERE c.assigned_to = u.id AND c.status = 'In Progress') AS in_progress,
              (SELECT COUNT(*) FROM complaints c WHERE c.assigned_to = u.id AND c.status NOT IN ('Awaiting Department Response','Resolved','Closed','Rejected') AND c.due_at < NOW()) AS overdue,
              (SELECT COUNT(*) FROM complaint_assignments a WHERE a.technician_id = u.id AND a.status = 'Completed') AS completed,
              (SELECT AVG(TIMESTAMPDIFF(MINUTE, a.assigned_at, a.completed_at)) / 60 FROM complaint_assignments a WHERE a.technician_id = u.id AND a.status = 'Completed') AS avg_hours,
              (SELECT MAX(cm.created_at) FROM complaint_comments cm WHERE cm.user_id = u.id) AS last_activity
            FROM users u JOIN roles r ON r.id = u.role_id WHERE r.slug = 'technician' ORDER BY u.is_active DESC, u.full_name");
        $this->render('technicians/index', ['rows' => $rows], 'Technicians');
    }

    public function show(): void
    {
        $t = User::find(Request::intGet('id'));
        if (!$t || $t['role'] !== 'technician') abort(404);
        $id = (int)$t['id'];
        $assignments = Db::all("SELECT a.id, a.status AS assignment_status, a.assigned_at, a.completed_at, a.resolution_details, c.id AS complaint_id, c.reference_no, c.title, c.priority, c.status, d.name AS department_name, b.full_name AS assigner
                                  FROM complaint_assignments a JOIN complaints c ON c.id = a.complaint_id JOIN departments d ON d.id = c.department_id JOIN users b ON b.id = a.assigned_by
                                 WHERE a.technician_id = ? ORDER BY a.assigned_at DESC, a.id DESC LIMIT 50", [$id]);
        $activity = Db::all("SELECT cm.kind, cm.body, cm.is_internal, cm.created_at, c.id AS complaint_id, c.reference_no FROM complaint_comments cm JOIN complaints c ON c.id = cm.complaint_id
                              WHERE cm.user_id = ? ORDER BY cm.id DESC LIMIT 15", [$id]);
        $this->render('technicians/show', ['t' => $t, 'assignments' => $assignments, 'activity' => $activity], $t['full_name']);
    }
}

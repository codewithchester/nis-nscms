<?php
declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Audit, Pdf, Request};
use App\Models\{Complaint, Department, User};
use App\Services\{ReportService, Workflow};

final class ReportController extends BaseController
{
    private function reportReference(): string
    {
        return 'UCC-NIS-RPT-' . date('Ymd-His') . '-' . strtoupper(bin2hex(random_bytes(3)));
    }

    public function index(): void
    {
        $f = ReportService::filters($_GET);
        $user = $this->user();
        $reference = $this->reportReference();
        Audit::log('report.generated', null, null, ['reference' => $reference, 'filters' => $f]);
        $this->render('reports/index', [
            'r' => ReportService::build($f, 100), 'f' => $f,
            'departments' => Department::options(false), 'categories' => Complaint::categories(false), 'technicians' => User::technicians(false),
            'reference' => $reference, 'generatedAt' => date('d M Y, H:i'), 'by' => $user['full_name'],
            'filterLabels' => ReportService::describeFilters($f),
        ], 'Reports');
    }

    public function print(): void
    {
        $f = ReportService::filters($_GET);
        $user = $this->user();
        $reference = $this->reportReference();
        Audit::log('report.print', null, null, ['reference' => $reference, 'filters' => $f]);
        $this->render('reports/print', [
            'r' => ReportService::build($f, 500), 'f' => $f, 'by' => $user['full_name'],
            'reference' => $reference, 'generatedAt' => date('d M Y, H:i'),
            'filterLabels' => ReportService::describeFilters($f),
        ], 'Complaint report', 'print');
    }

    public function csv(): void
    {
        $f = ReportService::filters($_GET);
        $reference = $this->reportReference();
        Audit::log('report.csv', null, null, ['reference' => $reference, 'filters' => $f]);
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="nis-complaints-' . date('Ymd-His') . '.csv"');
        header('X-Report-Reference: ' . $reference);
        $out = fopen('php://output', 'w');
        if ($out === false) throw new \RuntimeException('Could not open the CSV output stream.');
        fwrite($out, "\xEF\xBB\xBF");
        $head = ['Reference', 'Title', 'Department', 'Category', 'Priority', 'Status', 'Building', 'Room', 'Reported by', 'Technician', 'Submitted', 'Reported at', 'Target date', 'Resolved at', 'Resolution hours'];
        fputcsv($out, $head, ',', '"', '\\');
        foreach (ReportService::streamRows($f) as $r) {
            $line = [$r['reference_no'], $r['title'], $r['department_name'], $r['category_name'], $r['priority'], $r['status'], $r['building'], $r['room'], $r['reporter_name'],
                $r['technician_name'], $r['created_at'], $r['reported_at'], $r['due_at'], $r['resolved_at'], $r['resolution_hours']];
            $line = array_map([ReportService::class, 'csvSafeCell'], $line);
            fputcsv($out, $line, ',', '"', '\\');
        }
        fclose($out);
        exit;
    }

    public function pdf(): void
    {
        $f = ReportService::filters($_GET);
        $user = $this->user();
        $reference = $this->reportReference();
        Audit::log('report.pdf', null, null, ['reference' => $reference, 'filters' => $f]);
        $rowLimit = 500;
        $r = ReportService::build($f, $rowLimit);
        $s = $r['summary'];
        $pdf = new Pdf(true, $reference . ' · Generated ' . date('d M Y H:i') . ' by ' . $user['full_name'] . ' · ' . setting('system_abbr', 'UCC NIS NSCMS'));
        $pdf->letterhead((string)setting('org_name', 'University of Cape Coast'), (string)setting('section_name', 'Network Infrastructure Section (NIS)'), 'Network complaints report');
        $pdf->text('Report reference: ' . $reference . ' · Generated: ' . date('d M Y, H:i') . ' · Prepared by: ' . $user['full_name'], 9, false, [0.4, 0.4, 0.45]);
        $pdf->heading('Applied filters');
        $pdf->kv(ReportService::describeFilters($f), 3);
        $pdf->kv(['Total complaints' => $s['total'], 'Resolved or closed' => $s['resolved'], 'Unresolved' => $s['unresolved'], 'Overdue' => $s['overdue'],
            'Average resolution time' => hours_label($s['avg_hours']), 'Resolved within target' => $s['sla_pct'] === null ? '—' : $s['sla_pct'] . '%'], 6);
        $pdf->heading('Most frequently reported problems');
        $pdf->table(['Category', 'Complaints', 'Resolved', 'Avg resolution'], array_map(fn($x) => [$x['name'], $x['total'], (int)$x['resolved'], hours_label($x['avg_hours'])], $r['by_category']), [6, 1.5, 1.5, 2]);
        $pdf->heading('Departments by complaint volume');
        $pdf->table(['Department', 'Total', 'Open', 'Resolved', 'Avg resolution'], array_map(fn($x) => [$x['name'], $x['total'], (int)$x['open_count'], (int)$x['resolved'], hours_label($x['avg_hours'])], $r['by_department']), [6, 1.2, 1.2, 1.4, 2]);
        $pdf->heading('Recurring problems (' . $r['recurring_threshold'] . '+ occurrences, same department, category and building)');
        $pdf->table(['Department', 'Category', 'Building', 'Count', 'Last reported'], array_map(fn($x) => [$x['department'], $x['category'], $x['building'], $x['occurrences'], fmt_d($x['last_reported'])], $r['recurring']), [4, 4, 3, 1, 2]);
        $pdf->heading('Technician performance');
        $pdf->table(['Technician', 'Assigned', 'Completed', 'Active', 'Avg time to complete'], array_map(fn($x) => [$x['full_name'], $x['assigned'], (int)$x['completed'], (int)$x['active'], hours_label($x['avg_hours'])], $r['technicians']), [5, 1.5, 1.5, 1.5, 2.5]);
        $pdf->heading('Unresolved complaints');
        $pdf->table(['Reference', 'Title', 'Department', 'Priority', 'Status', 'Age (days)', 'Overdue'], array_map(fn($x) => [$x['reference_no'], $x['title'], $x['department_name'], $x['priority'], $x['status'], $x['age_days'], $x['is_overdue'] ? 'Yes' : 'No'], $r['unresolved']), [2, 5, 4, 1.4, 2.6, 1.2, 1.2]);
        $pdf->heading('Complaint details (latest ' . $rowLimit . ' records)');
        $pdf->table(['Reference', 'Title', 'Department', 'Category', 'Priority', 'Status', 'Technician', 'Submitted', 'Resolved'], array_map(
            fn($x) => [$x['reference_no'], $x['title'], $x['department_name'], $x['category_name'], $x['priority'], $x['status'], $x['technician_name'] ?: 'Unassigned', fmt_d($x['created_at']), fmt_d($x['resolved_at'])],
            $r['rows']
        ), [2, 4, 2.6, 2.4, 1.3, 2.3, 2.5, 2, 2]);
        $pdf->download('nis-report-' . date('Ymd') . '.pdf');
    }
}

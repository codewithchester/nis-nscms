<div class="page-head"><div><h2>Departments</h2><p>Register university departments and manage who can report on their behalf.</p></div>
  <a class="btn btn-primary" href="<?= e(url('departments/create')) ?>"><?= icon('plus-circle') ?> Register department</a></div>
<div class="panel">
  <form class="filters" method="get" action="<?= e(url('departments')) ?>" data-noguard>
    <input type="hidden" name="r" value="departments">
    <div><label class="form-label" for="q">Search</label><input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Name or code" maxlength="100"></div>
    <div><label class="form-label" for="status">Status</label><select class="form-select" id="status" name="status"><option value="">All</option><option value="active"<?= $st === 'active' ? ' selected' : '' ?>>Active</option><option value="inactive"<?= $st === 'inactive' ? ' selected' : '' ?>>Inactive</option></select></div>
    <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Filter</button><?php if ($q !== '' || $st !== ''): ?><a class="btn btn-outline-secondary" href="<?= e(url('departments')) ?>">Clear</a><?php endif; ?></div>
  </form>
  <?php if (!$rows): ?>
    <div class="empty"><div class="glyph"><?= icon('building') ?></div><h3><?= ($q !== '' || $st !== '') ? 'No departments match' : 'No departments yet' ?></h3><p>Register the first department, then add a representative so they can sign in and report problems.</p>
      <a class="btn btn-primary" href="<?= e(url('departments/create')) ?>">Register department</a></div>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Department</th><th>Code</th><th>Location</th><th class="num">Reps</th><th class="num">Complaints</th><th class="num">Open</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($rows as $d): ?>
    <tr><td class="title-cell"><a href="<?= e(url('departments/view', ['id' => $d['id']])) ?>"><?= e($d['name']) ?></a><?php if ($d['head_name']): ?><div class="small text-muted">Head: <?= e($d['head_name']) ?></div><?php endif; ?></td>
      <td class="mono"><?= e($d['code']) ?></td><td class="small"><?= e($d['location'] ?: '—') ?></td>
      <td class="num"><?= (int)$d['reps'] ?></td><td class="num"><?= (int)$d['complaints_total'] ?></td><td class="num"><?= (int)$d['complaints_open'] ?></td>
      <td><?= $d['is_active'] ? '<span class="pill st-resolved">Active</span>' : '<span class="pill st-closed">Inactive</span>' ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
  <?php $query = ['q' => $q, 'status' => $st]; $route = 'departments'; $label = 'departments'; include APP_ROOT . '/app/Views/partials/pagination.php'; ?>
  <?php endif; ?>
</div>

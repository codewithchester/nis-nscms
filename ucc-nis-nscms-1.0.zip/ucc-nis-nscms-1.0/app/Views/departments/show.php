<?php $s = $stats; ?>
<div class="page-head">
  <div><h2><?= e($d['name']) ?> <?= $d['is_active'] ? '<span class="pill st-resolved">Active</span>' : '<span class="pill st-closed">Inactive</span>' ?></h2>
    <p><span class="mono"><?= e($d['code']) ?></span><?= $d['location'] ? ' · ' . e($d['location']) : '' ?><?= $d['head_name'] ? ' · Head: ' . e($d['head_name']) : '' ?></p></div>
  <div class="d-flex gap-2">
    <a class="btn btn-outline-secondary" href="<?= e(url('departments/edit', ['id' => $d['id']])) ?>">Edit</a>
    <form method="post" action="<?= e(url('departments/toggle')) ?>" data-confirm="<?= $d['is_active'] ? 'Deactivate this department? Its representatives will not be able to sign in.' : 'Activate this department?' ?>">
      <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
      <button class="btn <?= $d['is_active'] ? 'btn-outline-danger' : 'btn-primary' ?>" type="submit"><?= $d['is_active'] ? 'Deactivate' : 'Activate' ?></button></form>
  </div>
</div>
<div class="ledger mb-3">
  <div class="cell"><div class="n"><?= (int)($s['total'] ?? 0) ?></div><div class="l">Total complaints</div></div>
  <div class="cell"><div class="n"><?= (int)($s['open_count'] ?? 0) ?></div><div class="l">Open</div></div>
  <div class="cell"><div class="n"><?= (int)($s['resolved'] ?? 0) ?></div><div class="l">Resolved or closed</div></div>
  <div class="cell"><div class="n"><?= (int)($s['rejected'] ?? 0) ?></div><div class="l">Rejected</div></div>
  <div class="cell"><div class="n"><?= e(hours_label($s['avg_hours'] ?? null)) ?></div><div class="l">Avg. resolution time</div></div>
</div>
<div class="row g-3">
  <div class="col-xl-8"><div class="panel">
    <div class="panel-h"><h3>Complaint history</h3><a class="small" href="<?= e(url('complaints', ['department' => $d['id']])) ?>">Open in full list</a></div>
    <?php if (!$res['rows']): ?><div class="empty"><div class="glyph"><?= icon('inbox') ?></div><h3>No complaints from this department</h3></div>
    <?php else: $rows = $res['rows']; include APP_ROOT . '/app/Views/partials/complaint_rows.php';
      $page = $res['page']; $pages = $res['pages']; $total = $res['total']; $route = 'departments/view'; $query = ['id' => $d['id']]; $label = 'complaints'; include APP_ROOT . '/app/Views/partials/pagination.php'; endif; ?>
  </div></div>
  <div class="col-xl-4"><div class="panel">
    <div class="panel-h"><h3>Representatives</h3><a class="btn btn-sm btn-primary" href="<?= e(url('users/create', ['department' => $d['id']])) ?>">Add</a></div>
    <?php if (!$reps): ?><div class="empty py-4"><p class="mb-0">No representatives yet. Add one so this department can report problems.</p></div>
    <?php else: foreach ($reps as $r): ?>
      <div class="notif-item"><b><?= e($r['full_name']) ?> <?= $r['is_active'] ? '' : '<span class="tag">Inactive</span>' ?></b><span><?= e($r['email']) ?><?= $r['phone'] ? ' · ' . e($r['phone']) : '' ?></span><time>Last sign-in: <?= e($r['last_login_at'] ? fmt_dt($r['last_login_at']) : 'never') ?></time></div>
    <?php endforeach; endif; ?>
  </div></div>
</div>

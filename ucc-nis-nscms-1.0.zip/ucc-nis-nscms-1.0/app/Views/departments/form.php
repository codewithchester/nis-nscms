<?php $edit = $d !== null; $v = fn($k) => old($k, $d[$k] ?? ''); ?>
<div class="page-head"><div><h2><?= $edit ? 'Edit department' : 'Register department' ?></h2></div></div>
<form class="panel" method="post" action="<?= e(url($edit ? 'departments/update' : 'departments/store')) ?>" novalidate>
  <?= csrf_field() ?><?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$d['id'] ?>"><?php endif; ?>
  <div class="panel-b row g-3">
    <div class="col-md-8"><?php $name='name'; $label='Department name'; $required=true; $value=$v('name'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-4"><?php $name='code'; $label='Short code'; $required=true; $value=$v('code'); $help='Letters, numbers, hyphens. e.g. CSIT'; $attrs='maxlength="20"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='head_name'; $label='Head of department'; $value=$v('head_name'); $attrs='maxlength="120"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='location'; $label='Main building / location'; $value=$v('location'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='email'; $label='Department email'; $type='email'; $value=$v('email'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='phone'; $label='Department phone'; $type='tel'; $value=$v('phone'); $attrs='maxlength="30"'; include __DIR__.'/../partials/field.php'; ?></div>
  </div>
  <div class="panel-b border-top"><button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Register department' ?></button>
    <a class="btn btn-outline-secondary" href="<?= e(url($edit ? 'departments/view' : 'departments', $edit ? ['id' => $d['id']] : [])) ?>">Cancel</a></div>
</form>

<?php
use App\Services\Notifier;
use App\Services\ProfilePhoto;
$u = auth_user();
$notif = Notifier::summary((int)$u['id']);
$hasAvatarPhoto = ProfilePhoto::existsFor((int)$u['id']);
$flashes = pull_flash();
$route = (string)($_GET['r'] ?? 'dashboard');
$is = fn(string ...$p) => in_array($route, $p, true) ? ' active' : '';
$sys = (string)setting('system_abbr', 'UCC NIS NSCMS');
$link = function (string $r, string $icon, string $label, array $active = []) use ($is) {
    $activeClass = $is($r, ...$active);
    $current = $activeClass !== '' ? ' aria-current="page"' : '';
    return '<a class="side-link' . $activeClass . '"' . $current . ' href="' . e(url($r)) . '">' . icon($icon) . '<span>' . e($label) . '</span></a>';
};
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(\App\Core\View::$title ? \App\Core\View::$title . ' · ' : '') . e($sys) ?></title>
<link rel="icon" href="<?= e(asset('img/favicon.svg')) ?>" type="image/svg+xml">
<script src="<?= e(asset('js/theme.js')) ?>"></script>
<link rel="stylesheet" href="<?= e(asset('vendor/bootstrap/bootstrap.min.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('vendor/icons/bootstrap-icons.min.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body>
<a class="skip-link" href="#main">Skip to content</a>
<div class="shell">
  <aside class="sidebar" id="sidebar" aria-label="Main navigation">
    <a class="brand" href="<?= e(url('dashboard')) ?>">
      <span class="brand-mark"><?php include APP_ROOT . '/app/Views/partials/logo.php'; ?></span>
      <span><b><?= e($sys) ?></b><small><?= e(setting('org_name', 'University of Cape Coast')) ?></small></span>
    </a>
    <button class="sidebar-close" type="button" data-sidebar-toggle aria-controls="primary-navigation" aria-label="Close navigation menu"><?= icon('x-lg') ?> Close menu</button>
    <nav id="primary-navigation" aria-label="Primary navigation">
      <?= $link('dashboard', 'grid-1x2', $u['role'] === 'technician' ? 'My work' : 'Dashboard') ?>
      <?php if (can_report()): ?><?= $link('complaints/create', 'plus-circle', 'Report a problem') ?><?php endif; ?>
      <?= $link('complaints', 'inbox', $u['role'] === 'department_rep' ? 'My complaints' : ($u['role'] === 'technician' ? 'My assignments' : 'All complaints'), ['complaints/view']) ?>
      <?= $link('track', 'search', 'Track a complaint') ?>

      <?php if (can('departments.manage') || can('users.manage') || can('technicians.view') || can('reports.view')): ?>
        <div class="nav-group">Administration</div>
        <?php if (can('departments.manage')): ?><?= $link('departments', 'building', 'Departments', ['departments/view', 'departments/create', 'departments/edit']) ?><?php endif; ?>
        <?php if (can('users.manage')): ?><?= $link('users', 'people', 'Users', ['users/create', 'users/edit']) ?><?php endif; ?>
        <?php if (can('technicians.view')): ?><?= $link('technicians', 'tools', 'Technicians', ['technicians/view']) ?><?php endif; ?>
        <?php if (can('reports.view')): ?><?= $link('reports', 'bar-chart-line', 'Reports') ?><?php endif; ?>
      <?php endif; ?>

      <?php if ($u['role'] === 'super_admin'): ?>
        <div class="nav-group">System</div>
        <?= $link('settings', 'sliders', 'Settings') ?>
        <?= $link('settings/categories', 'tags', 'Categories') ?>
        <?= $link('settings/permissions', 'shield-check', 'Roles & permissions') ?>
        <?= $link('audit', 'journal-text', 'Audit log') ?>
      <?php endif; ?>

      <div class="nav-group">Support</div>
      <?= $link('help', 'question-circle', 'Help & guidance') ?>
      <?= $link('terms', 'file-earmark-text', 'Terms of Service') ?>
    </nav>
    <div class="side-foot">Signed in as<br><b class="text-white"><?= e($u['role_name']) ?></b><?php if ($u['department_name']): ?><br><?= e($u['department_name']) ?><?php endif; ?></div>
  </aside>
  <div class="scrim" id="scrim"></div>

  <div class="main-col">
    <header class="topbar">
      <button class="icon-btn menu-toggle" type="button" data-sidebar-toggle data-noguard aria-controls="primary-navigation" aria-expanded="false" aria-label="Open navigation menu"><?= icon('list') ?></button>
      <h1><?= e(\App\Core\View::$title) ?></h1>
      <button class="icon-btn theme-toggle" type="button" data-theme-toggle aria-pressed="false" aria-label="Switch to dark mode" title="Switch to dark mode">
        <span aria-hidden="true"><span data-theme-icon-light><?= icon('moon-stars') ?></span><span data-theme-icon-dark hidden><?= icon('sun') ?></span></span>
      </button>
      <div class="dropdown">
        <button class="icon-btn" id="notification-menu-button" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-label="Notifications (<?= (int)$notif['count'] ?> unread)" aria-expanded="false" aria-controls="notification-menu">
          <?= icon('bell') ?><?php if ($notif['count'] > 0): ?><span class="badge-dot"><?= $notif['count'] > 99 ? '99+' : (int)$notif['count'] ?></span><?php endif; ?>
        </button>
        <div class="dropdown-menu dropdown-menu-end dd-menu notif-menu" id="notification-menu" aria-labelledby="notification-menu-button">
          <div class="d-flex justify-content-between align-items-center px-3 py-2 border-bottom"><b>Notifications</b>
            <a href="<?= e(url('notifications')) ?>" class="small">View all</a></div>
          <?php if (!$notif['items']): ?><div class="p-3 text-muted small">You have no notifications yet.</div><?php endif; ?>
          <?php foreach ($notif['items'] as $n): ?>
            <a class="notif-item<?= $n['is_read'] ? '' : ' unread' ?>" href="<?= e($n['complaint_id'] ? url('complaints/view', ['id' => $n['complaint_id']]) : url('notifications')) ?>">
              <b><?= e($n['title']) ?></b><span><?= e(mb_strimwidth($n['message'], 0, 90, '…')) ?></span><time><?= e(ago($n['created_at'])) ?></time>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="dropdown">
        <button class="user-btn" id="account-menu-button" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Account menu for <?= e($u['full_name']) ?>" aria-controls="account-menu">
          <span class="avatar" aria-hidden="true"><?php if ($hasAvatarPhoto): ?><img src="<?= e(url('account/photo')) ?>" alt=""><?php else: ?><?= e(initials($u['full_name'])) ?><?php endif; ?></span>
          <span class="who"><b><?= e($u['full_name']) ?></b><small><?= e($u['role_name']) ?></small></span>
          <span class="account-caret" aria-hidden="true"><?= icon('chevron-down') ?></span>
        </button>
        <ul class="dropdown-menu dropdown-menu-end dd-menu" id="account-menu" aria-labelledby="account-menu-button">
          <li class="account-menu-header"><span class="avatar" aria-hidden="true"><?php if ($hasAvatarPhoto): ?><img src="<?= e(url('account/photo')) ?>" alt=""><?php else: ?><?= e(initials($u['full_name'])) ?><?php endif; ?></span><span><b><?= e($u['full_name']) ?></b><small><?= e($u['role_name']) ?></small></span></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item" href="<?= e(url('account/profile')) ?>"><?= icon('person') ?> My profile</a></li>
          <li><a class="dropdown-item" href="<?= e(url('account/password')) ?>"><?= icon('key') ?> Change password</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><form method="post" action="<?= e(url('auth/logout')) ?>" data-noguard><?= csrf_field() ?><button class="dropdown-item" type="submit"><?= icon('box-arrow-right') ?> Sign out</button></form></li>
        </ul>
      </div>
    </header>

    <main id="main" class="content" tabindex="-1">
      <?php foreach ($flashes as [$type, $msg]): ?>
        <div class="alert alert-<?= e($type) ?> alert-dismissible fade show" role="<?= $type === 'danger' ? 'alert' : 'status' ?>">
          <?= e($msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
      <?php endforeach; ?>
      <?= $content ?>
    </main>

    <?php include APP_ROOT . '/app/Views/partials/footer.php'; ?>
  </div>
</div>
<script src="<?= e(asset('vendor/bootstrap/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= e(asset('vendor/chartjs/chart.umd.js')) ?>"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>

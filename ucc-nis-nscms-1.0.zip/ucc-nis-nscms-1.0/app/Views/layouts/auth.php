<?php
use App\Core\View;
$flashes = pull_flash();
$sys = (string)setting('system_abbr', 'UCC NIS NSCMS');
$wide = View::$wide;
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(View::$title ? View::$title . ' · ' : '') . e($sys) ?></title>
<link rel="icon" href="<?= e(asset('img/favicon.svg')) ?>" type="image/svg+xml">
<script src="<?= e(asset('js/theme.js')) ?>"></script>
<link rel="stylesheet" href="<?= e(asset('vendor/bootstrap/bootstrap.min.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('vendor/icons/bootstrap-icons.min.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
</head>
<body class="auth-page">
<a class="skip-link" href="#main">Skip to main content</a>
<div class="auth-shell<?= $wide ? ' plain' : '' ?>">
  <section class="auth-hero" aria-hidden="false">
    <a class="brand" href="<?= e(url('')) ?>">
      <span class="brand-mark"><?php include APP_ROOT . '/app/Views/partials/logo.php'; ?></span>
      <span><b><?= e(setting('org_name', 'University of Cape Coast')) ?></b><small><?= e(setting('section_name', 'Network Infrastructure Section (NIS)')) ?></small></span>
    </a>
    <div>
      <h2>Report network problems. Follow them to resolution.</h2>
      <p>One place for departments to log connectivity faults and for NIS to assign, fix and learn from them.</p>
      <ul class="facts">
        <li><?= icon('hash') ?>Every complaint gets a reference number, e.g. NIS-<?= e(date('Y')) ?>-00001</li>
        <li><?= icon('diagram-3') ?>Technicians are assigned and every status change is recorded</li>
        <li><?= icon('bell') ?>You are notified when NIS needs information or resolves the fault</li>
      </ul>
    </div>
    <small class="text-white-50"><?= e($sys) ?> · v<?= e(APP_VERSION) ?></small>
  </section>
  <div class="auth-main">
    <main class="auth-body" id="main" tabindex="-1">
      <div class="auth-card<?= $wide ? ' wide' : '' ?>">
        <?php foreach ($flashes as [$type, $msg]): ?>
          <div class="alert alert-<?= e($type) ?>" role="<?= $type === 'danger' ? 'alert' : 'status' ?>"><?= e($msg) ?></div>
        <?php endforeach; ?>
        <?= $content ?>
      </div>
    </main>
    <?php include APP_ROOT . '/app/Views/partials/footer_auth.php'; ?>
  </div>
</div>
<script src="<?= e(asset('vendor/bootstrap/bootstrap.bundle.min.js')) ?>"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>

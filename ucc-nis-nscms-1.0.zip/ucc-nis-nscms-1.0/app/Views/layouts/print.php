<?php use App\Core\View; ?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title><?= e(View::$title) ?> · <?= e(setting('system_abbr', 'UCC NIS NSCMS')) ?></title>
<link rel="stylesheet" href="<?= e(asset('css/print.css')) ?>">
</head>
<body>
<div class="toolbar">
  <button type="button" data-print data-noguard>Print or save as PDF</button>
</div>
<div class="sheet">
  <div class="letterhead">
    <div class="logo-ph">LOGO<br>placeholder</div>
    <div><h1><?= e(setting('org_name', 'University of Cape Coast')) ?></h1><p><?= e(setting('section_name', 'Network Infrastructure Section (NIS)')) ?> · <?= e(setting('system_name')) ?></p></div>
  </div>
  <?= $content ?>
  <div class="foot"><span>Generated <?= e(date('d M Y, H:i')) ?> · <?= e(setting('system_abbr', 'UCC NIS NSCMS')) ?></span>
    <span>Designed by <a href="https://teakaymultimedia.onrender.com" target="_blank" rel="noopener noreferrer">Teakay Multimedia</a></span></div>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>

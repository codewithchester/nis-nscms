<div class="page-head"><div><h2>Complaint categories</h2><p>Categories shown on the complaint form. Deactivate instead of deleting so history stays intact.</p></div></div>
<div class="row g-3">
  <div class="col-xl-8"><div class="panel"><div class="table-wrap"><table class="tbl"><thead><tr><th>Name</th><th>Order</th><th class="num">Used</th><th>Active</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?>
  <tr>
    <td><input class="form-control form-control-sm" form="cf<?= (int)$r['id'] ?>" name="name" value="<?= e($r['name']) ?>" maxlength="100" required aria-label="Category name"></td>
    <td><input class="form-control form-control-sm" form="cf<?= (int)$r['id'] ?>" type="number" name="sort_order" value="<?= (int)$r['sort_order'] ?>" min="0" max="999" aria-label="Order"></td>
    <td class="num"><?= (int)$r['used'] ?></td>
    <td><div class="form-check"><input class="form-check-input" form="cf<?= (int)$r['id'] ?>" type="checkbox" name="is_active" value="1"<?= $r['is_active'] ? ' checked' : '' ?> aria-label="Active"></div></td>
    <td class="text-end"><button class="btn btn-sm btn-outline-primary" form="cf<?= (int)$r['id'] ?>" type="submit">Save</button></td></tr>
  <?php endforeach; ?></tbody></table></div>
  <?php foreach ($rows as $r): ?><form method="post" action="<?= e(url('settings/categories/save')) ?>" id="cf<?= (int)$r['id'] ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"></form><?php endforeach; ?>
  </div></div>
  <div class="col-xl-4"><form class="panel" method="post" action="<?= e(url('settings/categories/save')) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="0">
    <div class="panel-h"><h3>Add a category</h3></div><div class="panel-b">
      <div class="mb-2"><label class="form-label req" for="new_name">Name</label><input class="form-control" id="new_name" name="name" maxlength="100" required></div>
      <div class="mb-3"><label class="form-label" for="new_order">Order</label><input class="form-control" type="number" id="new_order" name="sort_order" value="50" min="0" max="999"></div>
      <button class="btn btn-primary" type="submit">Add category</button></div></form></div>
</div>

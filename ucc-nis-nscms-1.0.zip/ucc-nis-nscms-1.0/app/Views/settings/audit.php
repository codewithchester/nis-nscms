<div class="page-head"><div><h2>Audit log</h2><p>Security-relevant events: sign-ins, status changes, assignments, user and settings changes. Entries cannot be edited from the portal.</p></div></div>
<div class="panel">
  <form class="filters" method="get" action="<?= e(url('audit')) ?>" data-noguard>
    <input type="hidden" name="r" value="audit">
    <div><label class="form-label" for="q">Search</label><input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="User, email, IP, details" maxlength="100"></div>
    <div><label class="form-label" for="action">Action</label><select class="form-select" id="action" name="action"><option value="">All actions</option><?php foreach ($actions as $a): ?><option<?= $action === $a ? ' selected' : '' ?>><?= e($a) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="from">From</label><input class="form-control" type="date" id="from" name="from" value="<?= e($from) ?>"></div>
    <div><label class="form-label" for="to">To</label><input class="form-control" type="date" id="to" name="to" value="<?= e($to) ?>"></div>
    <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Filter</button><a class="btn btn-outline-secondary" href="<?= e(url('audit')) ?>">Clear</a></div>
  </form>
  <?php if (!$rows): ?><div class="empty"><div class="glyph"><?= icon('journal-text') ?></div><h3>No log entries</h3></div><?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Entity</th><th>Details</th><th>IP</th></tr></thead><tbody>
  <?php foreach ($rows as $r): ?><tr><td class="small text-nowrap"><?= e(fmt_dt($r['created_at'], 'd M Y H:i:s')) ?></td>
    <td class="small"><?= $r['full_name'] ? e($r['full_name']) . '<div class="text-muted">' . e($r['email']) . '</div>' : '<span class="text-muted">—</span>' ?></td>
    <td><span class="tag"><?= e($r['action']) ?></span></td><td class="small"><?= e($r['entity_type'] ? $r['entity_type'] . ' #' . $r['entity_id'] : '—') ?></td>
    <td class="small mono"><?= e(mb_strimwidth((string)$r['details'], 0, 110, '…')) ?></td><td class="small mono"><?= e($r['ip_address']) ?></td></tr><?php endforeach; ?></tbody></table></div>
  <?php $query = ['q' => $q, 'action' => $action, 'from' => $from, 'to' => $to]; $route = 'audit'; $label = 'entries'; include APP_ROOT . '/app/Views/partials/pagination.php'; ?>
  <?php endif; ?>
</div>

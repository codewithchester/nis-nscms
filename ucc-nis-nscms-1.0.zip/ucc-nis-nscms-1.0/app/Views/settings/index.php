<?php $v = fn($k, $d = '') => old($k, (string)setting($k, $d)); ?>
<div class="page-head"><div><h2>System settings</h2><p>Institution details, target times and limits. Secrets such as SMTP passwords live in the server’s <span class="mono">.env</span> file, never here.</p></div></div>
<div class="row g-3">
  <div class="col-xl-8">
    <form class="panel" method="post" action="<?= e(url('settings/save')) ?>" novalidate>
      <?= csrf_field() ?>
      <div class="panel-h"><h3>General</h3></div>
      <div class="panel-b row g-3">
        <div class="col-12"><?php $name='system_name'; $label='System name'; $required=true; $value=$v('system_name'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-6"><?php $name='org_name'; $label='Institution name'; $required=true; $value=$v('org_name'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-6"><?php $name='section_name'; $label='Section name'; $required=true; $value=$v('section_name'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-6"><?php $name='support_email'; $label='NIS support email'; $type='email'; $value=$v('support_email'); $attrs='maxlength="150"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-6"><?php $name='support_phone'; $label='NIS support phone'; $type='tel'; $value=$v('support_phone'); $attrs='maxlength="30"'; include __DIR__.'/../partials/field.php'; ?></div>
      </div>
      <div class="panel-h border-top"><h3>Target resolution times (hours)</h3></div>
      <div class="panel-b row g-3">
        <?php foreach (['sla_hours_critical' => 'Critical', 'sla_hours_high' => 'High', 'sla_hours_medium' => 'Medium', 'sla_hours_low' => 'Low'] as $k => $l): ?>
          <div class="col-6 col-md-3"><?php $name=$k; $label=$l; $type='number'; $value=$v($k); $attrs='min="1" step="1"'; include __DIR__.'/../partials/field.php'; ?></div>
        <?php endforeach; ?>
        <div class="col-12"><p class="form-text mb-0">A complaint is “overdue” when its target time passes while it is still open. The clock is not counted while NIS is waiting for the department to reply.</p></div>
      </div>
      <div class="panel-h border-top"><h3>Behaviour and limits</h3></div>
      <div class="panel-b row g-3">
        <div class="col-md-3"><?php $name='per_page'; $label='Rows per page'; $type='number'; $value=$v('per_page'); $attrs='min="5" max="100"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-3"><?php $name='max_upload_mb'; $label='Max upload (MB)'; $type='number'; $value=$v('max_upload_mb'); $attrs='min="1" max="25"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-3"><?php $name='session_timeout_min'; $label='Idle timeout (min)'; $type='number'; $value=$v('session_timeout_min'); $attrs='min="5" max="240"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-md-3"><?php $name='recurring_threshold'; $label='Recurring threshold'; $type='number'; $value=$v('recurring_threshold'); $attrs='min="2" max="50"'; include __DIR__.'/../partials/field.php'; ?></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="email_enabled" name="email_enabled" value="1"<?= setting('email_enabled', '0') === '1' ? ' checked' : '' ?>>
          <label class="form-check-label" for="email_enabled">Send email notifications (needs <span class="mono">MAIL_DRIVER=smtp</span> and credentials in <span class="mono">.env</span>)</label></div>
          <div class="form-text">In-app notifications always work. Email is optional and never blocks complaint submission.</div></div>
      </div>
      <div class="panel-b border-top"><button class="btn btn-primary" type="submit">Save settings</button></div>
    </form>
  </div>
  <div class="col-xl-4">
    <div class="panel"><div class="panel-h"><h3>Environment</h3></div><div class="panel-b"><dl class="kv">
      <?php foreach ($env as $k => $val): ?><dt><?= e($k) ?></dt><dd><?= e($val) ?></dd><?php endforeach; ?></dl></div></div>
  </div>
</div>

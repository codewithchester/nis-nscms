<div class="page-head"><div><h2>Roles & permissions</h2><p>Choose what each role may do. The Super Administrator always has every permission. Data isolation (departments see only their own complaints, technicians only their assignments) is enforced separately and cannot be switched off.</p></div></div>
<form class="panel" method="post" action="<?= e(url('settings/permissions/save')) ?>">
  <?= csrf_field() ?>
  <div class="table-wrap"><table class="tbl perm-grid"><thead><tr><th>Permission</th><?php foreach ($roles as $r): ?><th><?= e($r['name']) ?></th><?php endforeach; ?></tr></thead><tbody>
  <?php $group = ''; foreach ($catalog as $code => $def): ?>
    <?php if ($def['group'] !== $group): $group = $def['group']; ?><tr><td colspan="<?= count($roles) + 1 ?>" class="fw-semibold bg-light"><?= e($group) ?></td></tr><?php endif; ?>
    <tr><td><?= e($def['label']) ?><div class="small text-muted mono"><?= e($code) ?></div></td>
      <?php foreach ($roles as $r): ?><td>
        <?php if (in_array($r['slug'], $def['roles'], true)): ?>
          <div class="form-check d-inline-block"><input class="form-check-input" type="checkbox" name="grant[<?= e($r['slug']) ?>][<?= e($code) ?>]" value="1"<?= !empty($grants[$r['id']][$code]) ? ' checked' : '' ?> aria-label="<?= e($def['label'] . ' for ' . $r['name']) ?>"></div>
        <?php else: ?><span class="text-muted" aria-label="Not applicable">—</span><?php endif; ?></td><?php endforeach; ?></tr>
  <?php endforeach; ?></tbody></table></div>
  <div class="panel-b border-top"><button class="btn btn-primary" type="submit">Save permissions</button></div>
</form>

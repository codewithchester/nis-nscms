<div class="page-head"><div><h2>Notifications</h2><p><?= (int)$total ?> in total.</p></div>
  <?php if ($items): ?><form method="post" action="<?= e(url('notifications/read')) ?>"><?= csrf_field() ?><input type="hidden" name="all" value="1"><button class="btn btn-outline-secondary" type="submit">Mark all as read</button></form><?php endif; ?></div>
<div class="panel">
<?php if (!$items): ?><div class="empty"><div class="glyph"><?= icon('bell') ?></div><h3>You’re all caught up</h3><p>You will be notified when a complaint is submitted, assigned, updated or resolved.</p></div>
<?php else: ?><div class="note-list">
  <?php foreach ($items as $n): ?>
  <div class="n<?= $n['is_read'] ? '' : ' unread' ?>">
    <div class="flex-grow-1"><b><?= e($n['title']) ?></b><div class="small"><?= e($n['message']) ?></div><div class="small text-muted"><?= e(fmt_dt($n['created_at'])) ?></div></div>
    <div class="d-flex gap-2 align-items-start">
      <?php if ($n['complaint_id']): ?><a class="btn btn-sm btn-outline-primary" href="<?= e(url('complaints/view', ['id' => $n['complaint_id']])) ?>">Open</a><?php endif; ?>
      <?php if (!$n['is_read']): ?><form method="post" action="<?= e(url('notifications/read')) ?>"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$n['id'] ?>"><button class="btn btn-sm btn-outline-secondary" type="submit">Mark read</button></form><?php endif; ?>
    </div>
  </div>
  <?php endforeach; ?></div>
  <?php $route = 'notifications'; $query = []; $label = 'notifications'; include APP_ROOT . '/app/Views/partials/pagination.php'; ?>
<?php endif; ?></div>

<?php $u = auth_user(); ?>
<?php
$c = $counts;
$cells = [
  ['Total complaints', $c['total'], url('complaints'), ''],
  ['New', $c['new_count'], url('complaints', ['status' => 'Submitted']), $c['new_count'] > 0 ? 'accent' : ''],
  ['Pending', $c['pending'], url('complaints'), ''],
  ['Assigned', $c['assigned'], url('complaints', ['status' => 'Assigned']), ''],
  ['Unassigned', $c['unassigned'], '', $c['unassigned'] > 0 ? 'accent' : ''],
  ['Under investigation', $c['investigating'], url('complaints', ['status' => 'In Progress']), ''],
  ['Awaiting department', $c['awaiting'], url('complaints', ['status' => 'Awaiting Department Response']), ''],
  ['Resolved', $c['resolved'], url('complaints', ['status' => 'Resolved']), ''],
  ['Overdue', $c['overdue'], url('complaints', ['overdue' => 1]), $c['overdue'] > 0 ? 'warn' : ''],
  ['Departments', $c['departments'], can('departments.manage') ? url('departments') : '', ''],
  ['Technicians', $c['technicians'], can('technicians.view') ? url('technicians') : '', ''],
];
?>
<div class="page-head">
  <div><h2>Welcome, <?= e(explode(' ', $u['full_name'])[0] ?? '') ?></h2><p>Live view of network complaints across the university.</p></div>
  <a class="btn btn-outline-secondary" href="<?= e(url('track')) ?>"><?= icon('search') ?> Track by reference</a>
</div>

<div class="ledger mb-4">
  <?php foreach ($cells as [$label, $n, $href, $cls]): ?>
    <?php if ($href): ?><a class="<?= e($cls) ?>" href="<?= e($href) ?>"><div class="n"><?= (int)$n ?></div><div class="l"><?= e($label) ?></div></a>
    <?php else: ?><div class="cell <?= e($cls) ?>"><div class="n"><?= (int)$n ?></div><div class="l"><?= e($label) ?></div></div><?php endif; ?>
  <?php endforeach; ?>
</div>

<div class="row g-3 mb-3">
  <div class="col-xl-8">
    <div class="panel h-100">
      <div class="panel-h"><h3>Recent complaints</h3><a href="<?= e(url('complaints')) ?>" class="small">View all</a></div>
      <?php if (!$recent): ?>
        <div class="empty"><div class="glyph"><?= icon('inbox') ?></div><h3>No complaints yet</h3><p>When a department submits a network problem it will appear here.</p></div>
      <?php else: ?><?php $rows = $recent; $showDept = true; include APP_ROOT . '/app/Views/partials/complaint_rows.php'; ?><?php endif; ?>
    </div>
  </div>
  <div class="col-xl-4">
    <div class="panel h-100">
      <div class="panel-h"><h3>Needs attention</h3><span class="text-muted small">Past target date</span></div>
      <?php if (!$attention): ?>
        <div class="empty"><div class="glyph"><?= icon('check2-circle') ?></div><h3>Nothing overdue</h3><p>Every open complaint is within its target resolution time.</p></div>
      <?php else: foreach ($attention as $a): ?>
        <a class="notif-item" href="<?= e(url('complaints/view', ['id' => $a['id']])) ?>">
          <b><span class="mono"><?= e($a['reference_no']) ?></span> · <?= e(mb_strimwidth($a['title'], 0, 40, '…')) ?></b>
          <span><?= e($a['department_name']) ?> · <?= priority_badge($a['priority']) ?></span>
          <time class="text-danger">Due <?= e(fmt_dt($a['due_at'], 'd M, H:i')) ?></time>
        </a>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>

<?php if (!empty($charts_enabled) && isset($charts)): ?>
<?php
$ch = $charts;
$prioCfg = ['type' => 'doughnut', 'labels' => $ch['priority']['labels'], 'datasets' => [['data' => $ch['priority']['data'], 'backgroundColor' => ['#64748b', '#2f6f9f', '#d9822b', '#b3261e'], 'borderWidth' => 2, 'borderColor' => '#fff']]];
$catCfg = ['type' => 'bar', 'horizontal' => true, 'legend' => false, 'labels' => $ch['category']['labels'], 'datasets' => [['label' => 'Complaints', 'data' => $ch['category']['data'], 'backgroundColor' => '#174b74', 'borderRadius' => 3]]];
$depCfg = ['type' => 'bar', 'legend' => false, 'labels' => $ch['department']['labels'], 'datasets' => [['label' => 'Complaints', 'data' => $ch['department']['data'], 'backgroundColor' => '#b8872a', 'borderRadius' => 3]]];
$monCfg = ['type' => 'line', 'labels' => $ch['monthly']['labels'], 'datasets' => [
  ['label' => 'Submitted', 'data' => $ch['monthly']['created'], 'borderColor' => '#174b74', 'backgroundColor' => 'rgba(23,75,116,.1)', 'fill' => true, 'tension' => .3],
  ['label' => 'Resolved', 'data' => $ch['monthly']['resolved'], 'borderColor' => '#1f7a6d', 'backgroundColor' => 'rgba(31,122,109,.08)', 'tension' => .3]]];
$wlCfg = ['type' => 'bar', 'horizontal' => true, 'legend' => false, 'labels' => $ch['workload']['labels'], 'datasets' => [['label' => 'Open complaints', 'data' => $ch['workload']['data'], 'backgroundColor' => '#475569', 'borderRadius' => 3]]];
$resCfg = ['type' => 'bar', 'labels' => $ch['resolution']['labels'], 'datasets' => [
  ['label' => 'Avg hours to resolve', 'data' => $ch['resolution']['avg'], 'backgroundColor' => '#174b74', 'borderRadius' => 3],
  ['type' => 'line', 'label' => '% within target', 'data' => $ch['resolution']['sla'], 'borderColor' => '#1f7a6d', 'backgroundColor' => '#1f7a6d', 'yAxisID' => 'y2', 'tension' => .25]]];
$noData = $c['total'] === 0;
?>
<?php if ($noData): ?>
  <div class="panel"><div class="empty"><div class="glyph"><?= icon('graph-up') ?></div><h3>Analytics will appear here</h3><p>Charts are drawn from real complaint records. Once departments start reporting problems you will see trends, categories and technician workload.</p></div></div>
<?php else: ?>
<div class="row g-3 mb-3">
  <div class="col-lg-8"><div class="panel"><div class="panel-h"><h3>Monthly complaint trend</h3><span class="text-muted small">Last 12 months</span></div><div class="panel-b"><div class="chart-box"><canvas data-chart="<?= json_attr($monCfg) ?>" role="img" aria-label="Line chart of complaints submitted and resolved per month"></canvas></div></div></div></div>
  <div class="col-lg-4"><div class="panel h-100"><div class="panel-h"><h3>Priority distribution</h3></div><div class="panel-b"><div class="chart-box"><canvas data-chart="<?= json_attr($prioCfg) ?>" role="img" aria-label="Doughnut chart of complaints by priority"></canvas></div></div></div></div>
</div>
<div class="row g-3 mb-3">
  <div class="col-lg-6"><div class="panel"><div class="panel-h"><h3>Complaints by category</h3><span class="text-muted small">Top 8</span></div><div class="panel-b"><div class="chart-box"><canvas data-chart="<?= json_attr($catCfg) ?>" role="img" aria-label="Bar chart of complaints by category"></canvas></div></div></div></div>
  <div class="col-lg-6"><div class="panel"><div class="panel-h"><h3>Departments with most complaints</h3><span class="text-muted small">Top 8 by code</span></div><div class="panel-b"><div class="chart-box"><canvas data-chart="<?= json_attr($depCfg) ?>" role="img" aria-label="Bar chart of complaints by department"></canvas></div></div></div></div>
</div>
<div class="row g-3">
  <div class="col-lg-6"><div class="panel"><div class="panel-h"><h3>Technician workload</h3><span class="text-muted small">Open complaints</span></div><div class="panel-b"><div class="chart-box sm"><?php if ($ch['workload']['labels']): ?><canvas data-chart="<?= json_attr($wlCfg) ?>" role="img" aria-label="Bar chart of open complaints per technician"></canvas><?php else: ?><div class="empty py-4"><p class="mb-0">No technicians registered yet.</p></div><?php endif; ?></div></div></div></div>
  <div class="col-lg-6"><div class="panel"><div class="panel-h"><h3>Resolution performance</h3><span class="text-muted small">By priority</span></div><div class="panel-b"><div class="chart-box sm"><canvas data-chart="<?= json_attr($resCfg) ?>" role="img" aria-label="Chart of average resolution hours and percent resolved within target by priority"></canvas></div></div></div></div>
</div>
<?php endif; ?>
<?php endif; ?>

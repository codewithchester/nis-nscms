<?php $u = auth_user(); ?>
<?php $c = $counts; ?>
<div class="page-head">
  <div><h2><?= e($u['department_name']) ?></h2><p>Your department’s network complaints and their progress.</p></div>
  <?php if (can_report()): ?><a class="btn btn-primary" href="<?= e(url('complaints/create')) ?>"><?= icon('plus-circle') ?> Report a problem</a><?php endif; ?>
</div>
<div class="ledger mb-4">
  <a href="<?= e(url('complaints')) ?>"><div class="n"><?= (int)$c['total'] ?></div><div class="l">Total reported</div></a>
  <a href="<?= e(url('complaints')) ?>"><div class="n"><?= (int)$c['open_count'] ?></div><div class="l">Open</div></a>
  <a class="<?= $c['awaiting'] > 0 ? 'accent' : '' ?>" href="<?= e(url('complaints', ['status' => 'Awaiting Department Response'])) ?>"><div class="n"><?= (int)$c['awaiting'] ?></div><div class="l">Waiting for your reply</div></a>
  <a href="<?= e(url('complaints', ['status' => 'Resolved'])) ?>"><div class="n"><?= (int)$c['resolved'] ?></div><div class="l">Resolved</div></a>
  <a href="<?= e(url('complaints', ['status' => 'Rejected'])) ?>"><div class="n"><?= (int)$c['rejected'] ?></div><div class="l">Rejected</div></a>
</div>

<?php if ($needs_response): ?>
<div class="callout"><b>NIS needs more information on <?= count($needs_response) ?> complaint<?= count($needs_response) > 1 ? 's' : '' ?>.</b> Open each one and reply so work can continue.
  <ul class="mb-0 mt-1"><?php foreach ($needs_response as $r): ?><li><a href="<?= e(url('complaints/view', ['id' => $r['id']])) ?>"><span class="mono"><?= e($r['reference_no']) ?></span> — <?= e($r['title']) ?></a></li><?php endforeach; ?></ul></div>
<?php endif; ?>
<?php if ($to_confirm): ?>
<div class="callout info"><b>Marked as resolved by NIS — please confirm.</b>
  <ul class="mb-0 mt-1"><?php foreach ($to_confirm as $r): ?><li><a href="<?= e(url('complaints/view', ['id' => $r['id']])) ?>"><span class="mono"><?= e($r['reference_no']) ?></span> — <?= e($r['title']) ?></a></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="panel">
  <div class="panel-h"><h3>Recent complaints</h3><a href="<?= e(url('complaints')) ?>" class="small">View all</a></div>
  <?php if (!$recent): ?>
    <div class="empty"><div class="glyph"><?= icon('wifi') ?></div><h3>No complaints yet</h3><p>Having trouble with the internet, Wi‑Fi, a network port or cabling? Report it and NIS will take it from there.</p>
      <?php if (can_report()): ?><a class="btn btn-primary" href="<?= e(url('complaints/create')) ?>">Report a problem</a><?php endif; ?></div>
  <?php else: ?><?php $rows = $recent; include APP_ROOT . '/app/Views/partials/complaint_rows.php'; ?><?php endif; ?>
</div>

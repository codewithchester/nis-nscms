<?php $c = $counts; ?>
<div class="page-head">
  <div><h2>My work</h2><p>Complaints assigned to you, most urgent first.</p></div>
  <a class="btn btn-outline-secondary" href="<?= e(url('complaints')) ?>">Assignment history</a>
</div>
<div class="ledger mb-4">
  <div class="cell"><div class="n"><?= (int)$c['active_total'] ?></div><div class="l">Active assignments</div></div>
  <div class="cell"><div class="n"><?= (int)$c['assigned'] ?></div><div class="l">Not started</div></div>
  <div class="cell"><div class="n"><?= (int)$c['in_progress'] ?></div><div class="l">In progress</div></div>
  <div class="cell"><div class="n"><?= (int)$c['awaiting'] ?></div><div class="l">Waiting on department</div></div>
  <div class="cell <?= $c['overdue'] > 0 ? 'warn' : '' ?>"><div class="n"><?= (int)$c['overdue'] ?></div><div class="l">Overdue</div></div>
  <div class="cell"><div class="n"><?= (int)$c['completed'] ?></div><div class="l">Completed (all time)</div></div>
  <div class="cell"><div class="n"><?= e(hours_label($c['avg_hours'])) ?></div><div class="l">Avg. time to complete</div></div>
</div>
<div class="row g-3">
  <div class="col-xl-8">
    <div class="panel">
      <div class="panel-h"><h3>Work queue</h3></div>
      <?php if (!$queue): ?>
        <div class="empty"><div class="glyph"><?= icon('check2-all') ?></div><h3>Nothing in your queue</h3><p>New assignments from the NIS administrator will show up here and in your notifications.</p></div>
      <?php else: ?>
      <div class="table-wrap"><table class="tbl"><thead><tr><th>Reference</th><th>Problem</th><th>Location</th><th>Priority</th><th>Status</th><th>Due</th></tr></thead><tbody>
        <?php foreach ($queue as $q): $over = \App\Models\Complaint::isOverdue($q); ?>
        <tr><td class="ref"><a href="<?= e(url('complaints/view', ['id' => $q['id']])) ?>"><?= e($q['reference_no']) ?></a></td>
          <td class="title-cell"><?= e(mb_strimwidth($q['title'], 0, 50, '…')) ?><div class="small text-muted"><?= e($q['department_name']) ?></div></td>
          <td><?= e($q['building']) ?><div class="small text-muted"><?= e($q['room']) ?></div></td>
          <td><?= priority_badge($q['priority']) ?></td><td><?= status_badge($q['status']) ?></td>
          <td class="<?= $over ? 'flag-overdue' : 'text-muted' ?>"><?= e(fmt_dt($q['due_at'], 'd M, H:i')) ?><?= $over ? '<br>Overdue' : '' ?></td></tr>
        <?php endforeach; ?></tbody></table></div>
      <?php endif; ?>
    </div>
  </div>
  <div class="col-xl-4">
    <div class="panel">
      <div class="panel-h"><h3>Recently completed</h3></div>
      <?php if (!$history): ?><div class="empty py-4"><p class="mb-0">Completed work will be listed here.</p></div>
      <?php else: foreach ($history as $h): ?>
        <a class="notif-item" href="<?= e(url('complaints/view', ['id' => $h['id']])) ?>"><b><span class="mono"><?= e($h['reference_no']) ?></span> · <?= e(mb_strimwidth($h['title'], 0, 38, '…')) ?></b><span><?= e($h['department_name']) ?></span><time>Completed <?= e(fmt_dt($h['completed_at'], 'd M Y, H:i')) ?></time></a>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>

<?php $s = $r['summary']; ?>
<div class="doc-title"><h2>Network complaints report</h2><span>Period: <?= e(fmt_d($f['from'])) ?> – <?= e(fmt_d($f['to'])) ?><?= $f['priority'] ? ' · ' . e($f['priority']) . ' priority' : '' ?><?= $f['status'] ? ' · ' . e($f['status']) : '' ?></span></div>
<div class="grid2 report-document-meta">
  <div><span>Report reference</span><b><?= e($reference) ?></b></div>
  <div><span>Generated</span><b><?= e($generatedAt) ?></b></div>
  <div><span>Prepared by</span><b><?= e($by) ?></b></div>
  <?php foreach ($filterLabels as $label => $value): ?><div><span><?= e($label) ?></span><b><?= e($value) ?></b></div><?php endforeach; ?>
</div>
<div class="kpis">
  <div><b><?= $s['total'] ?></b><span>Complaints</span></div><div><b><?= $s['resolved'] ?></b><span>Resolved / closed</span></div><div><b><?= $s['unresolved'] ?></b><span>Unresolved</span></div>
  <div><b><?= $s['overdue'] ?></b><span>Overdue</span></div><div><b><?= e(hours_label($s['avg_hours'])) ?></b><span>Avg. resolution</span></div><div><b><?= $s['sla_pct'] === null ? '—' : e($s['sla_pct']) . '%' ?></b><span>Within target</span></div>
</div>
<h3>Most frequently reported problems</h3>
<table><thead><tr><th>Category</th><th class="num">Complaints</th><th class="num">Resolved</th><th class="num">Avg. resolution</th></tr></thead><tbody>
<?php foreach ($r['by_category'] as $x): ?><tr><td><?= e($x['name']) ?></td><td class="num"><?= (int)$x['total'] ?></td><td class="num"><?= (int)$x['resolved'] ?></td><td class="num"><?= e(hours_label($x['avg_hours'])) ?></td></tr><?php endforeach; ?></tbody></table>
<h3>Departments by complaint volume</h3>
<table><thead><tr><th>Department</th><th class="num">Total</th><th class="num">Open</th><th class="num">Resolved</th><th class="num">Avg. resolution</th></tr></thead><tbody>
<?php foreach ($r['by_department'] as $x): ?><tr><td><?= e($x['name']) ?></td><td class="num"><?= (int)$x['total'] ?></td><td class="num"><?= (int)$x['open_count'] ?></td><td class="num"><?= (int)$x['resolved'] ?></td><td class="num"><?= e(hours_label($x['avg_hours'])) ?></td></tr><?php endforeach; ?></tbody></table>
<h3>Recurring problems</h3>
<table><thead><tr><th>Department</th><th>Category</th><th>Building</th><th class="num">Times</th><th>Last reported</th></tr></thead><tbody>
<?php foreach ($r['recurring'] as $x): ?><tr><td><?= e($x['department']) ?></td><td><?= e($x['category']) ?></td><td><?= e($x['building']) ?></td><td class="num"><?= (int)$x['occurrences'] ?></td><td><?= e(fmt_d($x['last_reported'])) ?></td></tr><?php endforeach; ?>
<?php if (!$r['recurring']): ?><tr><td colspan="5">None in this period.</td></tr><?php endif; ?></tbody></table>
<h3>Technician performance</h3>
<table><thead><tr><th>Technician</th><th class="num">Assigned</th><th class="num">Completed</th><th class="num">Active</th><th class="num">Avg. time to complete</th></tr></thead><tbody>
<?php foreach ($r['technicians'] as $x): ?><tr><td><?= e($x['full_name']) ?></td><td class="num"><?= (int)$x['assigned'] ?></td><td class="num"><?= (int)$x['completed'] ?></td><td class="num"><?= (int)$x['active'] ?></td><td class="num"><?= e(hours_label($x['avg_hours'])) ?></td></tr><?php endforeach; ?>
<?php if (!$r['technicians']): ?><tr><td colspan="5">No assignments in this period.</td></tr><?php endif; ?></tbody></table>
<h3>Unresolved complaints</h3>
<table><thead><tr><th>Reference</th><th>Title</th><th>Department</th><th>Priority</th><th>Status</th><th class="num">Age (d)</th></tr></thead><tbody>
<?php foreach ($r['unresolved'] as $x): ?><tr><td><?= e($x['reference_no']) ?></td><td><?= e(mb_strimwidth($x['title'], 0, 50, '…')) ?></td><td><?= e($x['department_name']) ?></td><td><?= e($x['priority']) ?></td><td><?= e($x['status']) ?></td><td class="num"><?= (int)$x['age_days'] ?></td></tr><?php endforeach; ?>
<?php if (!$r['unresolved']) : ?><tr><td colspan="6">None.</td></tr><?php endif; ?></tbody></table>
<p class="foot"><span>Prepared by <?= e($by) ?></span><span>Report generated from live system records</span></p>

<?php $s = $r['summary']; $qs = array_filter($f, fn($v) => $v !== '' && $v !== 0); $maxCat = max(1, ...array_map(fn($x) => (int)$x['total'], $r['by_category'] ?: [['total' => 1]])); $maxDep = max(1, ...array_map(fn($x) => (int)$x['total'], $r['by_department'] ?: [['total' => 1]])); ?>
<div class="page-head"><div><h2>Reports</h2><p><?= e(fmt_d($f['from'])) ?> to <?= e(fmt_d($f['to'])) ?> · computed from live complaint records.</p></div>
  <?php if (can('reports.export')): ?><div class="d-flex gap-2 flex-wrap">
    <a class="btn btn-outline-secondary" href="<?= e(url('reports/print', $qs)) ?>" target="_blank" rel="noopener"><?= icon('printer') ?> Print</a>
    <a class="btn btn-outline-secondary" href="<?= e(url('reports/pdf', $qs)) ?>"><?= icon('file-earmark-pdf') ?> PDF</a>
    <a class="btn btn-outline-secondary" href="<?= e(url('reports/csv', $qs)) ?>"><?= icon('filetype-csv') ?> CSV</a></div><?php endif; ?></div>

<form class="panel mb-3" method="get" action="<?= e(url('reports')) ?>" data-noguard>
  <input type="hidden" name="r" value="reports">
  <div class="filters wide">
    <div><label class="form-label" for="from">From</label><input class="form-control" type="date" id="from" name="from" value="<?= e($f['from']) ?>"></div>
    <div><label class="form-label" for="to">To</label><input class="form-control" type="date" id="to" name="to" value="<?= e($f['to']) ?>"></div>
    <div><label class="form-label" for="department">Department</label><select class="form-select" id="department" name="department"><option value="">All</option><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>"<?= $f['department'] === (int)$d['id'] ? ' selected' : '' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="category">Category</label><select class="form-select" id="category" name="category"><option value="">All</option><?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"<?= $f['category'] === (int)$c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="priority">Priority</label><select class="form-select" id="priority" name="priority"><option value="">All</option><?php foreach (\App\Services\Workflow::PRIORITIES as $p): ?><option<?= $f['priority'] === $p ? ' selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="status">Status</label><select class="form-select" id="status" name="status"><option value="">All</option><?php foreach (\App\Services\Workflow::STATUSES as $p): ?><option<?= $f['status'] === $p ? ' selected' : '' ?>><?= e($p) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="technician">Technician</label><select class="form-select" id="technician" name="technician"><option value="">Anyone</option><?php foreach ($technicians as $t): ?><option value="<?= (int)$t['id'] ?>"<?= $f['technician'] === (int)$t['id'] ? ' selected' : '' ?>><?= e($t['full_name']) ?></option><?php endforeach; ?></select></div>
    <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Generate</button><a class="btn btn-outline-secondary" href="<?= e(url('reports')) ?>">Reset</a></div>
  </div>
</form>

<section class="panel report-preview mb-3" data-report-preview data-expanded="true">
  <div class="panel-h p-0">
    <button class="report-preview-toggle" type="button" data-preview-toggle aria-expanded="true" aria-controls="report-preview-body">
      <span><b>Report preview</b><small>Generated from the selected filters</small></span>
      <span class="report-preview-label" data-preview-label>Collapse</span>
    </button>
  </div>
  <div class="report-preview-body" id="report-preview-body">
    <div class="report-preview-inner">
      <div class="panel-b">
        <div class="report-meta">
          <div><span>Report reference</span><b><?= e($reference) ?></b></div>
          <div><span>Generated</span><b><?= e($generatedAt) ?></b></div>
          <div><span>Prepared by</span><b><?= e($by) ?></b></div>
        </div>
        <div class="report-filters" aria-label="Applied report filters">
          <b>Applied filters:</b>
          <?php foreach ($filterLabels as $label => $value): ?><span><?= e($label) ?>: <?= e($value) ?></span><?php endforeach; ?>
        </div>
<?php if ($s['total'] === 0): ?>
  <div class="empty"><div class="glyph"><?= icon('bar-chart-line') ?></div><h3>No complaints in this selection</h3><p>Widen the date range or clear a filter. Reports use the complaints recorded in the system and never show placeholder numbers.</p></div>
<?php else: ?>
<div class="ledger mb-3">
  <div class="cell"><div class="n"><?= $s['total'] ?></div><div class="l">Complaints</div></div>
  <div class="cell"><div class="n"><?= $s['resolved'] ?></div><div class="l">Resolved or closed</div></div>
  <div class="cell"><div class="n"><?= $s['unresolved'] ?></div><div class="l">Unresolved</div></div>
  <div class="cell <?= $s['overdue'] ? 'warn' : '' ?>"><div class="n"><?= $s['overdue'] ?></div><div class="l">Overdue</div></div>
  <div class="cell"><div class="n"><?= e(hours_label($s['avg_hours'])) ?></div><div class="l">Avg. resolution time</div></div>
  <div class="cell"><div class="n"><?= $s['sla_pct'] === null ? '—' : e($s['sla_pct']) . '%' ?></div><div class="l">Resolved within target</div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-6"><div class="panel h-100"><div class="panel-h"><h3>Most frequently reported problems</h3></div><div class="panel-b">
    <?php foreach ($r['by_category'] as $x): ?><div class="bar-row"><span class="name" title="<?= e($x['name']) ?>"><?= e($x['name']) ?></span><span class="track"><span class="fill d-block" data-width="<?= e(round(100 * $x['total'] / $maxCat)) ?>"></span></span><span class="v"><?= (int)$x['total'] ?></span></div><?php endforeach; ?></div></div></div>
  <div class="col-lg-6"><div class="panel h-100"><div class="panel-h"><h3>Departments with highest volume</h3></div><div class="panel-b">
    <?php foreach (array_slice($r['by_department'], 0, 10) as $x): ?><div class="bar-row"><span class="name" title="<?= e($x['name']) ?>"><?= e($x['name']) ?></span><span class="track"><span class="fill d-block" data-width="<?= e(round(100 * $x['total'] / $maxDep)) ?>"></span></span><span class="v"><?= (int)$x['total'] ?></span></div><?php endforeach; ?></div></div></div>
</div>

<div class="row g-3 mb-3">
  <div class="col-lg-4"><div class="panel h-100"><div class="panel-h"><h3>By priority</h3></div><div class="table-wrap"><table class="tbl"><thead><tr><th>Priority</th><th class="num">Count</th><th class="num">Avg. resolution</th></tr></thead><tbody>
    <?php foreach ($r['by_priority'] as $x): ?><tr><td><?= priority_badge($x['priority']) ?></td><td class="num"><?= (int)$x['total'] ?></td><td class="num"><?= e(hours_label($x['avg_hours'])) ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
  <div class="col-lg-4"><div class="panel h-100"><div class="panel-h"><h3>By status</h3></div><div class="table-wrap"><table class="tbl"><tbody>
    <?php foreach ($r['by_status'] as $x): ?><tr><td><?= status_badge($x['status']) ?></td><td class="num"><?= (int)$x['total'] ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
  <div class="col-lg-4"><div class="panel h-100"><div class="panel-h"><h3>Common failure locations</h3></div><div class="table-wrap"><table class="tbl"><tbody>
    <?php foreach ($r['by_location'] as $x): ?><tr><td><?= e($x['building']) ?></td><td class="num"><?= (int)$x['total'] ?></td></tr><?php endforeach; ?></tbody></table></div></div></div>
</div>

<div class="panel mb-3"><div class="panel-h"><h3>Recurring problems</h3><span class="text-muted small"><?= (int)$r['recurring_threshold'] ?>+ reports of the same category, in the same building, from the same department</span></div>
  <?php if (!$r['recurring']): ?><div class="empty py-4"><p class="mb-0">No recurring problems in this period.</p></div><?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Department</th><th>Category</th><th>Building</th><th class="num">Times reported</th><th>Last reported</th></tr></thead><tbody>
  <?php foreach ($r['recurring'] as $x): ?><tr><td><?= e($x['department']) ?></td><td><?= e($x['category']) ?></td><td><?= e($x['building']) ?></td><td class="num"><b><?= (int)$x['occurrences'] ?></b></td><td class="small"><?= e(fmt_d($x['last_reported'])) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<div class="panel mb-3"><div class="panel-h"><h3>Technician performance</h3></div>
  <?php if (!$r['technicians']): ?><div class="empty py-4"><p class="mb-0">No complaints were assigned in this selection.</p></div><?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Technician</th><th class="num">Assigned</th><th class="num">Completed</th><th class="num">Active</th><th class="num">Avg. time to complete</th></tr></thead><tbody>
  <?php foreach ($r['technicians'] as $x): ?><tr><td><?= e($x['full_name']) ?></td><td class="num"><?= (int)$x['assigned'] ?></td><td class="num"><?= (int)$x['completed'] ?></td><td class="num"><?= (int)$x['active'] ?></td><td class="num"><?= e(hours_label($x['avg_hours'])) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<div class="panel mb-3"><div class="panel-h"><h3>Unresolved complaints</h3><span class="text-muted small">Oldest target date first, up to 100</span></div>
  <?php if (!$r['unresolved']): ?><div class="empty py-4"><p class="mb-0">Nothing is unresolved in this selection.</p></div><?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Reference</th><th>Title</th><th>Department</th><th>Priority</th><th>Status</th><th class="num">Age (days)</th><th>Target</th></tr></thead><tbody>
  <?php foreach ($r['unresolved'] as $x): ?><tr><td class="ref"><?= e($x['reference_no']) ?></td><td class="title-cell"><?= e(mb_strimwidth($x['title'], 0, 50, '…')) ?></td><td class="small"><?= e($x['department_name']) ?></td><td><?= priority_badge($x['priority']) ?></td><td><?= status_badge($x['status']) ?></td><td class="num"><?= (int)$x['age_days'] ?></td><td class="small <?= $x['is_overdue'] ? 'flag-overdue' : '' ?>"><?= e(fmt_dt($x['due_at'], 'd M, H:i')) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div>

<div class="panel"><div class="panel-h"><h3>Complaint list</h3><span class="text-muted small">Latest 100 · CSV export includes everything in the selection</span></div>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Reference</th><th>Title</th><th>Department</th><th>Category</th><th>Priority</th><th>Status</th><th>Submitted</th><th class="num">Resolution</th></tr></thead><tbody>
  <?php foreach ($r['rows'] as $x): ?><tr><td class="ref"><?= e($x['reference_no']) ?></td><td class="title-cell"><?= e(mb_strimwidth($x['title'], 0, 45, '…')) ?></td><td class="small"><?= e($x['department_name']) ?></td><td class="small"><?= e($x['category_name']) ?></td><td><?= priority_badge($x['priority']) ?></td><td><?= status_badge($x['status']) ?></td><td class="small"><?= e(fmt_d($x['created_at'])) ?></td><td class="num"><?= e(hours_label($x['resolution_hours'])) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php endif; ?>
      </div>
    </div>
  </div>
</section>

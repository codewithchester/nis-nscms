<?php // expects $rows, optional $showDept (bool) ?>
<?php $showDept = $showDept ?? false; ?>
<div class="table-wrap"><table class="tbl">
  <thead><tr><th>Reference</th><th>Title</th><?php if ($showDept): ?><th>Department</th><?php endif; ?><th>Priority</th><th>Status</th><th>Submitted</th></tr></thead>
  <tbody>
  <?php foreach ($rows as $r): ?>
    <tr>
      <td class="ref"><a href="<?= e(url('complaints/view', ['id' => $r['id']])) ?>"><?= e($r['reference_no']) ?></a></td>
      <td class="title-cell"><?= e(mb_strimwidth($r['title'], 0, 60, '…')) ?></td>
      <?php if ($showDept): ?><td><?= e($r['department_name']) ?></td><?php endif; ?>
      <td><?= priority_badge($r['priority']) ?></td>
      <td><?= status_badge($r['status']) ?><?php if (\App\Models\Complaint::isOverdue($r)): ?> <span class="flag-overdue">Overdue</span><?php endif; ?></td>
      <td class="text-muted"><?= e(ago($r['created_at'])) ?></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table></div>

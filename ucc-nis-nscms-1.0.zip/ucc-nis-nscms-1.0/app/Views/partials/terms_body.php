<?php $org = (string)setting('org_name', 'University of Cape Coast'); $nis = (string)setting('section_name', 'Network Infrastructure Section (NIS)'); $mail = (string)setting('support_email', ''); ?>
<p>These Terms of Service govern your use of the <?= e(setting('system_name')) ?> (the “Portal”), operated by the <?= e($nis) ?> of the <?= e($org) ?> (“NIS”, “we”). By signing in you confirm that you have read and accept them.</p>

<h2>1. Purpose of the Portal</h2>
<p>The Portal exists so authorised university departments can report network faults, and so NIS can receive, assign, resolve and analyse those reports. It is not a general-purpose messaging or file-sharing service.</p>

<h2>2. Eligibility and accounts</h2>
<ul>
  <li>Accounts are created by NIS for staff, technicians and nominated department representatives. You may not register yourself or share an account.</li>
  <li>You are responsible for everything done under your account. Keep your password confidential and sign out on shared computers.</li>
  <li>Temporary passwords must be changed at first sign-in. Report suspected unauthorised access to NIS immediately.</li>
  <li>NIS may deactivate an account, or a whole department’s access, when it is no longer needed or if these terms are breached.</li>
</ul>

<h2>3. Acceptable use</h2>
<ul>
  <li>Submit accurate, good-faith reports about genuine network problems. Do not submit false, abusive, defamatory or irrelevant complaints.</li>
  <li>Do not attempt to access other departments’ complaints, other users’ accounts, or any part of the Portal you are not authorised to use.</li>
  <li>Do not probe, scan, overload, reverse-engineer or attempt to bypass the security of the Portal or the university network through it.</li>
  <li>Do not upload malware, executable files or content that you do not have the right to share. Attachments are limited to the permitted file types and size shown on the form.</li>
  <li>Do not include passwords, personal financial data or other highly sensitive information in complaint text or attachments.</li>
</ul>

<h2>4. Complaint handling</h2>
<ul>
  <li>Each complaint receives a unique reference number. Target resolution times depend on priority and are goals, not guarantees.</li>
  <li>NIS may accept, reject, reprioritise, reassign or close complaints, and may request more information. A complaint rejected with an explanation can be resubmitted with additional detail.</li>
  <li>Status changes, assignments and messages are recorded with date, time and the person responsible, and cannot be deleted by users.</li>
  <li>Internal notes written by NIS staff are not visible to departments.</li>
</ul>

<h2>5. Privacy and data</h2>
<ul>
  <li>We collect only what the Portal needs: your name, email, phone number, department, the complaint details you submit, and technical records such as sign-in times and IP addresses used for security.</li>
  <li>Your data is used to handle complaints, notify you, produce statistics and protect the system. It is visible only to authorised NIS staff and, for your department’s complaints, to your department’s representatives.</li>
  <li>Security-relevant actions are written to an audit log. Aggregated, non-identifying statistics may be used in NIS reports.</li>
  <li>Personal data is processed in line with the Data Protection Act, 2012 (Act 843) of Ghana and applicable university policy. Contact NIS to ask about, correct or request removal of your data.</li>
</ul>

<h2>6. Security</h2>
<p>NIS uses technical measures such as encrypted passwords, access controls and activity logging. Sessions end after a period of inactivity. You agree not to disable or work around these measures. Activity may be monitored and reviewed for security and misuse.</p>

<h2>7. Availability</h2>
<p>NIS will try to keep the Portal available but does not promise uninterrupted service. Planned maintenance and unplanned outages may occur. For urgent faults while the Portal is unavailable, contact NIS directly<?= $mail !== '' ? ' at ' . e($mail) : '' ?>.</p>

<h2>8. Intellectual property</h2>
<p>The Portal software, design and content are the property of the university and its developers. University names, logos and marks remain the property of the <?= e($org) ?>. You retain ownership of the content you submit and grant NIS the right to use it to handle your complaint.</p>

<h2>9. Limitation of liability</h2>
<p>To the extent permitted by law, the university and NIS are not liable for indirect or consequential loss arising from use of, or inability to use, the Portal, or from delays in resolving a reported fault.</p>

<h2>10. Changes to these terms</h2>
<p>We may update these terms. When they change materially you will be asked to accept the new version the next time you sign in. Continued use after acceptance means you agree to the updated terms.</p>

<h2>11. Governing law and contact</h2>
<p>These terms are governed by the laws of the Republic of Ghana. Questions about these terms or the Portal can be sent to the <?= e($nis) ?><?= $mail !== '' ? ' at ' . e($mail) : '' ?>.</p>
<p class="small text-muted">This document is a working template supplied with the Portal and should be reviewed by the university’s legal office before production use.</p>

<footer class="site-footer">
  <span>© <?= e(date('Y')) ?> <?= e(setting('org_name', 'University of Cape Coast')) ?> · <?= e(setting('section_name', 'Network Infrastructure Section (NIS)')) ?></span>
  <span><a href="<?= e(url('terms')) ?>">Terms of Service</a> · <a href="<?= e(url('help')) ?>">Help</a> ·
    Designed by <a href="https://teakaymultimedia.onrender.com" target="_blank" rel="noopener noreferrer">Teakay Multimedia</a></span>
</footer>

<?php
// Renders a labelled form field. expects: $name, $label; optional: $type, $value, $required, $help, $attrs, $options (select), $rows
$type = $type ?? 'text'; $required = $required ?? false; $help = $help ?? ''; $attrs = $attrs ?? '';
$value = $value ?? old($name);
$id = 'f_' . $name;
$error = field_error($name);
$errorId = $id . '_error';
$helpId = $id . '_help';
$describedBy = array_filter([$error ? $errorId : null, $help ? $helpId : null]);
$ariaAttrs = ($error ? ' aria-invalid="true"' : '')
    . ($describedBy ? ' aria-describedby="' . e(implode(' ', $describedBy)) . '"' : '');
?>
<label class="form-label<?= $required ? ' req' : '' ?>" for="<?= e($id) ?>"><?= e($label) ?></label>
<?php if ($type === 'textarea'): ?>
  <textarea class="form-control<?= invalid($name) ?>" id="<?= e($id) ?>" name="<?= e($name) ?>" rows="<?= (int)($rows ?? 5) ?>" <?= $required ? 'required' : '' ?> <?= $attrs ?><?= $ariaAttrs ?>><?= e($value) ?></textarea>
<?php elseif ($type === 'select'): ?>
  <select class="form-select<?= invalid($name) ?>" id="<?= e($id) ?>" name="<?= e($name) ?>" <?= $required ? 'required' : '' ?> <?= $attrs ?><?= $ariaAttrs ?>>
    <?php foreach ($options as $val => $text): ?><option value="<?= e($val) ?>"<?= (string)$val === (string)$value ? ' selected' : '' ?>><?= e($text) ?></option><?php endforeach; ?>
  </select>
<?php else: ?>
  <input class="form-control<?= invalid($name) ?>" type="<?= e($type) ?>" id="<?= e($id) ?>" name="<?= e($name) ?>" value="<?= e($value) ?>" <?= $required ? 'required' : '' ?> <?= $attrs ?><?= $ariaAttrs ?>>
<?php endif; ?>
<?php if ($error): ?><div id="<?= e($errorId) ?>" class="invalid-feedback d-block"><?= e($error) ?></div><?php endif; ?>
<?php if ($help): ?><div id="<?= e($helpId) ?>" class="form-text"><?= e($help) ?></div><?php endif; ?>
<?php unset($type, $value, $required, $help, $attrs, $options, $rows, $error, $errorId, $helpId, $describedBy, $ariaAttrs); ?>

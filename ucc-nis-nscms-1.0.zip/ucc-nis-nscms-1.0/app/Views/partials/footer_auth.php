<div class="auth-foot">
  <span>© <?= e(date('Y')) ?> <?= e(setting('org_name', 'University of Cape Coast')) ?> · NIS</span>
  <span><a href="<?= e(url('terms')) ?>">Terms of Service</a> ·
    Designed by <a href="https://teakaymultimedia.onrender.com" target="_blank" rel="noopener noreferrer">Teakay Multimedia</a></span>
  <button class="btn btn-outline-secondary btn-sm theme-toggle-text" type="button" data-theme-toggle aria-pressed="false" aria-label="Switch to dark mode">
    <span aria-hidden="true"><span data-theme-icon-light><?= icon('moon-stars') ?></span><span data-theme-icon-dark hidden><?= icon('sun') ?></span></span>
    <span data-theme-label>Use dark appearance</span>
  </button>
</div>

<?php
// expects: $page, $pages, $total, $route, $query (array), $label (string)
$query = $query ?? [];
$label = $label ?? 'records';
if ($pages < 1) $pages = 1;
$window = range(max(1, $page - 2), min($pages, $page + 2));
?>
<div class="pager">
  <span><?= (int)$total ?> <?= e($label) ?> · page <?= (int)$page ?> of <?= (int)$pages ?></span>
  <?php if ($pages > 1): ?>
  <nav aria-label="Pagination"><ul class="pagination pagination-sm">
    <li class="page-item<?= $page <= 1 ? ' disabled' : '' ?>"><a class="page-link" href="<?= e(url($route, $query + ['page' => max(1, $page - 1)])) ?>">Previous</a></li>
    <?php if ($window[0] > 1): ?><li class="page-item"><a class="page-link" href="<?= e(url($route, $query + ['page' => 1])) ?>">1</a></li><li class="page-item disabled"><span class="page-link">…</span></li><?php endif; ?>
    <?php foreach ($window as $p): ?><li class="page-item<?= $p === $page ? ' active' : '' ?>"><a class="page-link" href="<?= e(url($route, $query + ['page' => $p])) ?>"><?= $p ?></a></li><?php endforeach; ?>
    <?php if (end($window) < $pages): ?><li class="page-item disabled"><span class="page-link">…</span></li><li class="page-item"><a class="page-link" href="<?= e(url($route, $query + ['page' => $pages])) ?>"><?= $pages ?></a></li><?php endif; ?>
    <li class="page-item<?= $page >= $pages ? ' disabled' : '' ?>"><a class="page-link" href="<?= e(url($route, $query + ['page' => min($pages, $page + 1)])) ?>">Next</a></li>
  </ul></nav>
  <?php endif; ?>
</div>

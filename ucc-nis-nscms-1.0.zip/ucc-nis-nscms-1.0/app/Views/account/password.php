<?php $wrap = $forced; ?>
<?php if ($forced): ?>
  <h1>Set a new password</h1>
  <p class="text-muted">Your account uses a temporary password. Choose your own before continuing.</p>
<?php else: ?>
  <div class="page-head"><div><h2>Change password</h2><p>Use at least 10 characters with letters and numbers.</p></div></div>
<?php endif; ?>
<form class="<?= $forced ? '' : 'panel panel-b' ?>" method="post" action="<?= e(url('account/password')) ?>" novalidate>
  <?= csrf_field() ?>
  <?php foreach ([['current_password', 'Current password', 'current-password'], ['new_password', 'New password', 'new-password'], ['new_password_confirm', 'Confirm new password', 'new-password']] as [$n, $l, $ac]): ?>
    <div class="mb-3">
      <?php $error = field_error($n); $errorId = $n . '_error'; ?>
      <label class="form-label" for="<?= $n ?>"><?= e($l) ?></label>
      <input class="form-control<?= invalid($n) ?>" type="password" id="<?= $n ?>" name="<?= $n ?>" autocomplete="<?= $ac ?>" maxlength="72" required<?= $error ? ' aria-invalid="true" aria-describedby="' . e($errorId) . '"' : '' ?>>
      <?php if ($error): ?><div id="<?= e($errorId) ?>" class="invalid-feedback d-block"><?= e($error) ?></div><?php endif; ?>
    </div>
  <?php endforeach; ?>
  <button class="btn btn-primary" type="submit">Update password</button>
  <?php if ($forced): ?><button class="btn btn-link" type="submit" form="logout-form" data-noguard>Sign out</button><?php endif; ?>
</form>
<?php if ($forced): ?><form id="logout-form" method="post" action="<?= e(url('auth/logout')) ?>" data-noguard><?= csrf_field() ?></form><?php endif; ?>

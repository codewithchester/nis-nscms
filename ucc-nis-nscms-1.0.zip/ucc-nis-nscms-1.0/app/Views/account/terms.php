<?php \App\Core\View::$wide = true; ?>
<h1>Terms of Service</h1>
<p class="text-muted">Please read and accept the terms (version <?= e(TERMS_VERSION) ?>) to continue.</p>
<div class="panel panel-b legal mb-3" tabindex="0" aria-label="Terms of Service text" data-scroll>
  <?php include APP_ROOT . '/app/Views/partials/terms_body.php'; ?>
</div>
<?php if ($accepted): ?>
  <div class="alert alert-success">You have already accepted the current terms.</div>
  <a class="btn btn-primary" href="<?= e(url('dashboard')) ?>">Continue</a>
<?php else: ?>
<form method="post" action="<?= e(url('account/terms/accept')) ?>">
  <?= csrf_field() ?>
  <div class="form-check mb-3"><input class="form-check-input" type="checkbox" id="agree" name="agree" value="1" required>
    <label class="form-check-label" for="agree">I have read and agree to the Terms of Service.</label></div>
  <button class="btn btn-primary" type="submit">Accept and continue</button>
  <button class="btn btn-link" type="submit" form="logout-form" data-noguard>Sign out</button>
</form>
<form id="logout-form" method="post" action="<?= e(url('auth/logout')) ?>" data-noguard><?= csrf_field() ?></form>
<?php endif; ?>

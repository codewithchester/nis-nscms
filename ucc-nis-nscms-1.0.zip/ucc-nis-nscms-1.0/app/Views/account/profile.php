<?php
$responsibilities = [
  'super_admin' => 'Oversees system access, settings, and administrative activity.',
  'nis_admin' => 'Manages network complaints, departments, and technician assignments.',
  'technician' => 'Investigates assigned network complaints and records technical progress.',
  'department_rep' => 'Reports network problems and follows their progress for your department.',
];
?>
<section class="profile-heading panel mb-3">
  <div class="profile-avatar">
    <?php if ($hasPhoto): ?><img src="<?= e(url('account/photo')) ?>" alt="">
    <?php else: ?><span aria-hidden="true"><?= e(initials($u['full_name'])) ?></span><?php endif; ?>
  </div>
  <div class="profile-heading-copy">
    <span class="tag"><?= e($u['role_name']) ?></span>
    <h2><?= e($u['full_name']) ?></h2>
    <p><?= e($u['department_name'] ?: 'Network Infrastructure Section') ?></p>
  </div>
  <span class="profile-status<?= (int)$u['is_active'] === 1 ? ' active' : '' ?>"><?= (int)$u['is_active'] === 1 ? 'Active account' : 'Inactive account' ?></span>
</section>

<div class="profile-stats mb-3">
  <?php foreach ($stats as $stat): ?><div class="panel"><b><?= e($stat['value']) ?></b><span><?= e($stat['label']) ?></span></div><?php endforeach; ?>
</div>

<div class="row g-3">
  <div class="col-lg-8">
    <form class="panel" method="post" action="<?= e(url('account/profile')) ?>" enctype="multipart/form-data" novalidate>
      <?= csrf_field() ?>
      <div class="panel-h"><h2>My profile</h2></div>
      <div class="panel-b row g-3">
        <div class="col-md-6"><?php $name = 'full_name'; $label = 'Full name'; $required = true; $value = old('full_name', $u['full_name']); $attrs = 'maxlength="120"'; include APP_ROOT . '/app/Views/partials/field.php'; unset($value, $attrs); ?></div>
        <div class="col-md-6"><?php $name = 'phone'; $label = 'Phone'; $type = 'tel'; $required = false; $value = old('phone', $u['phone'] ?? ''); $attrs = 'maxlength="30"'; include APP_ROOT . '/app/Views/partials/field.php'; unset($value, $attrs, $type); ?></div>
        <?php if ($photosAvailable): ?>
        <div class="col-12">
          <?php $photoError = field_error('profile_photo'); ?>
          <label class="form-label" for="profile_photo">Profile photo</label>
          <input class="form-control<?= invalid('profile_photo') ?>" type="file" id="profile_photo" name="profile_photo" accept="image/jpeg,image/png,image/webp" data-max-mb="<?= (int)$maxMb ?>" aria-describedby="profile_photo_help<?= $photoError ? ' profile_photo_error' : '' ?>"<?= $photoError ? ' aria-invalid="true"' : '' ?>>
          <div class="form-text" id="profile_photo_help">Optional JPEG, PNG, or WebP image up to <?= (int)$maxMb ?> MB. Your image is only visible to you.</div>
          <?php if ($photoError): ?><div id="profile_photo_error" class="invalid-feedback d-block"><?= e($photoError) ?></div><?php endif; ?>
        </div>
        <?php else: ?>
        <div class="col-12"><div class="alert alert-warning mb-0" role="status">Profile photo uploads require the administrator to apply the database migration.</div></div>
        <?php endif; ?>
        <div class="col-md-6"><label class="form-label">Email (sign-in name)</label><input class="form-control" value="<?= e($u['email']) ?>" disabled></div>
        <div class="col-md-6"><label class="form-label">Role</label><input class="form-control" value="<?= e($u['role_name'] . ($u['department_name'] ? ' · ' . $u['department_name'] : '')) ?>" disabled></div>
        <div class="col-12"><p class="form-text mb-0">To change your email address or department, contact the NIS office.</p></div>
      </div>
      <div class="panel-b border-top"><button class="btn btn-primary" type="submit">Save changes</button> <a class="btn btn-outline-secondary" href="<?= e(url('account/password')) ?>">Change password</a></div>
    </form>
  </div>
  <aside class="col-lg-4">
    <section class="panel">
      <div class="panel-h"><h2>Account overview</h2></div>
      <div class="panel-b">
        <dl class="profile-details">
          <dt>Email</dt><dd><?= e($u['email']) ?></dd>
          <dt>Phone</dt><dd><?= e($u['phone'] ?: 'Not provided') ?></dd>
          <dt>Role</dt><dd><?= e($u['role_name']) ?></dd>
          <dt>Account created</dt><dd><?= e(fmt_d($u['created_at'] ?? null)) ?></dd>
          <dt>Last sign in</dt><dd><?= e(fmt_dt($u['last_login_at'] ?? null)) ?></dd>
        </dl>
        <hr>
        <p class="small text-muted mb-0"><?= e($responsibilities[$u['role']] ?? 'Use the system according to your assigned access.') ?></p>
      </div>
    </section>
  </aside>
</div>

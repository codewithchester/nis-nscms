<div class="text-center py-4">
  <div class="err-code"><?= (int)$code ?></div>
  <h1 class="h3 mt-2"><?= e($heading) ?></h1>
  <p class="text-muted"><?= e($message) ?></p>
  <p class="mt-3">
    <a class="btn btn-primary" href="<?= e(url('')) ?>">Go to the portal</a>
    <?php if ($code === 419): ?><a class="btn btn-outline-secondary" href="<?= e(url('auth/login')) ?>">Sign in again</a><?php endif; ?>
  </p>
</div>

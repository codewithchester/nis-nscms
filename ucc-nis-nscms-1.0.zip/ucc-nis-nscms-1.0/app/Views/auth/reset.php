<h1>Choose a new password</h1>
<p class="text-muted mb-4">At least 10 characters, with letters and numbers.</p>
<form method="post" action="<?= e(url('auth/reset')) ?>" novalidate>
  <?= csrf_field() ?>
  <input type="hidden" name="token" value="<?= e($token) ?>">
  <div class="mb-3"><label class="form-label" for="password">New password</label>
    <div class="pw-wrap"><input class="form-control" type="password" id="password" name="password" autocomplete="new-password" maxlength="72" required>
    <button class="btn-eye" type="button" data-toggle-password="password" data-noguard aria-label="Show password"><i class="bi bi-eye" aria-hidden="true"></i></button></div></div>
  <div class="mb-3"><label class="form-label" for="password_confirm">Confirm new password</label>
    <input class="form-control" type="password" id="password_confirm" name="password_confirm" autocomplete="new-password" maxlength="72" required></div>
  <button class="btn btn-primary w-100 py-2" type="submit">Change password</button>
</form>

<?php $emailError = field_error('email'); ?>
<h1>Reset your password</h1>
<p class="text-muted mb-4">Enter the email address on your account. If it matches an active account, we send a link that works once and expires in 60 minutes.</p>
<form method="post" action="<?= e(url('auth/forgot')) ?>" novalidate>
  <?= csrf_field() ?>
  <div class="mb-3">
    <label class="form-label" for="email">Email address</label>
    <input class="form-control<?= invalid('email') ?>" type="email" id="email" name="email" value="<?= e(old('email')) ?>" maxlength="150" required<?= $emailError ? ' aria-invalid="true" aria-describedby="email_error"' : '' ?>>
    <?php if ($emailError): ?><div id="email_error" class="invalid-feedback d-block"><?= e($emailError) ?></div><?php endif; ?>
  </div>
  <button class="btn btn-primary w-100 py-2" type="submit">Send reset link</button>
  <p class="text-center mt-3 mb-0"><a href="<?= e(url('auth/login')) ?>">Back to sign in</a></p>
</form>

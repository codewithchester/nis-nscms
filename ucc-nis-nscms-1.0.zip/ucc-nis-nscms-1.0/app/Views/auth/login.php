<?php $emailError = field_error('email'); ?>
<h1>Sign in</h1>
<p class="text-muted mb-4">Use the account created for you by the NIS office.</p>
<form method="post" action="<?= e(url('auth/login')) ?>" novalidate>
  <?= csrf_field() ?>
  <div class="mb-3">
    <label class="form-label" for="email">Email address</label>
    <input class="form-control<?= invalid('email') ?>" type="email" id="email" name="email" value="<?= e(old('email')) ?>" autocomplete="username" maxlength="150" required<?= $emailError ? ' aria-invalid="true" aria-describedby="email_error"' : '' ?>>
    <?php if ($emailError): ?><div id="email_error" class="invalid-feedback d-block"><?= e($emailError) ?></div><?php endif; ?>
  </div>
  <div class="mb-2">
    <label class="form-label" for="password">Password</label>
    <div class="pw-wrap">
      <input class="form-control" type="password" id="password" name="password" autocomplete="current-password" maxlength="200" required>
      <button class="btn-eye" type="button" data-toggle-password="password" data-noguard aria-label="Show password"><i class="bi bi-eye" aria-hidden="true"></i></button>
    </div>
  </div>
  <div class="d-flex justify-content-between align-items-center mb-3">
    <a href="<?= e(url('auth/forgot')) ?>" class="small">Forgot your password?</a>
  </div>
  <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>
  <p class="small text-muted mt-3 mb-0">By signing in you agree to the <a href="<?= e(url('terms')) ?>">Terms of Service</a>.</p>
</form>

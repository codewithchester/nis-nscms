<?php use App\Core\Auth; if (!Auth::check()) \App\Core\View::$wide = true; ?>
<div class="<?= Auth::check() ? 'page-head' : '' ?>"><div><h<?= Auth::check() ? 2 : 1 ?>>Terms of Service</h<?= Auth::check() ? 2 : 1 ?>><p class="text-muted mb-3">Version <?= e(TERMS_VERSION) ?> · <?= e(setting('org_name', 'University of Cape Coast')) ?>, <?= e(setting('section_name', 'Network Infrastructure Section (NIS)')) ?></p></div></div>
<div class="<?= Auth::check() ? 'panel panel-b' : '' ?> legal">
  <?php include APP_ROOT . '/app/Views/partials/terms_body.php'; ?>
</div>
<?php if (!Auth::check()): ?><p class="mt-3"><a href="<?= e(url('auth/login')) ?>">&larr; Back to sign in</a></p><?php endif; ?>

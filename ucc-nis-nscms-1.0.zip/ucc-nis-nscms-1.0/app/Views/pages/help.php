<?php $role = $u['role']; ?>
<div class="page-head"><div><h2>Help & guidance</h2><p>How to use the portal as <?= e($u['role_name']) ?>.</p></div></div>
<div class="row g-3">
<?php if ($role === 'department_rep'): ?>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Report a problem</h3><ol>
    <li>Choose <b>Report a problem</b>. Your department is filled in automatically.</li><li>Describe what is wrong, where, and since when. Pick the closest category and priority.</li>
    <li>Attach a screenshot or photo if it helps, then submit.</li><li>Keep the reference number (for example <span class="mono">NIS-<?= e(date('Y')) ?>-00001</span>) — you also get it as a notification.</li></ol></div></div>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Follow progress</h3><ul>
    <li>Use <b>Track a complaint</b> and enter a reference number, or open the complaint from <b>My complaints</b>.</li><li>The progress line shows where the complaint is. You can see the status history and technician updates NIS shares.</li>
    <li>If NIS asks for more information the status becomes <i>Awaiting Department Response</i>. Reply on the complaint page so work can continue.</li><li>When it is <i>Resolved</i>, confirm and close it — or reopen it if the fault is still there.</li><li>Use <b>Print</b> or <b>Download PDF</b> on a complaint for a copy.</li></ul></div></div>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Priority guide</h3><ul><li><b>Critical</b> — a whole building, lab or key service is down.</li><li><b>High</b> — many users affected or an important office cannot work.</li><li><b>Medium</b> — some users affected; workarounds exist.</li><li><b>Low</b> — minor or cosmetic (e.g. a loose cable, slow occasionally).</li></ul></div></div>
<?php elseif ($role === 'technician'): ?>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Working an assignment</h3><ol>
    <li>Open <b>My work</b> — most urgent first. Open a complaint to see location, contact and instructions.</li><li>Choose <b>Start work</b> to move it to <i>In Progress</i>.</li>
    <li>Post <b>progress updates</b>, <b>technical findings</b> and <b>work performed</b>. Untick “Visible to the department” to keep a note internal.</li>
    <li>If you need information from the department, use <b>Ask the department</b>. The complaint pauses until they reply.</li><li>When fixed, choose <b>Mark as resolved</b> and write what you did. The department then confirms.</li></ol></div></div>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Good to know</h3><ul><li>You only see complaints assigned to you.</li><li>If NIS reassigns a complaint, it leaves your queue.</li><li>Every action is recorded with your name and the time.</li></ul></div></div>
<?php else: ?>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Daily workflow</h3><ol>
    <li>New complaints appear on the dashboard as <i>Submitted</i> and you receive a notification.</li><li>Open a complaint, then <b>Under Review</b> → <b>Accepted</b>, or <b>Rejected</b> with a reason the department will see.</li>
    <li><b>Assign</b> an active technician (add instructions if helpful). Use the same panel to <b>reassign</b>.</li><li>Use <b>Request information</b> when the department must clarify; the SLA clock pauses until they reply.</li>
    <li>When a technician resolves, the department confirms. You can close it yourself from <i>Resolved</i>.</li></ol></div></div>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Reports</h3><ul><li><b>Reports</b> filters by date, department, category, priority, status and technician.</li><li>Print, export CSV (opens in Excel) or download a PDF.</li><li>Recurring problems highlight the same fault being reported repeatedly from the same place.</li><li>All figures are calculated from real records.</li></ul></div></div>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Internal notes</h3><p class="mb-0">Tick <i>Internal note</i> when posting a message to keep it between NIS staff and technicians. Departments never see internal notes or attachments added to them.</p></div></div>
  <?php if ($role === 'super_admin'): ?><div class="col-lg-6"><div class="panel panel-b help-card"><h3>Super Administrator</h3><ul><li>Create NIS administrators, technicians and representatives under <b>Users</b>.</li><li><b>Roles & permissions</b> controls what each role can do.</li><li><b>Audit log</b> shows security-relevant activity.</li><li><b>Settings</b> holds target times, limits and email switch.</li><li>Delete the <span class="mono">/install</span> folder after installation.</li></ul></div></div><?php endif; ?>
<?php endif; ?>
  <div class="col-lg-6"><div class="panel panel-b help-card"><h3>Account and security</h3><ul><li>Change your password from the menu at top right. Use 10+ characters with letters and numbers.</li><li>Never share your password. NIS will never ask for it.</li><li>Sessions end after a period of inactivity.</li><li>Read the <a href="<?= e(url('terms')) ?>">Terms of Service</a>.</li></ul>
    <?php if (setting('support_email')): ?><p class="mb-0 mt-2">Need help? <a href="mailto:<?= e(setting('support_email')) ?>"><?= e(setting('support_email')) ?></a></p><?php endif; ?></div></div>
</div>

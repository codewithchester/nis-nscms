<div class="page-head"><div><h2>Users</h2><p>Technicians, department representatives<?= $actor['role'] === 'super_admin' ? ' and administrators' : '' ?>.</p></div>
  <a class="btn btn-primary" href="<?= e(url('users/create')) ?>"><?= icon('person-plus') ?> Add user</a></div>
<div class="panel">
  <form class="filters" method="get" action="<?= e(url('users')) ?>" data-noguard>
    <input type="hidden" name="r" value="users">
    <div><label class="form-label" for="q">Search</label><input class="form-control" id="q" name="q" value="<?= e($q) ?>" placeholder="Name or email" maxlength="100"></div>
    <div><label class="form-label" for="role">Role</label><select class="form-select" id="role" name="role"><option value="">All roles</option><?php foreach ($roles as $r): ?><option value="<?= e($r['slug']) ?>"<?= $role === $r['slug'] ? ' selected' : '' ?>><?= e($r['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="department">Department</label><select class="form-select" id="department" name="department"><option value="">All</option><?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>"<?= (int)$dept === (int)$d['id'] ? ' selected' : '' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="status">Status</label><select class="form-select" id="status" name="status"><option value="">All</option><option value="active"<?= $st === 'active' ? ' selected' : '' ?>>Active</option><option value="inactive"<?= $st === 'inactive' ? ' selected' : '' ?>>Inactive</option></select></div>
    <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Filter</button><?php if ($q !== '' || $role !== '' || $dept || $st !== ''): ?><a class="btn btn-outline-secondary" href="<?= e(url('users')) ?>">Clear</a><?php endif; ?></div>
  </form>
  <?php if (!$rows): ?><div class="empty"><div class="glyph"><?= icon('people') ?></div><h3>No users found</h3><p>Add a technician or department representative to get started.</p></div>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Name</th><th>Role</th><th>Department</th><th>Last sign-in</th><th>Status</th><th class="text-end">Actions</th></tr></thead><tbody>
    <?php foreach ($rows as $r): $self = (int)$r['id'] === (int)$actor['id']; ?>
    <tr><td><b><?= e($r['full_name']) ?></b><div class="small text-muted"><?= e($r['email']) ?></div></td><td><?= e($r['role_name']) ?></td><td class="small"><?= e($r['department_name'] ?: '—') ?></td>
      <td class="small text-muted"><?= e($r['last_login_at'] ? ago($r['last_login_at']) : 'Never') ?></td>
      <td><?= $r['is_active'] ? '<span class="pill st-resolved">Active</span>' : '<span class="pill st-closed">Inactive</span>' ?></td>
      <td class="text-end text-nowrap">
        <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('users/edit', ['id' => $r['id']])) ?>">Edit</a>
        <?php if (!$self): ?>
        <form class="d-inline" method="post" action="<?= e(url('users/reset-password')) ?>" data-confirm="Generate a new temporary password for <?= e($r['full_name']) ?>?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm btn-outline-secondary" type="submit">Reset password</button></form>
        <form class="d-inline" method="post" action="<?= e(url('users/toggle')) ?>" data-confirm="<?= $r['is_active'] ? 'Deactivate' : 'Activate' ?> <?= e($r['full_name']) ?>?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$r['id'] ?>"><button class="btn btn-sm <?= $r['is_active'] ? 'btn-outline-danger' : 'btn-outline-primary' ?>" type="submit"><?= $r['is_active'] ? 'Deactivate' : 'Activate' ?></button></form>
        <?php endif; ?></td></tr>
    <?php endforeach; ?></tbody></table></div>
  <?php $query = ['q' => $q, 'role' => $role, 'department' => $dept ?: null, 'status' => $st]; $route = 'users'; $label = 'users'; include APP_ROOT . '/app/Views/partials/pagination.php'; ?>
  <?php endif; ?>
</div>

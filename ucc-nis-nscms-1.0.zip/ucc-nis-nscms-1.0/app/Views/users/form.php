<?php $edit = $t !== null; $v = fn($k) => old($k, $t[$k] ?? ''); $roleVal = old('role', $edit ? $t['role'] : ''); $deptVal = old('department_id', $edit ? (string)($t['department_id'] ?? '') : ($preDept ?: '')); ?>
<div class="page-head"><div><h2><?= $edit ? 'Edit user' : 'Add user' ?></h2><p><?= $edit ? e($t['role_name']) : 'A temporary password is generated and shown once after you save.' ?></p></div></div>
<form class="panel" method="post" action="<?= e(url($edit ? 'users/update' : 'users/store')) ?>" novalidate>
  <?= csrf_field() ?><?php if ($edit): ?><input type="hidden" name="id" value="<?= (int)$t['id'] ?>"><?php endif; ?>
  <div class="panel-b row g-3">
    <div class="col-md-6"><?php $name='full_name'; $label='Full name'; $required=true; $value=$v('full_name'); $attrs='maxlength="120"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='email'; $label='Email address'; $type='email'; $required=true; $value=$v('email'); $attrs='maxlength="150" autocomplete="off"'; include __DIR__.'/../partials/field.php'; ?></div>
    <div class="col-md-6"><?php $name='phone'; $label='Phone'; $type='tel'; $value=$v('phone'); $attrs='maxlength="30"'; include __DIR__.'/../partials/field.php'; ?></div>
    <?php if (!$edit): ?>
    <div class="col-md-6"><?php $name='role'; $label='Role'; $required=true; $type='select'; $value=$roleVal; $options=['' => 'Choose a role…'] + array_column($roles, 'name', 'slug'); include __DIR__.'/../partials/field.php'; ?></div>
    <?php endif; ?>
    <?php if (!$edit || $t['role'] === 'department_rep'): ?>
    <div class="col-md-6" id="dept-wrap"><?php $name='department_id'; $label='Department (required for representatives)'; $type='select'; $value=$deptVal; $options=['' => 'Choose a department…'] + array_column($departments, 'name', 'id'); include __DIR__.'/../partials/field.php'; ?></div>
    <?php endif; ?>
  </div>
  <div class="panel-b border-top"><button class="btn btn-primary" type="submit"><?= $edit ? 'Save changes' : 'Create account' ?></button> <a class="btn btn-outline-secondary" href="<?= e(url('users')) ?>">Cancel</a></div>
</form>

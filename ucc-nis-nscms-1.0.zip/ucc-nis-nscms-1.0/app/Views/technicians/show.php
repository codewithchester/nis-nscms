<div class="page-head"><div><h2><?= e($t['full_name']) ?></h2><p><?= e($t['email']) ?> · <?= $t['is_active'] ? 'Active' : 'Inactive' ?> · last sign-in <?= e($t['last_login_at'] ? ago($t['last_login_at']) : 'never') ?></p></div>
  <a class="btn btn-outline-secondary" href="<?= e(url('technicians')) ?>">All technicians</a></div>
<div class="row g-3">
  <div class="col-xl-8"><div class="panel"><div class="panel-h"><h3>Assignments</h3></div>
    <?php if (!$assignments): ?><div class="empty"><div class="glyph"><?= icon('clipboard') ?></div><h3>No assignments yet</h3></div><?php else: ?>
    <div class="table-wrap"><table class="tbl"><thead><tr><th>Complaint</th><th>Department</th><th>Assigned</th><th>Assignment</th><th>Complaint status</th></tr></thead><tbody>
      <?php foreach ($assignments as $a): ?><tr><td class="title-cell"><a class="mono" href="<?= e(url('complaints/view', ['id' => $a['complaint_id']])) ?>"><?= e($a['reference_no']) ?></a><div class="small"><?= e(mb_strimwidth($a['title'], 0, 50, '…')) ?></div></td>
        <td class="small"><?= e($a['department_name']) ?></td><td class="small"><?= e(fmt_dt($a['assigned_at'])) ?><br><span class="text-muted">by <?= e($a['assigner']) ?></span></td>
        <td><span class="tag"><?= e($a['assignment_status']) ?></span><?= $a['completed_at'] ? '<div class="small text-muted">' . e(fmt_dt($a['completed_at'], 'd M Y')) . '</div>' : '' ?></td><td><?= status_badge($a['status']) ?></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div></div>
  <div class="col-xl-4"><div class="panel"><div class="panel-h"><h3>Recent activity</h3></div>
    <?php if (!$activity): ?><div class="empty py-4"><p class="mb-0">No updates posted yet.</p></div><?php else: foreach ($activity as $a): ?>
      <a class="notif-item" href="<?= e(url('complaints/view', ['id' => $a['complaint_id']])) ?>"><b><span class="mono"><?= e($a['reference_no']) ?></span> <span class="tag"><?= e(str_replace('_', ' ', $a['kind'])) ?></span><?= $a['is_internal'] ? ' <span class="tag internal">internal</span>' : '' ?></b><span><?= e(mb_strimwidth($a['body'], 0, 90, '…')) ?></span><time><?= e(ago($a['created_at'])) ?></time></a>
    <?php endforeach; endif; ?></div></div>
</div>

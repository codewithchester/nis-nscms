<div class="page-head"><div><h2>Technicians</h2><p>Workload and performance of the network technicians.</p></div>
  <?php if (can('users.manage')): ?><a class="btn btn-primary" href="<?= e(url('users/create', [])) ?>"><?= icon('person-plus') ?> Register technician</a><?php endif; ?></div>
<div class="panel">
<?php if (!$rows): ?><div class="empty"><div class="glyph"><?= icon('tools') ?></div><h3>No technicians registered</h3><p>Register technicians so complaints can be assigned to them.</p></div>
<?php else: $maxOpen = max(1, max(array_map(fn($r) => (int)$r['open_count'], $rows))); ?>
<div class="table-wrap"><table class="tbl"><thead><tr><th>Technician</th><th>Open workload</th><th class="num">In progress</th><th class="num">Overdue</th><th class="num">Completed</th><th class="num">Avg. completion</th><th>Last activity</th></tr></thead><tbody>
<?php foreach ($rows as $r): ?>
<tr><td><a href="<?= e(url('technicians/view', ['id' => $r['id']])) ?>"><b><?= e($r['full_name']) ?></b></a><?= $r['is_active'] ? '' : ' <span class="tag">Inactive</span>' ?><div class="small text-muted"><?= e($r['email']) ?></div></td>
  <td><div class="bar-row mb-0"><div class="track"><div class="fill" data-width="<?= e(round(100 * (int)$r['open_count'] / $maxOpen)) ?>"></div></div><span class="v"><?= (int)$r['open_count'] ?></span></div></td>
  <td class="num"><?= (int)$r['in_progress'] ?></td><td class="num <?= $r['overdue'] > 0 ? 'flag-overdue' : '' ?>"><?= (int)$r['overdue'] ?></td><td class="num"><?= (int)$r['completed'] ?></td>
  <td class="num"><?= e(hours_label($r['avg_hours'])) ?></td><td class="small text-muted"><?= e($r['last_activity'] ? ago($r['last_activity']) : '—') ?></td></tr>
<?php endforeach; ?></tbody></table></div><?php endif; ?>
</div>

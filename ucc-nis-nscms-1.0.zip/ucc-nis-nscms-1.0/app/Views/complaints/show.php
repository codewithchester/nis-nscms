<?php
use App\Services\Workflow;
$status = $c['status'];
$flow = ['Submitted', 'Under Review', 'Accepted', 'Assigned', 'In Progress', 'Resolved', 'Closed'];
$halted = false; $rejected = false;
if ($status === 'Rejected') { $steps = ['Submitted', 'Under Review', 'Rejected']; $cur = 2; $halted = true; $rejected = true; }
else {
  $steps = $flow;
  $effective = $status === Workflow::AWAITING ? ($c['status_before_hold'] ?: 'Under Review') : $status;
  $cur = array_search($effective, $flow, true); if ($cur === false) $cur = 0;
  $halted = $status === Workflow::AWAITING;
}
$kindLabel = ['comment' => 'Message', 'update' => 'Progress update', 'finding' => 'Technical finding', 'work_performed' => 'Work performed', 'resolution' => 'Resolution', 'info_request' => 'Information requested', 'info_response' => 'Department response'];
$optLabel = function (string $from, string $to) use ($u): string {
  if ($u['role'] === 'department_rep' && $from === 'Resolved') return $to === 'Closed' ? 'Confirm resolved and close' : 'Not fixed — reopen';
  if ($u['role'] === 'technician') return $to === 'In Progress' ? 'Start work (In Progress)' : ($to === Workflow::AWAITING ? 'Ask the department for information' : ($to === 'Resolved' ? 'Mark as resolved' : $to));
  return $to === Workflow::AWAITING ? 'Request information from department' : $to;
};
$notes = [];
foreach ($allowed as $to) $notes[$to] = ['label' => Workflow::noteLabel($status, $to), 'required' => Workflow::noteRequired($status, $to)];
$q = ['id' => $c['id']];
?>
<div class="page-head">
  <div>
    <div class="d-flex flex-wrap align-items-center gap-2 mb-1"><span class="ref-badge"><?= e($c['reference_no']) ?></span> <?= status_badge($status) ?> <?= priority_badge($c['priority']) ?>
      <?php if ($overdue): ?><span class="flag-overdue">Overdue</span><?php endif; ?></div>
    <h2><?= e($c['title']) ?></h2>
  </div>
  <div class="d-flex gap-2 flex-wrap">
    <a class="btn btn-outline-secondary btn-sm" href="<?= e(url('complaints/print', $q)) ?>" target="_blank" rel="noopener"><?= icon('printer') ?> Print</a>
    <a class="btn btn-outline-secondary btn-sm" href="<?= e(url('complaints/pdf', $q)) ?>"><?= icon('file-earmark-pdf') ?> Download PDF</a>
    <a class="btn btn-outline-secondary btn-sm" href="<?= e(url('complaints')) ?>">Back to list</a>
  </div>
</div>

<div class="panel panel-b mb-3">
  <div class="tracker<?= $halted ? ' halted' : '' ?><?= $rejected ? ' is-rejected' : '' ?>" role="list" aria-label="Complaint progress">
    <?php foreach ($steps as $i => $s):
      $done = $i < $cur || ($status === 'Closed' && $i === $cur);
      $now = $i === $cur && !$done; ?>
      <div class="hop<?= $done ? ' done' : '' ?><?= $now ? ' now' : '' ?>" role="listitem" <?= $now ? 'aria-current="step"' : '' ?>>
        <div class="node"><?= $done ? icon('check-lg') : ($now && $halted ? icon($rejected ? 'x-lg' : 'pause-fill') : '') ?></div>
        <?= e($s) ?><?php if ($now && $status === Workflow::AWAITING): ?><br><small>awaiting your reply</small><?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <?php if ($status === Workflow::AWAITING): ?><p class="small text-muted mb-0 mt-2">Progress is paused while NIS waits for information from the department.</p><?php endif; ?>
</div>

<?php if ($status === Workflow::AWAITING && $u['role'] === 'department_rep'): ?>
  <div class="callout"><b>NIS is waiting for your reply.</b> Read the latest request in the discussion below and respond so work can continue.</div>
<?php endif; ?>
<?php if ($status === 'Resolved' && $u['role'] === 'department_rep' && $allowed): ?>
  <div class="callout info"><b>NIS reports this problem as resolved.</b> Please confirm and close it, or reopen it if the fault is still there.</div>
<?php endif; ?>
<?php if ($status === 'Rejected' && $c['rejection_reason']): ?>
  <div class="callout"><b>Reason for rejection:</b> <?= e($c['rejection_reason']) ?></div>
<?php endif; ?>

<div class="row g-3">
  <div class="col-xl-8">
    <div class="panel mb-3">
      <div class="panel-h"><h3>Details</h3></div>
      <div class="panel-b">
        <dl class="kv">
          <dt>Department</dt><dd><?= e($c['department_name']) ?></dd>
          <dt>Category</dt><dd><?= e($c['category_name']) ?></dd>
          <dt>Location</dt><dd><?= e($c['building']) ?> — <?= e($c['room']) ?></dd>
          <dt>Reported by</dt><dd><?= e($c['reporter_name']) ?> · <a href="mailto:<?= e($c['reporter_email']) ?>"><?= e($c['reporter_email']) ?></a> · <?= e($c['reporter_phone']) ?></dd>
          <dt>Problem noticed</dt><dd><?= e(fmt_dt($c['reported_at'])) ?></dd>
          <dt>Submitted</dt><dd><?= e(fmt_dt($c['created_at'])) ?></dd>
          <dt>Target resolution</dt><dd class="<?= $overdue ? 'flag-overdue' : '' ?>"><?= e(fmt_dt($c['due_at'])) ?><?= $overdue ? ' · overdue' : '' ?></dd>
          <dt>Assigned technician</dt><dd><?= $c['technician_name'] ? e($c['technician_name']) : '<span class="text-muted">Not yet assigned</span>' ?></dd>
          <?php if ($c['resolved_at']): ?><dt>Resolved</dt><dd><?= e(fmt_dt($c['resolved_at'])) ?></dd><?php endif; ?>
          <?php if ($c['closed_at']): ?><dt>Closed</dt><dd><?= e(fmt_dt($c['closed_at'])) ?></dd><?php endif; ?>
        </dl>
        <hr>
        <div class="desc"><?= e($c['description']) ?></div>
      </div>
    </div>

    <?php if ($attachments): ?>
    <div class="panel mb-3"><div class="panel-h"><h3>Attachments</h3></div><div class="panel-b">
      <?php foreach ($attachments as $a): ?>
        <a class="attach" href="<?= e(url('attachments/download', ['id' => $a['id']])) ?>"><?= icon('paperclip') ?><span><b><?= e($a['original_name']) ?></b><br><small class="text-muted"><?= e(human_size((int)$a['size_bytes'])) ?> · <?= e($a['full_name']) ?> · <?= e(fmt_dt($a['created_at'])) ?></small></span></a>
      <?php endforeach; ?></div></div>
    <?php endif; ?>

    <div class="panel mb-3">
      <div class="panel-h"><h3>Discussion and updates</h3></div>
      <div class="panel-b thread">
        <?php if (!$comments): ?><p class="text-muted mb-0">No messages yet.</p><?php endif; ?>
        <?php foreach ($comments as $m):
          $ownMessage = (int)$m['user_id'] === (int)$u['id'];
          $cls = ($ownMessage ? ' own' : ' received') . ($m['is_internal'] ? ' internal' : ($m['kind'] === 'info_request' ? ' request' : ($m['kind'] === 'resolution' ? ' resolution' : '')));
        ?>
          <div class="msg<?= $cls ?>">
            <div class="msg-head">
              <span class="msg-avatar" aria-hidden="true"><?= e(initials($m['full_name'])) ?></span>
              <div class="meta"><b><?= e($m['full_name']) ?></b><span><?= e($m['role_name']) ?></span><span><?= e(fmt_dt($m['created_at'])) ?></span>
                <span class="tag"><?= e($kindLabel[$m['kind']] ?? $m['kind']) ?></span><?php if ($m['is_internal']): ?><span class="tag internal">Internal — not visible to department</span><?php endif; ?></div>
            </div>
            <div class="desc"><?= e($m['body']) ?></div>
          </div>
        <?php endforeach; ?>

        <?php if ($canComment): ?>
        <form method="post" action="<?= e(url('complaints/comment')) ?>" enctype="multipart/form-data" class="mt-3">
          <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
          <?php if ($isTech): ?>
            <div class="mb-2"><label class="form-label" for="kind">Type of update</label>
              <select class="form-select" id="kind" name="kind"><option value="update">Progress update</option><option value="finding">Technical finding</option><option value="work_performed">Work performed</option></select></div>
          <?php endif; ?>
          <label class="form-label req" for="body"><?= $u['role'] === 'department_rep' ? ($status === Workflow::AWAITING ? 'Your reply to NIS' : 'Add a message') : ($isTech ? 'Details' : 'Message') ?></label>
          <textarea class="form-control" id="body" name="body" rows="4" maxlength="5000" required></textarea>
          <div class="row g-2 mt-1 align-items-center">
            <div class="col-md-7"><input class="form-control form-control-sm" type="file" name="attachment" data-max-mb="<?= (int)$maxMb ?>" aria-label="Attachment (optional)"><div class="form-text">Optional attachment, max <?= (int)$maxMb ?> MB.</div></div>
            <div class="col-md-5">
              <?php if ($isTech): ?><div class="form-check"><input class="form-check-input" type="checkbox" id="visible" name="visible" value="1" checked><label class="form-check-label" for="visible">Visible to the department</label></div>
              <?php elseif ($isStaff): ?><div class="form-check"><input class="form-check-input" type="checkbox" id="internal" name="internal" value="1"><label class="form-check-label" for="internal">Internal note (hide from department)</label></div><?php endif; ?>
            </div>
          </div>
          <button class="btn btn-primary mt-2" type="submit"><?= $status === Workflow::AWAITING && $u['role'] === 'department_rep' ? 'Send reply' : 'Post' ?></button>
        </form>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="col-xl-4">
    <?php if ($canAssign): ?>
    <div class="action-card"><h3><?= $c['assigned_to'] ? 'Reassign technician' : 'Assign to a technician' ?></h3><div class="in">
      <?php if (!$technicians): ?><p class="text-muted small mb-0">No active technicians yet. <?php if (can('users.manage')): ?><a href="<?= e(url('users/create')) ?>">Add a technician</a>.<?php endif; ?></p>
      <?php else: ?>
      <form method="post" action="<?= e(url('complaints/assign')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
        <div class="mb-2"><label class="form-label req" for="technician_id">Technician</label>
          <select class="form-select" id="technician_id" name="technician_id" required><option value="">Choose…</option>
            <?php foreach ($technicians as $t): ?><option value="<?= (int)$t['id'] ?>"<?= (int)$t['id'] === (int)$c['assigned_to'] ? ' disabled' : '' ?>><?= e($t['full_name']) ?><?= (int)$t['id'] === (int)$c['assigned_to'] ? ' (current)' : '' ?></option><?php endforeach; ?></select></div>
        <div class="mb-2"><label class="form-label" for="instructions">Instructions (optional)</label><textarea class="form-control" id="instructions" name="instructions" rows="3" maxlength="2000"></textarea></div>
        <button class="btn btn-primary w-100" type="submit"><?= $c['assigned_to'] ? 'Reassign' : 'Assign' ?></button>
      </form><?php endif; ?></div></div>
    <?php endif; ?>

    <?php if ($allowed): ?>
    <div class="action-card"><h3><?= $u['role'] === 'department_rep' ? 'Your decision' : 'Update status' ?></h3><div class="in">
      <form method="post" action="<?= e(url('complaints/status')) ?>">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
        <div class="mb-2"><label class="form-label" for="to">Change status to</label>
          <select class="form-select" id="to" name="to" data-notes="<?= json_attr($notes) ?>" data-label="note-label" data-note="note">
            <?php foreach ($allowed as $to): ?><option value="<?= e($to) ?>"><?= e($optLabel($status, $to)) ?></option><?php endforeach; ?></select></div>
        <div class="mb-2"><label class="form-label" id="note-label" for="note">Note (optional)</label><textarea class="form-control" id="note" name="note" rows="3" maxlength="3000"></textarea></div>
        <button class="btn btn-primary w-100" type="submit">Save status</button>
      </form></div></div>
    <?php endif; ?>

    <div class="panel mb-3">
      <div class="panel-h"><h3>Status history</h3></div>
      <div class="panel-b"><ol class="timeline">
        <?php foreach (array_reverse($history) as $h): ?>
          <li><div><?= $h['from_status'] && $h['from_status'] !== $h['to_status'] ? e($h['from_status']) . ' → ' : '' ?><b><?= e($h['to_status']) ?></b></div>
            <?php if ($h['note']): ?><div class="small"><?= e(mb_strimwidth($h['note'], 0, 220, '…')) ?></div><?php endif; ?>
            <div class="when"><?= e(fmt_dt($h['created_at'])) ?> · <?= e($h['full_name']) ?></div></li>
        <?php endforeach; ?></ol></div>
    </div>

    <?php if ($assignments): ?>
    <div class="panel mb-3">
      <div class="panel-h"><h3>Assignments</h3></div>
      <div class="panel-b">
        <?php foreach ($assignments as $a): ?>
          <div class="mb-3 pb-3 border-bottom">
            <div class="d-flex justify-content-between"><b><?= e($a['technician_name']) ?></b><span class="tag"><?= e($a['status']) ?></span></div>
            <div class="small text-muted">Assigned by <?= e($a['assigner_name']) ?> · <?= e(fmt_dt($a['assigned_at'])) ?></div>
            <?php if ($a['instructions']): ?><div class="small mt-1"><b>Instructions:</b> <?= e($a['instructions']) ?></div><?php endif; ?>
            <?php if ($a['investigation_notes']): ?><details class="small mt-1"><summary>Investigation notes</summary><div class="desc"><?= e($a['investigation_notes']) ?></div></details><?php endif; ?>
            <?php if ($a['resolution_details']): ?><div class="small mt-1"><b>Resolution:</b> <?= e($a['resolution_details']) ?></div><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

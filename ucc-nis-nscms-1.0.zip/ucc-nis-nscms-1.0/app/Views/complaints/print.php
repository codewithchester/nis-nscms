<div class="doc-title"><h2>Network complaint <?= e($c['reference_no']) ?></h2><span><b><?= e($c['status']) ?></b> · <?= e($c['priority']) ?> priority</span></div>
<div class="grid2">
  <div><span>Department</span><b><?= e($c['department_name']) ?></b></div><div><span>Category</span><b><?= e($c['category_name']) ?></b></div>
  <div><span>Reported by</span><b><?= e($c['reporter_name']) ?></b></div><div><span>Contact</span><b><?= e($c['reporter_email']) ?> · <?= e($c['reporter_phone']) ?></b></div>
  <div><span>Location</span><b><?= e($c['building']) ?>, <?= e($c['room']) ?></b></div><div><span>Problem noticed</span><b><?= e(fmt_dt($c['reported_at'])) ?></b></div>
  <div><span>Submitted</span><b><?= e(fmt_dt($c['created_at'])) ?></b></div><div><span>Target resolution</span><b><?= e(fmt_dt($c['due_at'])) ?></b></div>
  <div><span>Assigned technician</span><b><?= e($c['technician_name'] ?: 'Not yet assigned') ?></b></div><div><span>Resolved</span><b><?= e($c['resolved_at'] ? fmt_dt($c['resolved_at']) : '—') ?></b></div>
</div>
<h3><?= e($c['title']) ?></h3>
<p class="pre"><?= e($c['description']) ?></p>
<?php if ($c['rejection_reason']): ?><h3>Reason for rejection</h3><p class="pre"><?= e($c['rejection_reason']) ?></p><?php endif; ?>
<h3>Status history</h3>
<table><thead><tr><th>When</th><th>Change</th><th>By</th><th>Note</th></tr></thead><tbody>
<?php foreach ($history as $h): ?><tr><td><?= e(fmt_dt($h['created_at'])) ?></td><td><?= e(($h['from_status'] && $h['from_status'] !== $h['to_status'] ? $h['from_status'] . ' → ' : '') . $h['to_status']) ?></td><td><?= e($h['full_name']) ?></td><td><?= e($h['note']) ?></td></tr><?php endforeach; ?>
</tbody></table>
<?php if ($comments): ?><h3>Updates and messages</h3>
<?php foreach ($comments as $m): ?><p><b><?= e($m['full_name']) ?></b> <small>(<?= e($m['role_name']) ?>) · <?= e(fmt_dt($m['created_at'])) ?></small><br><span class="pre"><?= e($m['body']) ?></span></p><?php endforeach; ?><?php endif; ?>
<?php if ($attachments): ?><h3>Attachments</h3><ul><?php foreach ($attachments as $a): ?><li><?= e($a['original_name']) ?> (<?= e(human_size((int)$a['size_bytes'])) ?>)</li><?php endforeach; ?></ul><?php endif; ?>
<div class="sig"><div>Department representative</div><div>NIS officer</div><div>Date</div></div>

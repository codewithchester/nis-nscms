<?php
$q = array_filter($f, fn($v) => $v !== '');
$base = $q + ['sort' => $sort, 'dir' => $dir];
$hasFilters = (bool)$q;
?>
<div class="page-head">
  <div><h2><?= e(\App\Core\View::$title) ?></h2><p><?= (int)$res['total'] ?> record<?= $res['total'] === 1 ? '' : 's' ?><?= $hasFilters ? ' match your filters' : '' ?>.</p></div>
  <?php if (can_report()): ?><a class="btn btn-primary" href="<?= e(url('complaints/create')) ?>"><?= icon('plus-circle') ?> Report a problem</a><?php endif; ?>
</div>
<div class="panel">
  <form class="filters wide" method="get" action="<?= e(url('complaints')) ?>" data-noguard>
    <input type="hidden" name="r" value="complaints">
    <div><label class="form-label" for="q">Search</label><input class="form-control" id="q" name="q" value="<?= e($f['q']) ?>" placeholder="Reference, title, location…" maxlength="100"></div>
    <div><label class="form-label" for="status">Status</label><select class="form-select" id="status" name="status"><option value="">All statuses</option>
      <?php foreach (\App\Services\Workflow::STATUSES as $s): ?><option<?= $f['status'] === $s ? ' selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="priority">Priority</label><select class="form-select" id="priority" name="priority"><option value="">All priorities</option>
      <?php foreach (\App\Services\Workflow::PRIORITIES as $s): ?><option<?= $f['priority'] === $s ? ' selected' : '' ?>><?= e($s) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="category">Category</label><select class="form-select" id="category" name="category"><option value="">All categories</option>
      <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>"<?= (string)$f['category'] === (string)$c['id'] ? ' selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
    <?php if ($staff): ?>
    <div><label class="form-label" for="department">Department</label><select class="form-select" id="department" name="department"><option value="">All departments</option>
      <?php foreach ($departments as $d): ?><option value="<?= (int)$d['id'] ?>"<?= (string)$f['department'] === (string)$d['id'] ? ' selected' : '' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
    <div><label class="form-label" for="technician">Technician</label><select class="form-select" id="technician" name="technician"><option value="">Anyone</option>
      <?php foreach ($technicians as $t): ?><option value="<?= (int)$t['id'] ?>"<?= (string)$f['technician'] === (string)$t['id'] ? ' selected' : '' ?>><?= e($t['full_name']) ?></option><?php endforeach; ?></select></div>
    <?php endif; ?>
    <div><label class="form-label" for="from">Submitted from</label><input class="form-control" type="date" id="from" name="from" value="<?= e($f['from']) ?>"></div>
    <div><label class="form-label" for="to">Submitted to</label><input class="form-control" type="date" id="to" name="to" value="<?= e($f['to']) ?>"></div>
    <div class="d-flex gap-2 align-items-end">
      <div class="form-check mb-2"><input class="form-check-input" type="checkbox" id="overdue" name="overdue" value="1"<?= $f['overdue'] === '1' ? ' checked' : '' ?>><label class="form-check-label" for="overdue">Overdue only</label></div>
    </div>
    <div class="d-flex gap-2"><button class="btn btn-primary" type="submit">Apply</button><?php if ($hasFilters): ?><a class="btn btn-outline-secondary" href="<?= e(url('complaints')) ?>">Clear</a><?php endif; ?></div>
  </form>

  <?php if (!$res['rows']): ?>
    <div class="empty"><div class="glyph"><?= icon($hasFilters ? 'funnel' : 'inbox') ?></div>
      <h3><?= $hasFilters ? 'No complaints match these filters' : 'No complaints yet' ?></h3>
      <p><?= $hasFilters ? 'Try removing a filter or widening the date range.' : 'Complaints you can access will be listed here.' ?></p>
      <?php if (!$hasFilters && can_report()): ?><a class="btn btn-primary" href="<?= e(url('complaints/create')) ?>">Report a problem</a><?php endif; ?></div>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr>
      <th><?= sort_link('complaints', $q, 'reference', 'Reference', $sort, $dir) ?></th>
      <th><?= sort_link('complaints', $q, 'title', 'Title', $sort, $dir) ?></th>
      <?php if ($staff): ?><th><?= sort_link('complaints', $q, 'department', 'Department', $sort, $dir) ?></th><?php endif; ?>
      <th><?= sort_link('complaints', $q, 'category', 'Category', $sort, $dir) ?></th>
      <th><?= sort_link('complaints', $q, 'priority', 'Priority', $sort, $dir) ?></th>
      <th><?= sort_link('complaints', $q, 'status', 'Status', $sort, $dir) ?></th>
      <?php if ($staff): ?><th><?= sort_link('complaints', $q, 'technician', 'Technician', $sort, $dir) ?></th><?php endif; ?>
      <th><?= sort_link('complaints', $q, 'created', 'Submitted', $sort, $dir) ?></th>
      <th><?= sort_link('complaints', $q, 'due', 'Target date', $sort, $dir) ?></th>
    </tr></thead>
    <tbody>
    <?php foreach ($res['rows'] as $r): $over = \App\Models\Complaint::isOverdue($r); ?>
      <tr>
        <td class="ref"><a href="<?= e(url('complaints/view', ['id' => $r['id']])) ?>"><?= e($r['reference_no']) ?></a></td>
        <td class="title-cell"><a href="<?= e(url('complaints/view', ['id' => $r['id']])) ?>"><?= e(mb_strimwidth($r['title'], 0, 70, '…')) ?></a><div class="small text-muted"><?= e($r['building']) ?></div></td>
        <?php if ($staff): ?><td><?= e($r['department_code']) ?></td><?php endif; ?>
        <td class="small"><?= e($r['category_name']) ?></td>
        <td><?= priority_badge($r['priority']) ?></td>
        <td><?= status_badge($r['status']) ?></td>
        <?php if ($staff): ?><td class="small"><?= $r['technician_name'] ? e($r['technician_name']) : '<span class="text-muted">Unassigned</span>' ?></td><?php endif; ?>
        <td class="small text-muted"><?= e(fmt_d($r['created_at'])) ?></td>
        <td class="small <?= $over ? 'flag-overdue' : 'text-muted' ?>"><?= e(fmt_dt($r['due_at'], 'd M, H:i')) ?><?= $over ? ' · Overdue' : '' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php $page = $res['page']; $pages = $res['pages']; $total = $res['total']; $route = 'complaints'; $query = $base; $label = 'complaints'; include APP_ROOT . '/app/Views/partials/pagination.php'; ?>
  <?php endif; ?>
</div>

<div class="page-head"><div><h2>Track a complaint</h2><p>Enter a reference number to see its status and history. You can only look up complaints you are allowed to see.</p></div></div>
<div class="panel mb-3"><div class="panel-b">
  <form class="row g-2 align-items-end" method="get" action="<?= e(url('track')) ?>" data-noguard>
    <input type="hidden" name="r" value="track">
    <div class="col-md-6 col-lg-4"><label class="form-label" for="ref">Reference number</label>
      <input class="form-control mono" id="ref" name="ref" value="<?= e($ref) ?>" placeholder="NIS-<?= e(date('Y')) ?>-00001" maxlength="20" autocomplete="off"></div>
    <div class="col-auto"><button class="btn btn-primary" type="submit"><?= icon('search') ?> Track</button></div>
  </form>
</div></div>

<?php if ($msg): ?><div class="panel"><div class="empty"><div class="glyph"><?= icon('question-lg') ?></div><h3>Nothing to show</h3><p><?= e($msg) ?></p></div></div><?php endif; ?>

<?php if ($c): ?>
<div class="row g-3">
  <div class="col-lg-7"><div class="panel">
    <div class="panel-h"><div><span class="ref-badge"><?= e($c['reference_no']) ?></span></div><div><?= status_badge($c['status']) ?> <?= priority_badge($c['priority']) ?></div></div>
    <div class="panel-b">
      <h3 class="h5"><?= e($c['title']) ?></h3>
      <dl class="kv">
        <dt>Department</dt><dd><?= e($c['department_name']) ?></dd>
        <dt>Category</dt><dd><?= e($c['category_name']) ?></dd>
        <dt>Location</dt><dd><?= e($c['building']) ?> — <?= e($c['room']) ?></dd>
        <dt>Submitted</dt><dd><?= e(fmt_dt($c['created_at'])) ?></dd>
        <dt>Target resolution</dt><dd class="<?= $overdue ? 'flag-overdue' : '' ?>"><?= e(fmt_dt($c['due_at'])) ?><?= $overdue ? ' · overdue' : '' ?></dd>
        <dt>Technician</dt><dd><?= $c['technician_name'] ? e($c['technician_name']) : '<span class="text-muted">Not yet assigned</span>' ?></dd>
        <?php if ($c['resolved_at']): ?><dt>Resolved</dt><dd><?= e(fmt_dt($c['resolved_at'])) ?></dd><?php endif; ?>
      </dl>
      <a class="btn btn-primary mt-2" href="<?= e(url('complaints/view', ['id' => $c['id']])) ?>">Open full details</a>
    </div></div></div>
  <div class="col-lg-5"><div class="panel"><div class="panel-h"><h3>Status history</h3></div><div class="panel-b"><ol class="timeline">
    <?php foreach (array_reverse($history) as $h): ?>
      <li><div><?= $h['from_status'] && $h['from_status'] !== $h['to_status'] ? e($h['from_status']) . ' → ' : '' ?><b><?= e($h['to_status']) ?></b></div>
        <?php if ($h['note']): ?><div class="small"><?= e(mb_strimwidth($h['note'], 0, 160, '…')) ?></div><?php endif; ?>
        <div class="when"><?= e(fmt_dt($h['created_at'])) ?></div></li>
    <?php endforeach; ?></ol></div></div></div>
</div>
<?php elseif ($ref === '' && !$msg): ?>
  <div class="panel"><div class="empty"><div class="glyph"><?= icon('hash') ?></div><h3>Where is my reference number?</h3><p>It was shown when you submitted the complaint and sent to you as a notification. You can also find it in your complaints list.</p>
    <a class="btn btn-outline-secondary" href="<?= e(url('complaints')) ?>">Open my complaints</a></div></div>
<?php endif; ?>

<div class="page-head"><div><h2>Report a network problem</h2><p>Give NIS enough detail to find and fix the fault quickly. Fields marked * are required.</p></div></div>
<form method="post" action="<?= e(url('complaints/store')) ?>" enctype="multipart/form-data" novalidate>
  <?= csrf_field() ?>
  <div class="row g-3">
    <div class="col-lg-8">
      <div class="panel mb-3">
        <div class="panel-h"><h3>The problem</h3></div>
        <div class="panel-b row g-3">
          <div class="col-12"><?php $name='title'; $label='Complaint title'; $required=true; $help='A short summary, e.g. “No internet in Room 204, Science Block”.'; $attrs='maxlength="200"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($help,$attrs); ?></div>
          <div class="col-md-6"><?php $name='category_id'; $label='Problem category'; $required=true; $type='select'; $options=['' => 'Select a category…'] + array_column($categories, 'name', 'id'); include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$options); ?></div>
          <div class="col-md-6"><?php $name='priority'; $label='Priority'; $required=true; $type='select'; $value=old('priority','Medium'); $options=['Low'=>'Low — minor, can wait','Medium'=>'Medium — affects some work','High'=>'High — affects many users','Critical'=>'Critical — whole building or service down']; include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$options,$value); ?></div>
          <div class="col-12"><?php $name='description'; $label='Detailed description'; $required=true; $type='textarea'; $rows=6; $help='What is happening, since when, how many people are affected, and what you have already tried.'; $attrs='maxlength="5000"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$help,$attrs); ?></div>
        </div>
      </div>
      <div class="panel mb-3">
        <div class="panel-h"><h3>Where and when</h3></div>
        <div class="panel-b row g-3">
          <div class="col-md-6"><?php $name='building'; $label='Building or location'; $required=true; $attrs='maxlength="150"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($attrs); ?></div>
          <div class="col-md-6"><?php $name='room'; $label='Office, room or block'; $required=true; $attrs='maxlength="100"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($attrs); ?></div>
          <div class="col-md-6"><?php $name='reported_at'; $label='Date and time the problem was noticed'; $required=true; $type='datetime-local'; $value=old('reported_at',$now); $attrs='max="'.e($now).'"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$value,$attrs); ?></div>
          <div class="col-md-6"><label class="form-label" for="attachment">Supporting attachment (optional)</label>
            <?php $attachmentError = field_error('attachment'); ?>
            <input class="form-control<?= invalid('attachment') ?>" type="file" id="attachment" name="attachment" data-max-mb="<?= (int)$maxMb ?>" accept=".jpg,.jpeg,.png,.gif,.webp,.pdf,.txt,.log,.csv,.doc,.docx,.xls,.xlsx" aria-describedby="attachment_help<?= $attachmentError ? ' attachment_error' : '' ?>"<?= $attachmentError ? ' aria-invalid="true"' : '' ?>>
            <?php if ($attachmentError): ?><div id="attachment_error" class="invalid-feedback d-block"><?= e($attachmentError) ?></div><?php endif; ?>
            <div class="form-text" id="attachment_help">Screenshot, photo or log. Max <?= (int)$maxMb ?> MB. <?= e($exts) ?>.</div></div>
        </div>
      </div>
    </div>
    <div class="col-lg-4">
      <div class="panel mb-3">
        <div class="panel-h"><h3>Reporter</h3></div>
        <div class="panel-b row g-3">
          <div class="col-12"><label class="form-label">Department</label><input class="form-control" value="<?= e($u['department_name']) ?>" disabled><div class="form-text">Set from your account.</div></div>
          <div class="col-12"><?php $name='reporter_name'; $label='Person reporting the issue'; $required=true; $value=old('reporter_name',$u['full_name']); $attrs='maxlength="120"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($value,$attrs); ?></div>
          <div class="col-12"><?php $name='reporter_email'; $label='Contact email'; $required=true; $type='email'; $value=old('reporter_email',$u['email']); $attrs='maxlength="150"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$value,$attrs); ?></div>
          <div class="col-12"><?php $name='reporter_phone'; $label='Contact phone'; $required=true; $type='tel'; $value=old('reporter_phone',$u['phone'] ?? ''); $attrs='maxlength="30"'; include APP_ROOT.'/app/Views/partials/field.php'; unset($type,$value,$attrs); ?></div>
        </div>
      </div>
      <div class="panel panel-b">
        <p class="small text-muted">A reference number such as <span class="mono">NIS-<?= e(date('Y')) ?>-00001</span> is generated when you submit. Target times: Critical <?= (int)setting('sla_hours_critical', 4) ?> h · High <?= (int)setting('sla_hours_high', 24) ?> h · Medium <?= (int)setting('sla_hours_medium', 72) ?> h · Low <?= (int)setting('sla_hours_low', 168) ?> h.</p>
        <button class="btn btn-primary w-100" type="submit">Submit complaint</button>
        <a class="btn btn-link w-100" href="<?= e(url('dashboard')) ?>">Cancel</a>
      </div>
    </div>
  </div>
</form>

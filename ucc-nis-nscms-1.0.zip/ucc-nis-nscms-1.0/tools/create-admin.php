<?php
declare(strict_types=1);
/**
 * Create a Super Administrator from the command line (useful if you imported database/schema.sql manually).
 * Usage:  php tools/create-admin.php
 *         php tools/create-admin.php "Full Name" admin@ucc.edu.gh
 * The password is asked for interactively (never passed on the command line).
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }

define('APP_ROOT', dirname(__DIR__));
require APP_ROOT . '/app/Core/Env.php';
require APP_ROOT . '/app/Core/Password.php';

use App\Core\{Env, Password};

if (!Env::load(APP_ROOT . '/.env')) { fwrite(STDERR, "No .env file found. Copy .env.example to .env and set the DB_* values first.\n"); exit(1); }

$name = $argv[1] ?? trim((string)readline('Full name: '));
$email = strtolower($argv[2] ?? trim((string)readline('Email: ')));
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $name === '') { fwrite(STDERR, "Invalid name or email.\n"); exit(1); }

if (function_exists('shell_exec') && DIRECTORY_SEPARATOR === '/') { shell_exec('stty -echo'); }
$pw = (string)readline('Password (min 10 chars, letters + numbers; input hidden on Linux/macOS): ');
if (function_exists('shell_exec') && DIRECTORY_SEPARATOR === '/') { shell_exec('stty echo'); echo "\n"; }
if ($err = Password::policy($pw, $email, $name)) { fwrite(STDERR, $err . "\n"); exit(1); }

try {
    $pdo = new PDO(sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', Env::get('DB_HOST', '127.0.0.1'), (int)Env::get('DB_PORT', '3306'), Env::get('DB_NAME')),
        Env::get('DB_USER'), Env::get('DB_PASS'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $role = $pdo->query("SELECT id FROM roles WHERE slug = 'super_admin'")->fetchColumn();
    if (!$role) { fwrite(STDERR, "Roles table is empty. Import database/schema.sql first.\n"); exit(1); }
    $st = $pdo->prepare('INSERT INTO users (role_id, full_name, email, password_hash, password_changed_at) VALUES (?,?,?,?,NOW())');
    $st->execute([$role, $name, $email, Password::hash($pw)]);
    echo "Super Administrator created: $email\n";
} catch (PDOException $e) {
    fwrite(STDERR, 'Database error: ' . $e->getMessage() . "\n");
    exit(1);
}

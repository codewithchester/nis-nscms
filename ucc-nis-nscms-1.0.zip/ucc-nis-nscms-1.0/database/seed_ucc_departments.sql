-- UCC NIS NSCMS department records.
-- This application schema has no `description` column, so the supplied
-- school/faculty group labels are stored in the existing `location` field.
-- Safe to rerun: matching department names or codes are updated.

INSERT INTO departments (name, code, location, is_active)
VALUES
-- COLLEGE OF AGRICULTURE AND NATURAL SCIENCES
('Department of Agri-Food Systems and Technology', 'DAFST', 'School of Agriculture', 1),
('Department of Agricultural Economics and Extension', 'DAEE', 'School of Agriculture', 1),
('Department of Animal Science', 'DAS', 'School of Agriculture', 1),
('Department of Crop Science', 'DCS-AGRI', 'School of Agriculture', 1),
('Department of Soil Science', 'DSS', 'School of Agriculture', 1),
('Department of Biochemistry', 'DBC', 'School of Biological Sciences', 1),
('Department of Conservation Biology and Entomology', 'DCBE', 'School of Biological Sciences', 1),
('Department of Environmental Science', 'DES', 'School of Biological Sciences', 1),
('Department of Fisheries and Aquatic Sciences', 'DFAS', 'School of Biological Sciences', 1),
('Department of Forensic Sciences', 'DFS', 'School of Biological Sciences', 1),
('Department of Molecular Biology and Biotechnology', 'DMBB', 'School of Biological Sciences', 1),
('Department of Chemistry', 'DOC', 'School of Physical Sciences', 1),
('Department of Computer Science and Information Technology', 'DCSI', 'School of Physical Sciences', 1),
('Department of Industrial Chemistry', 'DIC', 'School of Physical Sciences', 1),
('Department of Laboratory Technology', 'DLT', 'School of Physical Sciences', 1),
('Department of Mathematics', 'DOM', 'School of Physical Sciences', 1),
('Department of Physics', 'DOP', 'School of Physical Sciences', 1),
('Department of Statistics', 'DOS', 'School of Physical Sciences', 1),

-- COLLEGE OF DISTANCE EDUCATION
('CoDE Department of Business Studies', 'CODB', 'College of Distance Education', 1),
('CoDE Department of Education', 'CODED', 'College of Distance Education', 1),

-- COLLEGE OF EDUCATION STUDIES
('Department of Basic Education', 'DBE', 'Faculty of Educational Foundations', 1),
('Department of Education and Psychology', 'DEP', 'Faculty of Educational Foundations', 1),
('Department of Guidance and Counselling', 'DGC', 'Faculty of Educational Foundations', 1),
('Department of Arts Education', 'DAE', 'Faculty of Humanities and Social Sciences Education', 1),
('Department of Business and Social Sciences Education', 'DBSS', 'Faculty of Humanities and Social Sciences Education', 1),
('Department of Health, Physical Education and Recreation', 'DHPE', 'Faculty of Science and Technology Education', 1),
('Department of Mathematics and ICT Education', 'DMIC', 'Faculty of Science and Technology Education', 1),
('Department of Science Education', 'DSE', 'Faculty of Science and Technology Education', 1),
('Department of Vocational and Technical Education', 'DVTE', 'Faculty of Science and Technology Education', 1),

-- COLLEGE OF HEALTH AND ALLIED SCIENCES
('Department of Biomedical Sciences', 'DOBS', 'School of Allied Health Sciences', 1),
('Department of Optometry and Vision Sciences', 'DOVS', 'School of Allied Health Sciences', 1),
('Department of Physician Assistant Studies', 'DPAS', 'School of Allied Health Sciences', 1),
('Department of Anatomy', 'DAN', 'School of Medical Sciences', 1),
('Department of Medical Biochemistry', 'DMB', 'School of Medical Sciences', 1),
('Department of Medical Education', 'DME', 'School of Medical Sciences', 1),
('Department of Microbiology and Immunology', 'MICIMM', 'School of Medical Sciences', 1),
('Department of Nutrition and Dietetics', 'DND', 'School of Medical Sciences', 1),
('Department of Adult Health Nursing', 'DAHN', 'School of Nursing and Midwifery', 1),
('Department of Maternal and Child Health', 'DMCH', 'School of Nursing and Midwifery', 1),
('Department of Mental Health', 'DMH', 'School of Nursing and Midwifery', 1),
('Department of Pharmacotherapeutics and Pharmacy Practice', 'DPP', 'School of Pharmacy and Pharmaceutical Sciences', 1),

-- COLLEGE OF HUMANITIES AND LEGAL STUDIES
('Department of Classics and Philosophy', 'DCPY', 'Faculty of Arts', 1),
('Department of Communication Studies', 'DCS-COMM', 'Faculty of Arts', 1),
('Department of English', 'DOE', 'Faculty of Arts', 1),
('Department of French', 'DFR', 'Faculty of Arts', 1),
('Department of Ghanaian Languages and Linguistics', 'DGLL', 'Faculty of Arts', 1),
('Department of History and Diplomacy', 'DOH', 'Faculty of Arts', 1),
('Department of Information Science', 'DOIS', 'Faculty of Arts', 1),
('Department of Music and Dance', 'DMD', 'Faculty of Arts', 1),
('Department of Religion and Human Values', 'DRHV', 'Faculty of Arts', 1),
('Department of Theatre and Film Studies', 'DTFS', 'Faculty of Arts', 1),
('Department of Geography and Regional Planning', 'DGRP', 'Faculty of Social Sciences', 1),
('Department of Hospitality and Tourism Management', 'DHTM', 'Faculty of Social Sciences', 1),
('Department of Population and Health', 'DPOH', 'Faculty of Social Sciences', 1),
('Department of Sociology and Anthropology', 'DSA', 'Faculty of Social Sciences', 1),
('Department of Environment, Governance and Sustainable Development', 'DEGS', 'School for Development Studies', 1),
('Department of Integrated Development Studies', 'DIDS', 'School for Development Studies', 1),
('Department of Labour and Human Resource Studies', 'DLHR', 'School for Development Studies', 1),
('Department of Peace Studies', 'DPS', 'School for Development Studies', 1),
('Department of Accounting', 'DOA', 'School of Business', 1),
('Department of Finance', 'DFIN', 'School of Business', 1),
('Department of Human Resource Management', 'DHRM', 'School of Business', 1),
('Department of Management', 'DMAN', 'School of Business', 1),
('Department of Marketing and Supply Chain Management', 'DMSC', 'School of Business', 1),
('Department of Applied Economics', 'DAPE', 'School of Economics', 1),
('Department of Data Science and Economic Policy', 'DDSE', 'School of Economics', 1),
('Department of Economic Studies', 'DOES', 'School of Economics', 1),

-- UNIVERSITY-WIDE DEPARTMENTS
('Department of Chemical and Renewable Energy Engineering', 'DCRE', 'University-wide', 1),
('Department of Civil and Environmental Engineering', 'DCEE', 'University-wide', 1),
('Department of Clinical Optometry', 'DCO', 'University-wide', 1),
('Department of Computer and Systems Engineering', 'DCSE', 'University-wide', 1),
('Department of Law', 'DOL', 'University-wide', 1),
('Department of Medical Imaging', 'MEDIMG', 'University-wide', 1),
('Department of Medical Laboratory Science', 'DMLS', 'University-wide', 1),
('Department of Ophthalmic Science', 'DOSC', 'University-wide', 1),
('Department of Vision Science', 'DVS', 'University-wide', 1)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    location = VALUES(location),
    is_active = 1;

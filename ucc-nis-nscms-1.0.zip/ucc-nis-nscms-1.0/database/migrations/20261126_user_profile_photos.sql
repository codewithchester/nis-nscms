CREATE TABLE IF NOT EXISTS user_profile_photos (
  user_id INT UNSIGNED NOT NULL,
  stored_name CHAR(40) NOT NULL,
  mime_type VARCHAR(30) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_profile_photo_stored (stored_name),
  CONSTRAINT fk_profile_photo_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

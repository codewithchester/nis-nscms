-- =====================================================================
-- UCC NIS Network Support & Complaint Management System (UCC NIS NSCMS)
-- Database installation file  |  MySQL 5.7+ / MariaDB 10.3+  |  utf8mb4
-- Safe to import with phpMyAdmin. Re-running it will not delete data.
-- After importing, create the first Super Administrator with:
--     php tools/create-admin.php        (or use the web installer instead)
-- =====================================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS roles (
  id TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(30) NOT NULL,
  name VARCHAR(60) NOT NULL,
  description VARCHAR(255) NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_slug (slug)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS permissions (
  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(60) NOT NULL,
  label VARCHAR(120) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_permissions_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id TINYINT UNSIGNED NOT NULL,
  permission_id SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles (id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(150) NOT NULL,
  code VARCHAR(20) NOT NULL,
  head_name VARCHAR(120) NULL,
  email VARCHAR(150) NULL,
  phone VARCHAR(30) NULL,
  location VARCHAR(150) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_departments_name (name),
  UNIQUE KEY uq_departments_code (code),
  KEY idx_departments_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  role_id TINYINT UNSIGNED NOT NULL,
  department_id INT UNSIGNED NULL,
  full_name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30) NULL,
  password_hash VARCHAR(255) NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  must_change_password TINYINT(1) NOT NULL DEFAULT 0,
  terms_version VARCHAR(10) NULL,
  terms_accepted_at DATETIME NULL,
  last_login_at DATETIME NULL,
  last_login_ip VARCHAR(45) NULL,
  password_changed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role (role_id),
  KEY idx_users_department (department_id),
  KEY idx_users_active (is_active),
  CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles (id),
  CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS user_profile_photos (
  user_id INT UNSIGNED NOT NULL,
  stored_name CHAR(40) NOT NULL,
  mime_type VARCHAR(30) NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_profile_photo_stored (stored_name),
  CONSTRAINT fk_profile_photo_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS complaint_categories (
  id SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  sort_order SMALLINT NOT NULL DEFAULT 0,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_categories_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_counters (
  ref_year SMALLINT UNSIGNED NOT NULL,
  last_seq INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (ref_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS complaints (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  reference_no VARCHAR(20) NOT NULL,
  department_id INT UNSIGNED NOT NULL,
  submitted_by INT UNSIGNED NOT NULL,
  assigned_to INT UNSIGNED NULL,
  category_id SMALLINT UNSIGNED NOT NULL,
  reporter_name VARCHAR(120) NOT NULL,
  reporter_email VARCHAR(150) NOT NULL,
  reporter_phone VARCHAR(30) NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  building VARCHAR(150) NOT NULL,
  room VARCHAR(100) NOT NULL,
  reported_at DATETIME NOT NULL,
  priority ENUM('Low','Medium','High','Critical') NOT NULL DEFAULT 'Medium',
  status ENUM('Submitted','Under Review','Accepted','Assigned','In Progress','Awaiting Department Response','Resolved','Closed','Rejected') NOT NULL DEFAULT 'Submitted',
  status_before_hold VARCHAR(40) NULL,
  rejection_reason TEXT NULL,
  due_at DATETIME NOT NULL,
  resolved_at DATETIME NULL,
  closed_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_complaints_reference (reference_no),
  KEY idx_complaints_department (department_id),
  KEY idx_complaints_status (status),
  KEY idx_complaints_priority (priority),
  KEY idx_complaints_category (category_id),
  KEY idx_complaints_assigned (assigned_to),
  KEY idx_complaints_created (created_at),
  KEY idx_complaints_due (due_at),
  KEY idx_complaints_recurring (department_id, category_id, building),
  CONSTRAINT fk_complaints_department FOREIGN KEY (department_id) REFERENCES departments (id),
  CONSTRAINT fk_complaints_submitter FOREIGN KEY (submitted_by) REFERENCES users (id),
  CONSTRAINT fk_complaints_assignee FOREIGN KEY (assigned_to) REFERENCES users (id) ON DELETE SET NULL,
  CONSTRAINT fk_complaints_category FOREIGN KEY (category_id) REFERENCES complaint_categories (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS complaint_assignments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  complaint_id INT UNSIGNED NOT NULL,
  technician_id INT UNSIGNED NOT NULL,
  assigned_by INT UNSIGNED NOT NULL,
  assigned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Active','Completed','Reassigned') NOT NULL DEFAULT 'Active',
  instructions TEXT NULL,
  investigation_notes TEXT NULL,
  resolution_details TEXT NULL,
  completed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY idx_assign_complaint (complaint_id),
  KEY idx_assign_technician (technician_id, status),
  CONSTRAINT fk_assign_complaint FOREIGN KEY (complaint_id) REFERENCES complaints (id) ON DELETE CASCADE,
  CONSTRAINT fk_assign_technician FOREIGN KEY (technician_id) REFERENCES users (id),
  CONSTRAINT fk_assign_admin FOREIGN KEY (assigned_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS complaint_status_history (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  complaint_id INT UNSIGNED NOT NULL,
  from_status VARCHAR(40) NULL,
  to_status VARCHAR(40) NOT NULL,
  changed_by INT UNSIGNED NOT NULL,
  note TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_history_complaint (complaint_id, created_at),
  CONSTRAINT fk_history_complaint FOREIGN KEY (complaint_id) REFERENCES complaints (id) ON DELETE CASCADE,
  CONSTRAINT fk_history_user FOREIGN KEY (changed_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS complaint_comments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  complaint_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  kind ENUM('comment','update','finding','work_performed','resolution','info_request','info_response') NOT NULL DEFAULT 'comment',
  body TEXT NOT NULL,
  is_internal TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_comments_complaint (complaint_id, created_at),
  CONSTRAINT fk_comments_complaint FOREIGN KEY (complaint_id) REFERENCES complaints (id) ON DELETE CASCADE,
  CONSTRAINT fk_comments_user FOREIGN KEY (user_id) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attachments (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  complaint_id INT UNSIGNED NOT NULL,
  comment_id INT UNSIGNED NULL,
  uploaded_by INT UNSIGNED NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(80) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  size_bytes INT UNSIGNED NOT NULL,
  sha256 CHAR(64) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_attachments_stored (stored_name),
  KEY idx_attachments_complaint (complaint_id),
  CONSTRAINT fk_attach_complaint FOREIGN KEY (complaint_id) REFERENCES complaints (id) ON DELETE CASCADE,
  CONSTRAINT fk_attach_comment FOREIGN KEY (comment_id) REFERENCES complaint_comments (id) ON DELETE SET NULL,
  CONSTRAINT fk_attach_user FOREIGN KEY (uploaded_by) REFERENCES users (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notifications (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  complaint_id INT UNSIGNED NULL,
  type VARCHAR(40) NOT NULL,
  title VARCHAR(160) NOT NULL,
  message VARCHAR(500) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, is_read, created_at),
  KEY idx_notif_complaint (complaint_id),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT fk_notif_complaint FOREIGN KEY (complaint_id) REFERENCES complaints (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  requested_ip VARCHAR(45) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_reset_token (token_hash),
  KEY idx_reset_user (user_id),
  CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  identifier CHAR(64) NOT NULL,
  ip_address VARCHAR(45) NOT NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_attempts_identifier (identifier, attempted_at),
  KEY idx_attempts_ip (ip_address, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NULL,
  action VARCHAR(60) NOT NULL,
  entity_type VARCHAR(40) NULL,
  entity_id INT UNSIGNED NULL,
  details TEXT NULL,
  ip_address VARCHAR(45) NULL,
  user_agent VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_audit_user (user_id),
  KEY idx_audit_action (action),
  KEY idx_audit_entity (entity_type, entity_id),
  KEY idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS system_settings (
  setting_key VARCHAR(60) NOT NULL,
  setting_value TEXT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Reference data (idempotent)
-- ---------------------------------------------------------------------
INSERT IGNORE INTO roles (id, slug, name, description) VALUES
 (1, 'super_admin',    'Super Administrator',     'Full system access'),
 (2, 'nis_admin',      'NIS Administrator',      'Manages complaints, technicians and reports'),
 (3, 'technician',     'Network Technician',     'Works on assigned complaints'),
 (4, 'department_rep', 'Department Representative', 'Reports and tracks department complaints');

INSERT IGNORE INTO permissions (code, label) VALUES
 ('complaints.create',   'Submit complaints'),
 ('complaints.respond',  'Respond to information requests, confirm or reopen resolved complaints'),
 ('complaints.review',   'Review, accept, reject, change status and close complaints'),
 ('complaints.assign',   'Assign and reassign complaints to technicians'),
 ('complaints.work',     'Update investigation progress on assigned complaints'),
 ('departments.manage',  'Register and manage departments'),
 ('users.manage',        'Manage technicians and department representatives'),
 ('technicians.view',    'Monitor technician workload and activity'),
 ('reports.view',        'View reports'),
 ('reports.export',      'Export reports (CSV / PDF / print)'),
 ('analytics.view',      'View dashboard analytics charts');

-- Default grants (role ids: 2 nis_admin, 3 technician, 4 department_rep)
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT 2, id FROM permissions WHERE code IN ('complaints.review','complaints.assign','departments.manage','users.manage','technicians.view','reports.view','reports.export','analytics.view');
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT 3, id FROM permissions WHERE code IN ('complaints.work');
INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT 4, id FROM permissions WHERE code IN ('complaints.create','complaints.respond');

INSERT IGNORE INTO complaint_categories (name, sort_order) VALUES
 ('Internet connectivity failure', 1),
 ('Slow internet connection', 2),
 ('Wi-Fi connectivity problems', 3),
 ('LAN/network port problems', 4),
 ('Router problems', 5),
 ('Switch problems', 6),
 ('Access point problems', 7),
 ('Network cable damage', 8),
 ('Network configuration issues', 9),
 ('IP address or DHCP problems', 10),
 ('DNS-related problems', 11),
 ('Network security concerns', 12),
 ('Other networking problems', 13);

INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES
 ('system_name',        'UCC NIS Network Support & Complaint Management System'),
 ('system_abbr',        'UCC NIS NSCMS'),
 ('org_name',           'University of Cape Coast'),
 ('section_name',       'Network Infrastructure Section (NIS)'),
 ('support_email',      ''),
 ('support_phone',      ''),
 ('sla_hours_critical', '4'),
 ('sla_hours_high',     '24'),
 ('sla_hours_medium',   '72'),
 ('sla_hours_low',      '168'),
 ('per_page',           '15'),
 ('max_upload_mb',      '5'),
 ('session_timeout_min','30'),
 ('email_enabled',      '0'),
 ('recurring_threshold','3');

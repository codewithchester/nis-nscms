<?php
declare(strict_types=1);
/**
 * UCC NIS NSCMS — web installer.
 * Creates the database tables, the first Super Administrator and the .env file, then locks itself.
 * DELETE THIS FOLDER after installation.
 */
define('APP_ROOT', dirname(__DIR__));
require APP_ROOT . '/app/Core/Password.php';

use App\Core\Password;

$lock = APP_ROOT . '/storage/installed.lock';
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (int)($_SERVER['SERVER_PORT'] ?? 0) === 443;
header("Content-Security-Policy: default-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'self'");
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cache-Control: no-store');

$root = rtrim(str_replace('\\', '/', dirname(dirname($_SERVER['SCRIPT_NAME'] ?? '/install/index.php'))), '/');
$asset = fn(string $p) => $root . '/assets/' . $p;
$e = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

session_name('NIS_INSTALL');
session_set_cookie_params(['lifetime' => 0, 'path' => ($root === '' ? '/' : $root . '/'), 'secure' => $https, 'httponly' => true, 'samesite' => 'Lax']);
session_start();
if (empty($_SESSION['t'])) $_SESSION['t'] = bin2hex(random_bytes(24));

function page(string $title, string $body, string $root): void
{
    global $asset, $e;
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">'
       . '<title>' . $e($title) . ' · Installer</title><link rel="stylesheet" href="' . $e($asset('vendor/bootstrap/bootstrap.min.css')) . '"><link rel="stylesheet" href="' . $e($asset('css/app.css')) . '"></head>'
       . '<body class="auth-page"><div class="container py-4 install-wrap">' . $body
       . '<p class="text-center text-muted small mt-4">Designed by <a href="https://teakaymultimedia.onrender.com" target="_blank" rel="noopener noreferrer">Teakay Multimedia</a></p></div></body></html>';
    exit;
}

if (is_file($lock) || is_file(APP_ROOT . '/.env')) {
    page('Already installed', '<div class="panel panel-b mt-4"><h1 class="h3">The system is already installed</h1><p>For security, the installer is disabled. <b>Delete the <span class="mono">install</span> folder</b> from the server.</p><a class="btn btn-primary" href="' . $e($root . '/index.php') . '">Open the portal</a></div>', $root);
}

// ---- requirements -------------------------------------------------------
$checks = [
    ['PHP 8.1 or newer', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION],
    ['PDO MySQL extension', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'OK' : 'Missing'],
    ['mbstring extension', extension_loaded('mbstring'), extension_loaded('mbstring') ? 'OK' : 'Missing'],
    ['fileinfo extension (upload checks)', extension_loaded('fileinfo'), extension_loaded('fileinfo') ? 'OK' : 'Missing (uploads fall back to extension checks)'],
    ['storage/ is writable', is_writable(APP_ROOT . '/storage'), APP_ROOT . '/storage'],
    ['Project folder is writable (to create .env)', is_writable(APP_ROOT), APP_ROOT],
];
$hardFail = !$checks[0][1] || !$checks[1][1] || !$checks[2][1] || !$checks[4][1];

$errors = [];
$in = ['db_host' => '127.0.0.1', 'db_port' => '3306', 'db_name' => '', 'db_user' => '', 'app_env' => 'local', 'app_url' => '', 'admin_name' => '', 'admin_email' => '', 'create_db' => '', 'samples' => '1'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$hardFail) {
    foreach ($in as $k => $_) $in[$k] = is_string($_POST[$k] ?? null) ? trim($_POST[$k]) : '';
    $dbPass = (string)($_POST['db_pass'] ?? '');
    $pw = (string)($_POST['admin_password'] ?? '');
    $pw2 = (string)($_POST['admin_password_confirm'] ?? '');

    if (!hash_equals($_SESSION['t'], (string)($_POST['t'] ?? ''))) $errors[] = 'Your session expired. Reload the page and try again.';
    if ($in['db_host'] === '' || !preg_match('/^[A-Za-z0-9.\-_:]+$/', $in['db_host'])) $errors[] = 'Enter a valid database host.';
    if (!ctype_digit($in['db_port']) || (int)$in['db_port'] < 1 || (int)$in['db_port'] > 65535) $errors[] = 'Enter a valid database port.';
    if (!preg_match('/^[A-Za-z0-9_$\-]{1,64}$/', $in['db_name'])) $errors[] = 'Database name may contain letters, numbers, underscores and hyphens.';
    if ($in['db_user'] === '') $errors[] = 'Enter the database user.';
    if (!in_array($in['app_env'], ['local', 'production'], true)) $errors[] = 'Choose an environment.';
    if ($in['app_url'] !== '' && !preg_match('~^https?://[A-Za-z0-9.\-:/_]+$~', $in['app_url'])) $errors[] = 'Site URL must start with http:// or https:// and have no spaces.';
    if (!preg_match('/^[\p{L}\p{M}\s\'.,-]{2,120}$/u', $in['admin_name'])) $errors[] = 'Enter the administrator’s full name.';
    if (!filter_var($in['admin_email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid administrator email.';
    if ($err = Password::policy($pw, $in['admin_email'], $in['admin_name'])) $errors[] = $err;
    elseif (!hash_equals($pw, $pw2)) $errors[] = 'The two passwords do not match.';

    if (!$errors) {
        try {
            $dsn = fn(bool $withDb) => sprintf('mysql:host=%s;port=%d;%scharset=utf8mb4', $in['db_host'], (int)$in['db_port'], $withDb ? 'dbname=' . $in['db_name'] . ';' : '');
            $opts = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false];
            try {
                $pdo = new PDO($dsn(true), $in['db_user'], $dbPass, $opts);
            } catch (PDOException $ex) {
                if ($in['create_db'] === '1' && (int)$ex->getCode() === 1049) {
                    $tmp = new PDO($dsn(false), $in['db_user'], $dbPass, $opts);
                    $tmp->exec('CREATE DATABASE `' . str_replace('`', '', $in['db_name']) . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                    $pdo = new PDO($dsn(true), $in['db_user'], $dbPass, $opts);
                } else {
                    throw $ex;
                }
            }
            if ((int)$pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'users'")->fetchColumn() > 0
                && (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn() > 0) {
                throw new RuntimeException('This database already contains users. Use an empty database, or remove the existing tables first.');
            }

            // schema
            $sql = (string)file_get_contents(APP_ROOT . '/database/schema.sql');
            $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
            foreach (preg_split('/;\s*[\r\n]+/', $sql) ?: [] as $stmt) {
                $stmt = trim($stmt, " \t\r\n;");
                if ($stmt !== '') $pdo->exec($stmt);
            }

            $roleId = (int)$pdo->query("SELECT id FROM roles WHERE slug = 'super_admin'")->fetchColumn();
            $st = $pdo->prepare('INSERT INTO users (role_id, full_name, email, password_hash, password_changed_at) VALUES (?,?,?,?,NOW())');
            $st->execute([$roleId, $in['admin_name'], strtolower($in['admin_email']), Password::hash($pw)]);

            if ($in['samples'] === '1') {
                $d = $pdo->prepare('INSERT IGNORE INTO departments (name, code, location) VALUES (?,?,?)');
                foreach ([
                    ['Department of Computer Science and Information Technology', 'CSIT', 'School of Physical Sciences'],
                    ['University Library', 'LIB', 'Library Complex'],
                    ['Finance Directorate', 'FIN', 'Administration Block'],
                    ['Directorate of Academic Affairs', 'DAA', 'Administration Block'],
                    ['Department of Physics', 'PHY', 'School of Physical Sciences'],
                ] as $row) $d->execute($row);
            }

            // The .env loader strips one pair of surrounding quotes and does not process escapes.
            if (preg_match('/[\r\n]/', $dbPass)) throw new RuntimeException('The database password must not contain line breaks.');
            if (!str_contains($dbPass, '"')) $dbPassLine = '"' . $dbPass . '"';
            elseif (!str_contains($dbPass, "'")) $dbPassLine = "'" . $dbPass . "'";
            else throw new RuntimeException('Database passwords containing both single and double quotes are not supported. Change the password.');
            $env = implode("\n", [
                '# Generated by the installer on ' . date('c'),
                'APP_ENV=' . $in['app_env'], 'APP_DEBUG=false', 'APP_URL=' . rtrim($in['app_url'], '/'), 'APP_TIMEZONE=Africa/Accra',
                'DB_HOST=' . $in['db_host'], 'DB_PORT=' . (int)$in['db_port'], 'DB_NAME=' . $in['db_name'], 'DB_USER=' . $in['db_user'],
                'DB_PASS=' . $dbPassLine,
                'TRUST_PROXY_HEADERS=false', 'MAIL_DRIVER=log', 'MAIL_HOST=', 'MAIL_PORT=587', 'MAIL_ENCRYPTION=tls', 'MAIL_USERNAME=', 'MAIL_PASSWORD=',
                'MAIL_FROM_ADDRESS=', 'MAIL_FROM_NAME="UCC NIS Support"', 'CSP_EXTRA_SCRIPT_SRC=', '',
            ]);
            $written = @file_put_contents(APP_ROOT . '/.env', $env, LOCK_EX);
            if ($written !== false) @chmod(APP_ROOT . '/.env', 0640);
            @file_put_contents($lock, 'installed ' . date('c'));
            session_regenerate_id(true);
            unset($_SESSION['t']);

            $body = '<div class="panel panel-b mt-4"><h1 class="h3">Installation complete</h1><p>Database tables created and the Super Administrator <b>' . $e($in['admin_email']) . '</b> is ready.</p>';
            if ($written === false) {
                $body .= '<div class="alert alert-warning">Could not write <span class="mono">.env</span> automatically. Create a file named <span class="mono">.env</span> in the project root with the content below:</div><pre class="p-3 bg-light border small">' . $e($env) . '</pre>';
            }
            $body .= '<div class="alert alert-danger"><b>Important:</b> delete the <span class="mono">install</span> folder from the server now.</div>'
                   . '<a class="btn btn-primary" href="' . $e($root . '/index.php') . '">Open the portal and sign in</a></div>';
            page('Installed', $body, $root);
        } catch (Throwable $ex) {
            $errors[] = ($ex instanceof PDOException ? 'Database error: ' : '') . $ex->getMessage();
        }
    }
}

ob_start(); ?>
<div class="panel mt-3">
  <div class="panel-h"><div><h1 class="h4 mb-0">UCC NIS NSCMS installer</h1><small class="text-muted">University of Cape Coast · Network Infrastructure Section</small></div></div>
  <div class="panel-b">
    <h2 class="h6">1. Server check</h2>
    <ul class="list-unstyled small">
      <?php foreach ($checks as [$label, $ok, $note]): ?><li><?= $ok ? '<span class="text-success">&#10003;</span>' : '<span class="text-danger">&#10007;</span>' ?> <?= $e($label) ?> <span class="text-muted">— <?= $e($note) ?></span></li><?php endforeach; ?>
    </ul>
    <?php if ($hardFail): ?><div class="alert alert-danger">Fix the failed checks above, then reload this page.</div><?php endif; ?>
    <?php if ($errors): ?><div class="alert alert-danger" role="alert"><ul class="mb-0"><?php foreach ($errors as $m): ?><li><?= $e($m) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <?php if (!$hardFail): ?>
    <form method="post" autocomplete="off">
      <input type="hidden" name="t" value="<?= $e($_SESSION['t']) ?>">
      <h2 class="h6 mt-3">2. Database</h2>
      <p class="small text-muted">Create an empty MySQL/MariaDB database first (phpMyAdmin, or the hosting control panel), or tick the box to let the installer create it on a local server.</p>
      <div class="row g-3">
        <div class="col-md-8"><label class="form-label" for="db_host">Host</label><input class="form-control" id="db_host" name="db_host" value="<?= $e($in['db_host']) ?>" required></div>
        <div class="col-md-4"><label class="form-label" for="db_port">Port</label><input class="form-control" id="db_port" name="db_port" value="<?= $e($in['db_port']) ?>" required></div>
        <div class="col-md-4"><label class="form-label" for="db_name">Database name</label><input class="form-control" id="db_name" name="db_name" value="<?= $e($in['db_name']) ?>" required></div>
        <div class="col-md-4"><label class="form-label" for="db_user">Database user</label><input class="form-control" id="db_user" name="db_user" value="<?= $e($in['db_user']) ?>" required></div>
        <div class="col-md-4"><label class="form-label" for="db_pass">Database password</label><input class="form-control" type="password" id="db_pass" name="db_pass" autocomplete="new-password"></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="create_db" name="create_db" value="1"<?= $in['create_db'] === '1' ? ' checked' : '' ?>><label class="form-check-label" for="create_db">Create the database if it does not exist (local servers)</label></div></div>
      </div>
      <h2 class="h6 mt-4">3. Site</h2>
      <div class="row g-3">
        <div class="col-md-4"><label class="form-label" for="app_env">Environment</label><select class="form-select" id="app_env" name="app_env"><option value="local"<?= $in['app_env'] === 'local' ? ' selected' : '' ?>>Local testing</option><option value="production"<?= $in['app_env'] === 'production' ? ' selected' : '' ?>>Production (live site)</option></select></div>
        <div class="col-md-8"><label class="form-label" for="app_url">Site URL (optional)</label><input class="form-control" id="app_url" name="app_url" value="<?= $e($in['app_url']) ?>" placeholder="https://nis.example.edu.gh"><div class="form-text">Used in email links. Leave empty to auto-detect.</div></div>
        <div class="col-12"><div class="form-check"><input class="form-check-input" type="checkbox" id="samples" name="samples" value="1"<?= $in['samples'] === '1' ? ' checked' : '' ?>><label class="form-check-label" for="samples">Add a few sample departments so I can try the system (you can edit or deactivate them later)</label></div></div>
      </div>
      <h2 class="h6 mt-4">4. Super Administrator account</h2>
      <div class="row g-3">
        <div class="col-md-6"><label class="form-label" for="admin_name">Full name</label><input class="form-control" id="admin_name" name="admin_name" value="<?= $e($in['admin_name']) ?>" required></div>
        <div class="col-md-6"><label class="form-label" for="admin_email">Email (used to sign in)</label><input class="form-control" type="email" id="admin_email" name="admin_email" value="<?= $e($in['admin_email']) ?>" required></div>
        <div class="col-md-6"><label class="form-label" for="admin_password">Password</label><input class="form-control" type="password" id="admin_password" name="admin_password" autocomplete="new-password" maxlength="72" required><div class="form-text">10+ characters, letters and numbers.</div></div>
        <div class="col-md-6"><label class="form-label" for="admin_password_confirm">Confirm password</label><input class="form-control" type="password" id="admin_password_confirm" name="admin_password_confirm" autocomplete="new-password" maxlength="72" required></div>
      </div>
      <button class="btn btn-primary mt-4" type="submit">Install</button>
    </form>
    <?php endif; ?>
  </div>
</div>
<?php page('Installer', (string)ob_get_clean(), $root);

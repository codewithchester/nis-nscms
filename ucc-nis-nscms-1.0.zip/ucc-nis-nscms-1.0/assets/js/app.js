/* UCC NIS NSCMS front-end behaviour. No inline scripts are used anywhere (strict CSP). */
(function () {
  'use strict';

  // Mobile sidebar
  var sb = document.getElementById('sidebar'), scrim = document.getElementById('scrim');
  var mainCol = document.querySelector('.main-col');
  var menuToggles = document.querySelectorAll('[data-sidebar-toggle]');
  function mobileNavigation() {
    return window.matchMedia ? window.matchMedia('(max-width: 991px)').matches : window.innerWidth <= 991;
  }
  function setSidebarAccessibility(open) {
    if (!sb) return;
    var mobile = mobileNavigation();
    if (!mobile) {
      sb.removeAttribute('aria-hidden');
      if ('inert' in sb) sb.inert = false;
      if (mainCol) {
        mainCol.removeAttribute('aria-hidden');
        if ('inert' in mainCol) mainCol.inert = false;
      }
      return;
    }
    sb.setAttribute('aria-hidden', open ? 'false' : 'true');
    if ('inert' in sb) sb.inert = !open;
    if (mainCol) {
      mainCol.setAttribute('aria-hidden', open ? 'true' : 'false');
      if ('inert' in mainCol) mainCol.inert = open;
    }
  }
  function toggleSidebar(force) {
    if (!sb) return;
    var open = typeof force === 'boolean' ? force : !sb.classList.contains('open');
    sb.classList.toggle('open', open);
    if (scrim) scrim.classList.toggle('open', open);
    menuToggles.forEach(function (button) {
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (!button.classList.contains('sidebar-close')) button.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
    });
    setSidebarAccessibility(open);
    if (mobileNavigation()) {
      var closeButton = sb.querySelector('.sidebar-close');
      var openButton = document.querySelector('.menu-toggle');
      if (open && closeButton) closeButton.focus();
      if (!open && openButton) openButton.focus();
    }
  }
  menuToggles.forEach(function (b) { b.addEventListener('click', function () { toggleSidebar(); }); });
  if (scrim) scrim.addEventListener('click', function () { toggleSidebar(false); });
  if (sb) {
    setSidebarAccessibility(sb.classList.contains('open'));
    window.addEventListener('resize', function () {
      if (!mobileNavigation()) toggleSidebar(false);
      else setSidebarAccessibility(sb.classList.contains('open'));
    });
    document.addEventListener('keydown', function (event) {
      if (!sb.classList.contains('open')) return;
      if (event.key === 'Escape') {
        event.preventDefault();
        toggleSidebar(false);
        return;
      }
      if (event.key !== 'Tab') return;
      var focusable = sb.querySelectorAll('a[href],button:not([disabled])');
      if (!focusable.length) return;
      var first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    });
  }

  // Progress widths (set via CSSOM so CSP can stay free of inline styles)
  document.querySelectorAll('[data-width]').forEach(function (el) {
    el.style.width = Math.max(0, Math.min(100, parseFloat(el.getAttribute('data-width')) || 0)) + '%';
  });

  // Confirm dialogs + double-submit guard
  document.addEventListener('submit', function (e) {
    var f = e.target;
    var msg = f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) { e.preventDefault(); return; }
    if (f.hasAttribute('data-noguard')) return;
    var btns = f.querySelectorAll('button[type="submit"]');
    setTimeout(function () { btns.forEach(function (b) { b.disabled = true; }); }, 0);
  });
  window.addEventListener('pageshow', function () {
    document.querySelectorAll('form button[type="submit"]').forEach(function (b) { b.disabled = false; });
  });

  // Print
  document.querySelectorAll('[data-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });

  // Expandable report preview (content remains visible if JavaScript is unavailable).
  document.querySelectorAll('[data-report-preview]').forEach(function (panel) {
    var toggle = panel.querySelector('[data-preview-toggle]');
    var body = panel.querySelector('.report-preview-body');
    var label = panel.querySelector('[data-preview-label]');
    if (!toggle || !body) return;

    function setExpanded(expanded) {
      panel.setAttribute('data-expanded', expanded ? 'true' : 'false');
      toggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
      body.setAttribute('aria-hidden', expanded ? 'false' : 'true');
      if ('inert' in body) body.inert = !expanded;
      if (label) label.textContent = expanded ? 'Collapse' : 'Expand';
    }

    setExpanded(false);
    window.requestAnimationFrame(function () { setExpanded(true); });
    toggle.addEventListener('click', function () {
      setExpanded(toggle.getAttribute('aria-expanded') !== 'true');
    });
  });

  // Show / hide password
  document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-toggle-password'));
      if (!input) return;
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      var i = btn.querySelector('i'); if (i) i.className = show ? 'bi bi-eye-slash' : 'bi bi-eye';
    });
  });

  // Status form: adapt note label / requirement to the chosen status
  document.querySelectorAll('select[data-notes]').forEach(function (sel) {
    var notes = {}; try { notes = JSON.parse(sel.getAttribute('data-notes')); } catch (e) {}
    var label = document.getElementById(sel.getAttribute('data-label'));
    var note = document.getElementById(sel.getAttribute('data-note'));
    function sync() {
      var n = notes[sel.value] || { label: 'Note (optional)', required: false };
      if (label) { label.textContent = n.label; label.classList.toggle('req', !!n.required); }
      if (note) note.required = !!n.required;
    }
    sel.addEventListener('change', sync); sync();
  });

  // Client-side file size hint (the server enforces the real limit)
  document.querySelectorAll('input[type="file"][data-max-mb]').forEach(function (inp) {
    inp.addEventListener('change', function () {
      var max = parseFloat(inp.getAttribute('data-max-mb')) * 1048576;
      if (inp.files[0] && inp.files[0].size > max) {
        window.alert('That file is larger than ' + inp.getAttribute('data-max-mb') + ' MB. Please choose a smaller file.');
        inp.value = '';
      }
    });
  });

  // Charts
  if (window.Chart) {
    var charts = [];
    var cs = getComputedStyle(document.documentElement);
    var chartText = cs.getPropertyValue('--muted').trim() || '#586172';
    var chartGrid = cs.getPropertyValue('--line-2').trim() || '#eceff4';
    Chart.defaults.font.family = getComputedStyle(document.body).fontFamily;
    Chart.defaults.font.size = 12;
    Chart.defaults.color = chartText;
    document.querySelectorAll('canvas[data-chart]').forEach(function (cv) {
      var cfg; try { cfg = JSON.parse(cv.getAttribute('data-chart')); } catch (e) { return; }
      var isRound = cfg.type === 'doughnut' || cfg.type === 'pie';
      var options = {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: cfg.legend !== false, position: 'bottom', labels: { boxWidth: 10, usePointStyle: true } } }
      };
      if (!isRound) {
        var horiz = !!cfg.horizontal;
        var valAxis = { beginAtZero: true, ticks: { precision: 0 }, grid: { color: chartGrid } };
        var catAxis = { grid: { display: false }, ticks: { autoSkip: false, maxRotation: horiz ? 0 : 40 } };
        options.indexAxis = horiz ? 'y' : 'x';
        options.scales = horiz ? { x: valAxis, y: catAxis } : { y: valAxis, x: catAxis };
        if (cfg.datasets.some(function (d) { return d.yAxisID === 'y2'; })) {
          options.scales.y2 = { position: 'right', min: 0, max: 100, grid: { drawOnChartArea: false }, ticks: { callback: function (v) { return v + '%'; } } };
        }
        if (cfg.yTitle) options.scales.y.title = { display: true, text: cfg.yTitle };
      } else {
        options.cutout = '62%';
      }
      charts.push(new Chart(cv, { type: cfg.type, data: { labels: cfg.labels, datasets: cfg.datasets }, options: options }));
    });
    document.addEventListener('app:themechange', function () {
      var style = getComputedStyle(document.documentElement);
      Chart.defaults.color = style.getPropertyValue('--muted').trim() || '#586172';
      var grid = style.getPropertyValue('--line-2').trim() || '#eceff4';
      charts.forEach(function (chart) {
        Object.keys(chart.options.scales || {}).forEach(function (axis) {
          if (chart.options.scales[axis].grid) chart.options.scales[axis].grid.color = grid;
        });
        chart.update();
      });
    });
  }
})();

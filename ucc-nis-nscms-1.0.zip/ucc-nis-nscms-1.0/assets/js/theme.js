/* Applies the saved appearance before page styles render. */
(function () {
  'use strict';

  var root = document.documentElement;
  var storageKey = 'ucc-nis-theme';

  function preferredTheme() {
    try {
      var saved = window.localStorage.getItem(storageKey);
      if (saved === 'light' || saved === 'dark') return saved;
    } catch (error) {
      if (window.console && window.console.warn) window.console.warn('Appearance preference could not be read.', error);
    }
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }

  function updateButtons(theme) {
    document.querySelectorAll('[data-theme-toggle]').forEach(function (button) {
      var next = theme === 'dark' ? 'light' : 'dark';
      var label = 'Switch to ' + next + ' mode';
      button.setAttribute('aria-label', label);
      button.setAttribute('title', label);
      button.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
      var lightIcon = button.querySelector('[data-theme-icon-light]');
      var darkIcon = button.querySelector('[data-theme-icon-dark]');
      if (lightIcon) lightIcon.hidden = theme === 'dark';
      if (darkIcon) darkIcon.hidden = theme !== 'dark';
      var text = button.querySelector('[data-theme-label]');
      if (text) text.textContent = 'Use ' + next + ' appearance';
    });
  }

  function setTheme(theme, save) {
    root.setAttribute('data-theme', theme);
    updateButtons(theme);
    document.dispatchEvent(new CustomEvent('app:themechange', { detail: { theme: theme } }));
    if (!save) return;
    try {
      window.localStorage.setItem(storageKey, theme);
    } catch (error) {
      if (window.console && window.console.warn) window.console.warn('Appearance preference could not be saved.', error);
    }
  }

  setTheme(preferredTheme(), false);
  document.addEventListener('DOMContentLoaded', function () { updateButtons(root.getAttribute('data-theme')); });
  document.addEventListener('click', function (event) {
    var button = event.target;
    while (button && button !== document && !button.hasAttribute('data-theme-toggle')) button = button.parentNode;
    if (!button || button === document) return;
    setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true);
  });
  window.addEventListener('storage', function (event) {
    if (event.key === storageKey && (event.newValue === 'light' || event.newValue === 'dark')) setTheme(event.newValue, false);
  });
})();
